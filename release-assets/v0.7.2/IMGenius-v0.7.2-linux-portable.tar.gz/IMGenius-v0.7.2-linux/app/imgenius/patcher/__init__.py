"""Safe local ZIP patching for IMGenius source installations."""
from .engine import (PatchError, PatchFile, PatchPlan, make_plan, apply_patch,
                     list_backups, restore_backup, installation_is_valid)

__all__ = ['PatchError', 'PatchFile', 'PatchPlan', 'make_plan', 'apply_patch',
           'list_backups', 'restore_backup', 'installation_is_valid']
