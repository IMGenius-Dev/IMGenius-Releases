"""Validate, preview, apply and restore IMGenius source ZIP patches.

The patch engine depends only on Python's standard library. It does NOT extract
arbitrary ZIP entries. It validates every destination, backs up originals, and
rolls back a partially applied patch if an error occurs.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import stat
import tempfile
from typing import Callable
from uuid import uuid4
from zipfile import ZipFile, BadZipFile, ZipInfo

PATCH_META = 'imgenius-patch.json'
BACKUP_DIR = '.imgenius-patcher/backups'
MAX_FILES = 160
MAX_SINGLE_FILE = 48 * 1024 * 1024
MAX_TOTAL_SIZE = 120 * 1024 * 1024
MAX_ARCHIVE_SIZE = 150 * 1024 * 1024
SAFE_EXTENSIONS = {
    '.py', '.pyi', '.json', '.md', '.txt', '.png', '.ico', '.jpg', '.jpeg',
    '.webp', '.svg', '.sh', '.bat', '.ps1', '.toml', '.yml', '.yaml', '.desktop',
    '.qss', '.ui', '.ini', '.css', '.qrc',
}
SAFE_ROOT_FILES = {
    'main.py', 'patcher.py', 'requirements.txt', 'README.md', 'pyproject.toml',
    'launch-linux.sh', 'launch-windows.bat', 'setup-windows.ps1', 'setup-windows.bat',
    'setup-linux.sh', 'launch-patcher-linux.sh',
    'launch-patcher-windows.bat', '.gitignore',
}
SAFE_TOP_FOLDERS = {'imgenius', 'assets', 'scripts', 'docs', 'tests', 'tools', '.github'}
DOCUMENTATION_FILES = {'README.md', 'UPGRADE.md', 'INSTALL.md'}
BASE_VERSION_RE = re.compile(r"__version__\s*=\s*['\"]([^'\"]+)['\"]")


class PatchError(ValueError):
    """A patch is invalid, incompatible or could not be installed safely."""


@dataclass(frozen=True)
class PatchFile:
    path: str
    member: str
    size: int
    operation: str
    sha256: str = ''


@dataclass(frozen=True)
class PatchPlan:
    zip_path: Path
    installation: Path
    name: str
    files: tuple[PatchFile, ...]
    patch_version: str = ''
    target_version: str = ''

    @property
    def new_count(self) -> int:
        return sum(f.operation == 'Add' for f in self.files)

    @property
    def changed_count(self) -> int:
        return sum(f.operation == 'Replace' for f in self.files)


def installation_is_valid(path: Path | str) -> bool:
    root = Path(path).expanduser()
    return (root / 'main.py').is_file() and (root / 'imgenius' / '__init__.py').is_file() and (
        (root / 'launch-linux.sh').is_file() or (root / 'launch-windows.bat').is_file()
    )


def _version(root: Path) -> str:
    match = BASE_VERSION_RE.search((root / 'imgenius' / '__init__.py').read_text(encoding='utf-8'))
    return match.group(1) if match else ''


def _valid_relative(path: str) -> PurePosixPath:
    if not path or '\\' in path or '\0' in path or path.startswith('/'):
        raise PatchError(f'Unsafe path in ZIP: {path!r}')
    win = PureWindowsPath(path)
    if win.drive or win.root:
        raise PatchError(f'Absolute or drive-qualified path: {path!r}')
    raw = path.split('/')
    if any(part in ('', '.', '..') for part in raw):
        raise PatchError(f'Unsafe path traversal in ZIP: {path!r}')
    posix = PurePosixPath(path)
    if posix.parts[0].casefold() in {'data', 'user_data', '.git', '.venv', 'dist', 'build', '.imgenius-patcher'}:
        raise PatchError(f'User data or private directories are not patchable: {path}')
    if posix.parts[0] not in SAFE_TOP_FOLDERS and str(posix) not in SAFE_ROOT_FILES:
        if str(posix) == 'qt_app.py' or str(posix) == 'core.py':
            raise PatchError('This is a pre-v0.5 patch. It cannot be applied to the reorganized IMGenius source. Download a v0.5+ patch instead.')
        raise PatchError(f'File is outside permitted IMGenius source folders: {path}')
    if posix.suffix.lower() not in SAFE_EXTENSIONS:
        raise PatchError(f'Unsupported file type: {path}')
    if any(part.startswith('.') and part not in {'.github', '.gitignore'} for part in posix.parts):
        raise PatchError(f'Hidden path not allowed: {path}')
    if any(part.casefold() in {'__pycache__', '.pytest_cache'} for part in posix.parts):
        raise PatchError(f'Generated files cannot be patched: {path}')
    return posix


def _inside_root(root: Path, relative: str) -> Path:
    destination = root.joinpath(*PurePosixPath(relative).parts)
    resolved = destination.resolve(strict=False)
    base = root.resolve()
    if resolved == base or base not in resolved.parents:
        raise PatchError(f'Destination leaves the installation folder: {relative}')
    # Even symlinks pointing back into the tree must not be replaced, as they
    # can have unexpected semantics on some platforms.
    cursor = root
    for part in PurePosixPath(relative).parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise PatchError(f'A symbolic link blocks this update: {relative}')
    return destination


def _is_link(info: ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def _unpack_member_names(zf: ZipFile):
    all_infos = [i for i in zf.infolist() if not i.is_dir()]
    if not all_infos:
        raise PatchError('This ZIP contains no files.')
    if len(all_infos) > MAX_FILES:
        raise PatchError('The ZIP contains too many files for a normal patch.')
    if sum(i.file_size for i in all_infos) > MAX_TOTAL_SIZE:
        raise PatchError('The ZIP uncompresses to an unusually large size.')
    for info in all_infos:
        if info.file_size > MAX_SINGLE_FILE:
            raise PatchError(f'File is too large for an update: {info.filename}')
        if info.flag_bits & 1:
            raise PatchError('Encrypted ZIP entries are not supported.')
        if _is_link(info):
            raise PatchError('ZIP files containing symlinks are not supported.')
        # Validate ALL raw member names before stripping any wrapper.
        if not info.filename or '\\' in info.filename or '\0' in info.filename or info.filename.startswith('/'):
            raise PatchError(f'Unsafe file path in ZIP: {info.filename}')
        if PureWindowsPath(info.filename).drive or any(p in ('', '.', '..') for p in info.filename.split('/')):
            raise PatchError(f'Unsafe ZIP file path: {info.filename}')

    paths = [PurePosixPath(i.filename) for i in all_infos]
    first_parts = {p.parts[0] for p in paths}
    # Accept ZIPs with one extra containing folder, such as
    # IMGenius_v0.5.2_Patch/imgenius/ui/pages/chats.py.
    contains_root = any(p.parts[0] in SAFE_TOP_FOLDERS or p.parts[0] in SAFE_ROOT_FILES or
                        p.parts[0] == PATCH_META for p in paths)
    prefix = ''
    if not contains_root and len(first_parts) == 1 and all(len(p.parts) > 1 for p in paths):
        prefix = next(iter(first_parts)) + '/'
    mapped = {}
    for info in all_infos:
        name = info.filename[len(prefix):] if prefix else info.filename
        if name in mapped:
            raise PatchError(f'Duplicate file destination in ZIP: {name}')
        mapped[name] = info
    return mapped


def _read_manifest(zf: ZipFile, mapped):
    if PATCH_META not in mapped:
        return None
    info = mapped[PATCH_META]
    if info.file_size > 64 * 1024:
        raise PatchError('Patch manifest is too large.')
    try:
        manifest = json.loads(zf.read(info).decode('utf-8'))
    except (UnicodeError, ValueError, BadZipFile) as exc:
        raise PatchError(f'Patch manifest is invalid: {exc}') from exc
    if not isinstance(manifest, dict) or manifest.get('format') != 'imgenius-patch-v1':
        raise PatchError('Unsupported patch manifest format.')
    return manifest


def make_plan(zip_path: Path | str, installation: Path | str) -> PatchPlan:
    root = Path(installation).expanduser().resolve()
    path = Path(zip_path).expanduser().resolve()
    if not installation_is_valid(root):
        raise PatchError('Choose the IMGenius source folder containing main.py and imgenius/. Compiled PyInstaller folders cannot be patched with this tool.')
    if not path.is_file() or path.suffix.lower() != '.zip':
        raise PatchError('Drop a valid .zip patch file.')
    if path.stat().st_size > MAX_ARCHIVE_SIZE:
        raise PatchError('This ZIP is too large for a normal source patch.')
    try:
        with ZipFile(path) as zf:
            mapped = _unpack_member_names(zf)
            manifest = _read_manifest(zf, mapped)
            target_version = str((manifest or {}).get('target_version', '')).strip()
            version = _version(root)
            if not version.startswith(('0.5', '0.6', '0.7')):
                raise PatchError(f'This patcher supports IMGenius v0.5.x, v0.6.x and v0.7.x source projects. Found {version or "unknown version"}.')
            if target_version and target_version.rstrip('.*') != version and not (
                target_version.endswith('.*') and version.startswith(target_version[:-1])
            ):
                raise PatchError(f'Patch requires IMGenius {target_version}, but the installed version is {version}.')
            declared = {}
            if manifest:
                entries = manifest.get('files')
                if not isinstance(entries, list) or not entries:
                    raise PatchError('Patch manifest must contain a nonempty files list.')
                for entry in entries:
                    if not isinstance(entry, dict) or not isinstance(entry.get('path'), str):
                        raise PatchError('A manifest file entry is invalid.')
                    if entry['path'] in declared:
                        raise PatchError(f'Duplicate file in manifest: {entry["path"]}')
                    checksum = entry.get('sha256', '')
                    if checksum and (not isinstance(checksum, str) or not re.fullmatch(r'[a-f0-9]{64}', checksum)):
                        raise PatchError('Invalid SHA256 hash in patch manifest.')
                    declared[entry['path']] = checksum
                names = list(declared)
                extra = set(mapped) - set(names) - {PATCH_META} - DOCUMENTATION_FILES
                if extra:
                    raise PatchError(f'ZIP contains files not listed in its manifest: {", ".join(sorted(extra)[:5])}')
            else:
                names = [name for name in mapped if name not in DOCUMENTATION_FILES and name != PATCH_META]
            if not names:
                raise PatchError('No application files were found. A patch must contain paths relative to the IMGenius source folder.')
            changes = []
            dest_names = set()
            for name in names:
                _valid_relative(name)
                if name not in mapped:
                    raise PatchError(f'A patch file is missing from the ZIP: {name}')
                folded = name.casefold()
                if folded in dest_names:
                    raise PatchError(f'Two files differ only by letter case: {name}')
                dest_names.add(folded)
                dest = _inside_root(root, name)
                if dest.exists() and not dest.is_file():
                    raise PatchError(f'Destination is not a file: {name}')
                changes.append(PatchFile(name, mapped[name].filename, mapped[name].file_size,
                                         'Replace' if dest.exists() else 'Add',
                                         declared.get(name, '')))
            return PatchPlan(path, root, str((manifest or {}).get('name') or path.stem),
                             tuple(changes), str((manifest or {}).get('version', '')),
                             target_version)
    except (BadZipFile, OSError) as exc:
        raise PatchError(f'Unable to read the ZIP: {exc}') from exc


def _write_copy(source, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    with open(destination, 'wb') as fp:
        shutil.copyfileobj(source, fp, 1024 * 512)


def _safe_write_bytes(src: Path, dest: Path):
    """Stage a copy next to the final file, then atomically replace it."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.parent / ('.imgenius-new-' + uuid4().hex)
    try:
        shutil.copy2(src, temp)
        if dest.exists():
            os.chmod(temp, dest.stat().st_mode)
        elif dest.suffix.lower() in ('.sh', '.bat'):
            os.chmod(temp, temp.stat().st_mode | stat.S_IXUSR)
        os.replace(temp, dest)
    finally:
        temp.unlink(missing_ok=True)


def _rollback(root: Path, saved: list[dict], backup: Path):
    errors = []
    for entry in reversed(saved):
        try:
            target = _inside_root(root, entry['path'])
            if entry['existed']:
                old = backup / 'files' / entry['path']
                _safe_write_bytes(old, target)
            else:
                target.unlink(missing_ok=True)
        except Exception as exc:
            errors.append(f'{entry["path"]}: {exc}')
    if errors:
        raise PatchError('Rollback was incomplete: ' + '; '.join(errors))


def apply_patch(plan: PatchPlan, on_progress: Callable[[int, int, str], None] | None = None) -> Path:
    """Apply a validated plan, retaining an installation-local backup.

    Returns the backup directory. A failure attempts to restore every touched
    file (and delete any newly added files).
    """
    # Replan immediately before writing to catch changed archives/targets.
    latest = make_plan(plan.zip_path, plan.installation)
    if [x.path for x in latest.files] != [x.path for x in plan.files]:
        raise PatchError('Patch contents changed since preview; inspect it again.')
    root = latest.installation
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = root / BACKUP_DIR / f'{stamp}_{uuid4().hex[:8]}'
    record: list[dict] = []
    staging_dir = None
    try:
        backup.mkdir(parents=True, exist_ok=False)
        staging_dir = Path(tempfile.mkdtemp(prefix='stage-', dir=backup))
        with ZipFile(latest.zip_path) as zf:
            for count, entry in enumerate(latest.files, 1):
                dest = _inside_root(root, entry.path)
                source = zf.getinfo(entry.member)
                target_stage = staging_dir / entry.path
                with zf.open(source) as stream:
                    _write_copy(stream, target_stage)
                # A manifest with hashes guarantees the selected bytes were
                # downloaded intact. For patches without one, still verify CRC
                # via ZipFile.open and the declared file size.
                if target_stage.stat().st_size != entry.size:
                    raise PatchError(f'Incomplete ZIP member: {entry.path}')
                if entry.sha256 and hashlib.sha256(target_stage.read_bytes()).hexdigest() != entry.sha256:
                    raise PatchError(f'Checksum mismatch: {entry.path}')
                exists = dest.exists()
                if exists:
                    old = backup / 'files' / entry.path
                    old.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dest, old)
                record.append({'path': entry.path, 'existed': exists})
                if on_progress:
                    on_progress(count, len(latest.files), f'Prepared {entry.path}')
        metadata = {
            'format': 'imgenius-backup-v1', 'name': latest.name,
            'created_at_utc': datetime.now(timezone.utc).isoformat(),
            'source_version': _version(root), 'files': record,
        }
        (backup / 'backup.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        for count, entry in enumerate(latest.files, 1):
            _inside_root(root, entry.path)
            _safe_write_bytes(staging_dir / entry.path, root / entry.path)
            if on_progress:
                on_progress(count, len(latest.files), f'Installed {entry.path}')
        metadata['state'] = 'installed'
        (backup / 'backup.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        return backup
    except Exception as exc:
        if record:
            try:
                _rollback(root, record, backup)
            except PatchError as rollback_exc:
                raise PatchError(f'Patch failed: {exc}. {rollback_exc}. Backup at {backup}') from exc
        if backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        if isinstance(exc, PatchError):
            raise
        raise PatchError(f'Patch failed and was rolled back: {exc}') from exc
    finally:
        if staging_dir:
            shutil.rmtree(staging_dir, ignore_errors=True)


def list_backups(installation: Path | str):
    root = Path(installation).expanduser().resolve()
    if not installation_is_valid(root):
        raise PatchError('Choose a valid IMGenius source folder.')
    parent = root / BACKUP_DIR
    result = []
    if parent.exists():
        for child in parent.iterdir():
            meta_file = child / 'backup.json'
            if child.is_dir() and not child.is_symlink() and meta_file.is_file():
                try:
                    metadata = json.loads(meta_file.read_text(encoding='utf-8'))
                    if metadata.get('format') == 'imgenius-backup-v1' and metadata.get('state') == 'installed':
                        result.append((child, metadata))
                except (ValueError, OSError):
                    pass
    return sorted(result, key=lambda x: x[0].name, reverse=True)


def restore_backup(installation: Path | str, backup_path: Path | str) -> None:
    root = Path(installation).expanduser().resolve()
    backup = Path(backup_path).expanduser().resolve()
    if not installation_is_valid(root):
        raise PatchError('Choose a valid IMGenius source folder.')
    expected_parent = (root / BACKUP_DIR).resolve()
    if backup.parent != expected_parent or not (backup / 'backup.json').is_file():
        raise PatchError('This backup does not belong to the selected IMGenius installation.')
    try:
        meta = json.loads((backup / 'backup.json').read_text(encoding='utf-8'))
        if meta.get('format') != 'imgenius-backup-v1' or meta.get('state') != 'installed':
            raise PatchError('The backup is not restorable.')
        files = meta.get('files')
        if not isinstance(files, list):
            raise PatchError('Backup file list is invalid.')
        for item in files:
            if not isinstance(item, dict) or not isinstance(item.get('path'), str) or not isinstance(item.get('existed'), bool):
                raise PatchError('The backup contains invalid file records.')
            _valid_relative(item['path'])
            _inside_root(root, item['path'])
            if item['existed'] and not (backup / 'files' / item['path']).is_file():
                raise PatchError(f'Backup is missing original file: {item["path"]}')
        _rollback(root, files, backup)
        meta['state'] = 'restored'
        (backup / 'backup.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    except (OSError, ValueError) as exc:
        if isinstance(exc, PatchError):
            raise
        raise PatchError(f'Could not restore the backup: {exc}') from exc
