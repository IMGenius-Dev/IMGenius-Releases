"""Native Qt drag/drop patch manager for IMGenius.

Only PySide6 is required, which is already a dependency of IMGenius.
"""
from __future__ import annotations

from pathlib import Path
import sys

from PySide6.QtCore import Qt, QSettings, QThread, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QFileDialog, QFrame, QHBoxLayout, QLabel, QMainWindow,
    QMessageBox, QProgressBar, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget, QLineEdit, QHeaderView, QSizePolicy,
)

from .engine import (
    PatchError, PatchPlan, make_plan, apply_patch, list_backups,
    restore_backup, installation_is_valid,
)

STYLESHEET = """
* { font-family: 'Noto Sans', 'Segoe UI', sans-serif; font-size: 14px; }
QMainWindow { background: #141626; }
QWidget { color: #e9e9f7; }
QLabel { background: transparent; }
QLabel#AppTitle { font-size: 24px; font-weight: 750; color: #f4f0ff; }
QLabel#Subtitle { color: #b3b8d3; font-size: 13px; }
QLabel#SectionHeading { font-weight: 700; font-size: 15px; }
QLabel#Information { color: #b9bdd3; }
QLabel#Status { color: #a3e4dc; }
QFrame#Panel { background: #222136; border: 1px solid #45445e; border-radius: 15px; }
QFrame#DropZone { background: #211f38; border: 2px dashed #8074c7; border-radius: 16px; }
QFrame#DropZone[dragActive='true'] { border-color: #5bdcf7; background: #2c3551; }
QLabel#DropTitle { font-size: 17px; font-weight: 750; }
QLabel#DropHint { font-size: 12px; color: #adb8d4; }
QLineEdit { background: #171728; border: 1px solid #555372; border-radius: 9px; padding: 10px 12px; }
QLineEdit:focus { border: 1px solid #67b7f1; }
QPushButton { background: #353249; border: 1px solid #5b5674; border-radius: 10px; padding: 10px 15px; }
QPushButton:hover { background: #494263; border-color: #aaa1ee; }
QPushButton:disabled { color: #77788d; background: #252438; border-color: #353447; }
QPushButton#Primary { background: #6253d5; border-color: #8577ed; color: white; font-weight: 700; }
QPushButton#Primary:hover { background: #7364e4; }
QProgressBar { background: #171728; color: #eeeaff; border: 1px solid #45445e; border-radius: 7px; text-align: center; }
QProgressBar::chunk { background: #7661e7; border-radius: 6px; }
QTableWidget { background: #171728; alternate-background-color: #1d1d30; border: 1px solid #48465e; border-radius: 10px; gridline-color: transparent; }
QTableWidget::item { padding: 7px 8px; }
QHeaderView::section { background: #2b293f; color: #d8d7ef; font-weight: 650; padding: 9px; border: none; }
"""


class DropZone(QFrame):
    dropped = Signal(str)

    def __init__(self):
        super().__init__()
        self.setObjectName('DropZone')
        self.setAcceptDrops(True)
        self.setMinimumHeight(115)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        self.title = QLabel('Drop a patch ZIP here')
        self.title.setObjectName('DropTitle')
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.title)
        hint = QLabel('or choose a .zip file using Browse')
        hint.setObjectName('DropHint')
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)

    def _file(self, event):
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if len(urls) != 1 or not urls[0].isLocalFile():
            return None
        path = Path(urls[0].toLocalFile())
        return str(path) if path.suffix.lower() == '.zip' else None

    def dragEnterEvent(self, event):
        if self._file(event):
            self.setProperty('dragActive', True)
            self.style().unpolish(self)
            self.style().polish(self)
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.setProperty('dragActive', False)
        self.style().unpolish(self)
        self.style().polish(self)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):
        self.setProperty('dragActive', False)
        self.style().unpolish(self)
        self.style().polish(self)
        path = self._file(event)
        if path:
            self.dropped.emit(path)
            event.acceptProposedAction()
        else:
            event.ignore()


class InstallWorker(QThread):
    progress = Signal(int, int, str)
    completed = Signal(str)
    problem = Signal(str)

    def __init__(self, plan: PatchPlan):
        super().__init__()
        self.plan = plan

    def run(self):
        try:
            backup = apply_patch(self.plan, lambda pos, count, msg: self.progress.emit(pos, count, msg))
            self.completed.emit(str(backup))
        except Exception as exc:
            self.problem.emit(str(exc))


class RestoreWorker(QThread):
    completed = Signal()
    problem = Signal(str)

    def __init__(self, folder, backup):
        super().__init__()
        self.folder = folder
        self.backup = backup

    def run(self):
        try:
            restore_backup(self.folder, self.backup)
            self.completed.emit()
        except Exception as exc:
            self.problem.emit(str(exc))


class PatchWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('IMGenius Patcher')
        self.resize(880, 735)
        self.setMinimumSize(680, 590)
        self.setAcceptDrops(True)
        self.settings = QSettings('IMGenius', 'Patcher')
        self.plan: PatchPlan | None = None
        self._selected_zip_path = ''
        self.worker = None
        self.last_backup = None
        self._build()
        self._load_installation()

    def _build(self):
        container = QWidget()
        self.setCentralWidget(container)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(24, 21, 24, 22)
        layout.setSpacing(14)
        header = QHBoxLayout()
        title = QLabel('IMGenius Patcher')
        title.setObjectName('AppTitle')
        header.addWidget(title)
        header.addStretch()
        info = QLabel('LOCAL UPDATES')
        info.setObjectName('Information')
        header.addWidget(info)
        layout.addLayout(header)
        subtitle = QLabel('Drag in a patch, preview the changes, and apply them safely to your IMGenius source folder.')
        subtitle.setObjectName('Subtitle')
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        loc = QFrame()
        loc.setObjectName('Panel')
        loc_layout = QVBoxLayout(loc)
        loc_layout.setContentsMargins(15, 14, 15, 14)
        loc_layout.setSpacing(9)
        loc_layout.addWidget(self._label('IMGenius installation folder'))
        row = QHBoxLayout()
        self.install_field = QLineEdit()
        self.install_field.setPlaceholderText('Choose the folder containing main.py and imgenius/')
        self.install_field.editingFinished.connect(self._location_edited)
        row.addWidget(self.install_field, 1)
        self.folder_button = QPushButton('Browse folder…')
        self.folder_button.clicked.connect(self.browse_installation)
        row.addWidget(self.folder_button)
        loc_layout.addLayout(row)
        self.location_hint = QLabel('IMGenius 0.5.x and 0.6.x source projects. Your saved character and chat data is not modified.')
        self.location_hint.setObjectName('Subtitle')
        self.location_hint.setWordWrap(True)
        loc_layout.addWidget(self.location_hint)
        layout.addWidget(loc)

        self.dropzone = DropZone()
        self.dropzone.dropped.connect(self.select_zip)
        layout.addWidget(self.dropzone)
        choose_row = QHBoxLayout()
        self.selected_zip = QLabel('No patch selected')
        self.selected_zip.setObjectName('Information')
        self.selected_zip.setWordWrap(True)
        choose_row.addWidget(self.selected_zip, 1)
        self.browse_button = QPushButton('Browse ZIP…')
        self.browse_button.clicked.connect(self.browse_zip)
        choose_row.addWidget(self.browse_button)
        layout.addLayout(choose_row)

        layout.addWidget(self._label('Files to update'))
        self.summary = QLabel('Select a ZIP to preview the changes.')
        self.summary.setObjectName('Information')
        layout.addWidget(self.summary)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(['Action', 'Target file', 'Size'])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setMinimumHeight(140)
        layout.addWidget(self.table, 1)

        self.status = QLabel('Ready. Close IMGenius before installing an update.')
        self.status.setObjectName('Status')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        layout.addWidget(self.bar)
        actions = QHBoxLayout()
        self.restore_button = QPushButton('Restore last backup')
        self.restore_button.clicked.connect(self.restore_last)
        actions.addWidget(self.restore_button)
        actions.addStretch()
        self.apply_button = QPushButton('Apply patch')
        self.apply_button.setObjectName('Primary')
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self.install_patch)
        actions.addWidget(self.apply_button)
        layout.addLayout(actions)

    def _label(self, text):
        lbl = QLabel(text)
        lbl.setObjectName('SectionHeading')
        return lbl

    def _load_installation(self):
        saved = Path(str(self.settings.value('install_dir', '') or '')).expanduser()
        root = Path(__file__).resolve().parents[2]
        found = saved if installation_is_valid(saved) else root if installation_is_valid(root) else None
        if found:
            self.install_field.setText(str(found.resolve()))
            self._location_edited()
        else:
            self.location_hint.setText('Select your IMGenius v0.5+ source folder first.')
        self._refresh_restore_button()

    def _location_edited(self):
        location = Path(self.install_field.text().strip()).expanduser()
        if installation_is_valid(location):
            self.install_field.setText(str(location.resolve()))
            self.settings.setValue('install_dir', str(location.resolve()))
            self.location_hint.setText('Installation found. Saved characters and chats will not be touched.')
        else:
            self.location_hint.setText('Folder not recognized. Select the IMGenius v0.5+ folder containing main.py and imgenius/.')
        self._refresh_restore_button()
        if self._selected_zip_path and self.worker is None:
            self.select_zip(self._selected_zip_path)

    def _refresh_restore_button(self):
        try:
            found = list_backups(self.install_field.text().strip())
            self.restore_button.setEnabled(bool(found))
        except PatchError:
            self.restore_button.setEnabled(False)

    def browse_installation(self):
        current = self.install_field.text().strip() or str(Path.home())
        chosen = QFileDialog.getExistingDirectory(self, 'Select IMGenius application folder', current)
        if chosen:
            self.install_field.setText(chosen)
            self._location_edited()

    def browse_zip(self):
        selected, _ = QFileDialog.getOpenFileName(self, 'Choose IMGenius patch ZIP', str(Path.home() / 'Downloads'), 'ZIP patches (*.zip)')
        if selected:
            self.select_zip(selected)

    def select_zip(self, name: str):
        self._selected_zip_path = name
        self.plan = None
        self.table.setRowCount(0)
        self.selected_zip.setText(str(Path(name).name))
        self.summary.setText('Checking patch…')
        self.apply_button.setEnabled(False)
        self.bar.setValue(0)
        try:
            plan = make_plan(name, self.install_field.text().strip())
        except PatchError as exc:
            self.summary.setText('Patch cannot be applied.')
            self.status.setText(str(exc))
            return
        self.plan = plan
        self.summary.setText(f'{plan.name}  •  {len(plan.files)} files  •  {plan.changed_count} replacements  •  {plan.new_count} additions')
        for entry in plan.files:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(entry.operation))
            self.table.setItem(row, 1, QTableWidgetItem(entry.path))
            self.table.setItem(row, 2, QTableWidgetItem(f'{entry.size / 1024:,.1f} KB'))
        self.status.setText('Review the file list. Only application source files will be updated.')
        self.apply_button.setEnabled(True)

    def _set_busy(self, busy):
        self.install_field.setEnabled(not busy)
        self.folder_button.setEnabled(not busy)
        self.browse_button.setEnabled(not busy)
        self.apply_button.setEnabled(not busy and self.plan is not None)
        self.restore_button.setEnabled(not busy and self.restore_button.isEnabled())
        self.dropzone.setEnabled(not busy)

    def install_patch(self):
        if not self.plan:
            return
        answer = QMessageBox.question(
            self, 'Apply IMGenius patch?',
            f'Apply {len(self.plan.files)} files to:\n{self.plan.installation}\n\n'
            'Close the main IMGenius application before continuing.\n'
            'A local backup will be created automatically.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._set_busy(True)
        self.status.setText('Backing up current files and preparing patch…')
        self.bar.setValue(0)
        worker = InstallWorker(self.plan)
        self.worker = worker
        worker.progress.connect(self._progress)
        worker.completed.connect(self._installed)
        worker.problem.connect(self._failure)
        worker.finished.connect(self._worker_finished)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _worker_finished(self):
        self.worker = None

    def _progress(self, pos, count, message):
        self.bar.setValue(min(100, round(100 * pos / max(1, count))))
        self.status.setText(message)

    def _installed(self, backup):
        self.last_backup = backup
        self.bar.setValue(100)
        self.status.setText('Patch applied successfully. Reopen IMGenius to use the update.')
        self._set_busy(False)
        self._refresh_restore_button()
        QMessageBox.information(self, 'Patch installed', 'IMGenius was updated successfully.\n\nBackup location:\n' + backup)

    def _failure(self, details):
        self.bar.setValue(0)
        self.status.setText('Patch failed: ' + details)
        self._set_busy(False)
        self._refresh_restore_button()
        QMessageBox.critical(self, 'Unable to install patch', details)

    def restore_last(self):
        try:
            backups = list_backups(self.install_field.text().strip())
        except PatchError as exc:
            self.status.setText(str(exc))
            return
        if not backups:
            self.status.setText('No backup available for this installation.')
            self._refresh_restore_button()
            return
        backup, meta = backups[0]
        answer = QMessageBox.warning(
            self, 'Restore previous files?',
            f'Restore the source files from {meta.get("name", "last patch")}?\n\n'
            'Close IMGenius first. This will undo the files changed by that patch.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._set_busy(True)
        self.status.setText('Restoring previous application files…')
        worker = RestoreWorker(self.install_field.text().strip(), str(backup))
        self.worker = worker
        worker.completed.connect(self._restored)
        worker.problem.connect(self._failure)
        worker.finished.connect(self._worker_finished)
        worker.finished.connect(worker.deleteLater)
        worker.start()

    def _restored(self):
        self.bar.setValue(0)
        self._set_busy(False)
        self._refresh_restore_button()
        self.status.setText('Previous files restored. Restart IMGenius.')
        if self._selected_zip_path and self.worker is None:
            self.select_zip(self._selected_zip_path)
        QMessageBox.information(self, 'Restored', 'Previous application files restored successfully.')

    def dragEnterEvent(self, event):
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if len(urls) == 1 and urls[0].isLocalFile() and urls[0].toLocalFile().lower().endswith('.zip'):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls() if event.mimeData().hasUrls() else []
        if len(urls) == 1 and urls[0].isLocalFile() and urls[0].toLocalFile().lower().endswith('.zip'):
            self.select_zip(urls[0].toLocalFile())
            event.acceptProposedAction()
        else:
            event.ignore()


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(STYLESHEET)
    assets = Path(__file__).resolve().parents[2] / 'assets' / 'IMGenius.png'
    if assets.exists():
        app.setWindowIcon(QIcon(str(assets)))
    window = PatchWindow()
    if len(sys.argv) > 1:
        window.select_zip(sys.argv[1])
    window.show()
    return app.exec()
