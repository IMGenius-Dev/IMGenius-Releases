"""Anonymous, read-only GitHub Releases update checks for IMGenius desktop.

Private development repositories are intentionally never queried from clients: the
public distribution repository is the only source, and no GitHub tokens are used.
The updater *notifies* users; it never downloads or runs unverified binaries.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import re
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from imgenius import __version__

PUBLIC_RELEASE_REPO = 'IMGenius-Dev/IMGenius-Releases'
RELEASES_URL = f'https://api.github.com/repos/{PUBLIC_RELEASE_REPO}/releases?per_page=15'
VERSION_RE = re.compile(r'^v?(\d+)\.(\d+)(?:\.(\d+))?(?:[-.]?(alpha|beta|rc)[.-]?(\d+)?)?$', re.I)


@dataclass(frozen=True)
class UpdateResult:
    state: str  # available / current / unavailable
    tag: str = ''
    url: str = ''
    detail: str = ''


def version_key(version: str):
    """Semantic subset sufficient for v0.7.1 and v0.8.0-beta.1 tags."""
    match = VERSION_RE.fullmatch(str(version).strip())
    if not match:
        return None
    major, minor, patch, stage, number = match.groups()
    # Alpha < beta < release candidate < stable.
    stage_rank = {'alpha': 0, 'beta': 1, 'rc': 2, None: 3}[stage.lower() if stage else None]
    return (int(major), int(minor), int(patch or 0), stage_rank, int(number or 0))


def latest_release(payload, *, current=__version__, channel='beta') -> UpdateResult:
    """Choose only greater, tagged, published releases from the official feed."""
    own = version_key(current)
    if own is None or not isinstance(payload, list):
        return UpdateResult('unavailable', detail='Invalid release metadata')
    choices = []
    for entry in payload:
        if not isinstance(entry, dict) or entry.get('draft'):
            continue
        if channel == 'stable' and entry.get('prerelease'):
            continue
        tag = entry.get('tag_name')
        if not isinstance(tag, str):
            continue
        version = version_key(tag)
        if version is None or version <= own:
            continue
        # Construct the URL locally from the validated version tag; do not
        # follow attacker-supplied URLs embedded in release JSON.
        choices.append((version, tag))
    if not choices:
        return UpdateResult('current', detail='No newer public release')
    _, tag = max(choices)
    return UpdateResult('available', tag=tag,
                        url=f'https://github.com/{PUBLIC_RELEASE_REPO}/releases/tag/{tag}',
                        detail=f'IMGenius {tag} is available')


def check_github_updates(*, current=__version__, channel='beta', timeout=3.0) -> UpdateResult:
    """Fail open on offline, rate-limit, missing public repo and invalid JSON."""
    try:
        request = Request(RELEASES_URL, headers={
            'Accept': 'application/vnd.github+json',
            'User-Agent': f'IMGenius/{current}',
        })
        with urlopen(request, timeout=timeout) as response:
            if response.status != 200:
                return UpdateResult('unavailable', detail='GitHub returned an unexpected response')
            # Bound response sizes; release bodies need not be downloaded.
            data = response.read(512 * 1024 + 1)
            if len(data) > 512 * 1024:
                return UpdateResult('unavailable', detail='GitHub release feed too large')
            payload = json.loads(data.decode('utf-8'))
        return latest_release(payload, current=current, channel=channel)
    except (HTTPError, URLError, OSError, ValueError, UnicodeError, TimeoutError):
        return UpdateResult('unavailable', detail='GitHub releases unavailable; continuing offline')
