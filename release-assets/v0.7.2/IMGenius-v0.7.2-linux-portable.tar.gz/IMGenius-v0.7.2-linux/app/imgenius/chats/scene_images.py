"""Build an isolated visual-prompt request from a saved conversation.

Do not place these instructions into the roleplay or persist them as chat text.
"""
from __future__ import annotations
import re

SCENE_SYSTEM = (
    'You write visual prompts for SDXL/Illustrious image generation. '
    'Using the conversation, describe ONE current scene in a single concise '
    'positive prompt. Include visible characters, appearance, clothing, pose, '
    'setting, lighting, camera composition, and art style only when grounded in '
    'the conversation or character profile. Do not invent nudity, ages, or explicit '
    'details. Do not include dialogue, markdown, explanations, negative prompts, '
    'or meta-instructions. Output only the image prompt.'
)


def scene_prompt_messages(character, messages, *, max_messages=24, max_chars=12000):
    """Bound Ollama context while retaining speaker labels and scene continuity."""
    lines = []
    for message in messages[-max_messages:]:
        if message.get('role') not in ('assistant', 'user'):
            continue
        content = str(message.get('content') or '').strip()
        if content:
            lines.append(f"{message['role']}: {content[:1600]}")
    transcript = '\n'.join(lines)[-max_chars:]
    if not transcript:
        raise ValueError('Start a conversation before generating a scene image.')
    profile = '\n'.join(str(character.get(field) or '')[:1000] for field in
                         ('name', 'description', 'personality', 'scenario'))
    return [{'role': 'user', 'content': 'Character context:\n' + profile +
             '\nConversation (most recent last):\n' + transcript +
             '\nWrite the image prompt for the latest visually depictable scene.'}]


def clean_scene_prompt(response):
    result = str(response or '').strip()
    result = re.sub(r'^```(?:[a-zA-Z]+)?\s*|\s*```$', '', result).strip()
    result = re.sub(r'^(?:positive\s+)?(?:image\s+)?prompt\s*:\s*', '', result, flags=re.I)
    result = result.strip(' \t\r\n"')[:3500]
    if not result:
        raise ValueError('The LLM did not produce an image prompt.')
    return result
