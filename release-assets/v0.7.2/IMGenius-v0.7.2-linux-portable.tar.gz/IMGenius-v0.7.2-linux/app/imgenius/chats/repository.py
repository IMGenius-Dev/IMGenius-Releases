"""SQLite conversation/message repository and migrations."""
import sqlite3
from datetime import datetime, timezone
from imgenius.shared.paths import DATA_DIR
from imgenius.shared.text import safe_text

class ChatStore:
    def __init__(self, db_path=str(DATA_DIR / 'chats.db')):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize()

    def _initialize(self):
        self.conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS chats (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                character_id INTEGER,
                title TEXT,
                model TEXT,
                summary TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            '''
        )
        self.conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            '''
        )
        self.conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS chat_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                prompt TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
            '''
        )
        # Upgrade existing chat databases created by older versions of IMGenius.
        # CREATE TABLE IF NOT EXISTS does not add columns to existing tables.
        columns = {row[1] for row in self.conn.execute('PRAGMA table_info(chats)')}
        if 'summary' not in columns:
            self.conn.execute("ALTER TABLE chats ADD COLUMN summary TEXT DEFAULT ''")
        self.conn.commit()

    def create_chat(self, character_id, title, model, summary='', first_message=''):
        """Create a conversation with an optional, persisted assistant greeting.

        The greeting is inserted in the same transaction as the chat, so it
        appears once, even if the conversation is reopened later.
        """
        created = datetime.now(timezone.utc).isoformat()
        with self.conn:
            cursor = self.conn.execute(
                'INSERT INTO chats (character_id, title, model, summary, created_at, updated_at) '
                'VALUES (?, ?, ?, ?, ?, ?)',
                (character_id, title, model, summary, created, created),
            )
            chat_id = cursor.lastrowid
            if safe_text(first_message):
                self.conn.execute(
                    'INSERT INTO messages (chat_id, role, content, created_at) VALUES (?, ?, ?, ?)',
                    (chat_id, 'assistant', str(first_message), created),
                )
        return chat_id

    def delete_chat(self, chat_id):
        """Remove one conversation and only its messages, in one transaction.

        Returns the number of conversations deleted (0 or 1). No other
        character, chat, image, or story records are touched.
        """
        with self.conn:
            exists = self.conn.execute(
                'SELECT 1 FROM chats WHERE id = ?', (chat_id,)
            ).fetchone()
            if not exists:
                return 0
            self.conn.execute('DELETE FROM messages WHERE chat_id = ?', (chat_id,))
            self.conn.execute('DELETE FROM chat_images WHERE chat_id = ?', (chat_id,))
            self.conn.execute('DELETE FROM chats WHERE id = ?', (chat_id,))
        return 1

    def rename_character_chats(self, character_id, old_name, new_name):
        """Refresh only default chat titles when a character is renamed.

        Custom titles and historical conversation text are left unchanged.
        Other profile changes already flow through the character_id link.
        """
        old_name, new_name = safe_text(old_name), safe_text(new_name)
        if not old_name or not new_name or old_name == new_name:
            return 0
        with self.conn:
            cursor = self.conn.execute(
                'UPDATE chats SET title = ? WHERE character_id = ? AND title = ?',
                (f'{new_name} chat', character_id, f'{old_name} chat'),
            )
        return cursor.rowcount

    def add_message(self, chat_id, role, content):
        self.conn.execute(
            'INSERT INTO messages (chat_id, role, content, created_at) VALUES (?, ?, ?, ?)',
            (chat_id, role, content, datetime.now(timezone.utc).isoformat()),
        )
        self.conn.execute(
            'UPDATE chats SET updated_at = ? WHERE id = ?',
            (datetime.now(timezone.utc).isoformat(), chat_id),
        )
        self.conn.commit()

    def delete_message(self, chat_id, message_id):
        self.conn.execute('DELETE FROM messages WHERE id = ? AND chat_id = ?', (message_id, chat_id))
        self.conn.execute('UPDATE chats SET updated_at = ? WHERE id = ?', (datetime.now(timezone.utc).isoformat(), chat_id))
        self.conn.commit()

    def truncate_messages(self, chat_id, message_id, include_selected=False):
        """Trim one conversation after a chosen message (or including it).

        Only replace old history when new response text exists, including
        a partially generated response intentionally stopped by the user.
        """
        comparator = '>=' if include_selected else '>'
        with self.conn:
            self.conn.execute(
                f'DELETE FROM messages WHERE chat_id = ? AND id {comparator} ?',
                (chat_id, message_id),
            )
            self.conn.execute(
                'UPDATE chats SET updated_at = ? WHERE id = ?',
                (datetime.now(timezone.utc).isoformat(), chat_id),
            )

    def add_chat_image(self, chat_id, filename, prompt):
        """Attach a generated gallery image to a chat without inventing a message."""
        from pathlib import Path
        name = str(filename)
        if not name or Path(name).name != name or Path(name).suffix.lower() not in ('.png', '.jpg', '.jpeg', '.webp'):
            raise ValueError('Chat image must reference a gallery image filename.')
        if self.get_chat(chat_id) is None:
            raise ValueError('Chat no longer exists.')
        with self.conn:
            cursor = self.conn.execute(
                'INSERT INTO chat_images (chat_id, filename, prompt, created_at) VALUES (?, ?, ?, ?)',
                (chat_id, name, str(prompt), datetime.now(timezone.utc).isoformat()),
            )
            self.conn.execute('UPDATE chats SET updated_at = ? WHERE id = ?',
                              (datetime.now(timezone.utc).isoformat(), chat_id))
        return cursor.lastrowid

    def get_chat_images(self, chat_id):
        rows = self.conn.execute(
            'SELECT id, filename, prompt, created_at FROM chat_images WHERE chat_id = ? ORDER BY created_at, id',
            (chat_id,),
        ).fetchall()
        return [dict(zip(('id', 'filename', 'prompt', 'created_at'), row)) for row in rows]

    def update_message(self, chat_id, message_id, content):
        self.conn.execute(
            'UPDATE messages SET content = ? WHERE id = ? AND chat_id = ?',
            (content, message_id, chat_id),
        )
        self.conn.execute('UPDATE chats SET updated_at = ? WHERE id = ?', (datetime.now(timezone.utc).isoformat(), chat_id))
        self.conn.commit()

    def get_messages(self, chat_id):
        rows = self.conn.execute(
            'SELECT id, role, content, created_at FROM messages WHERE chat_id = ? ORDER BY id ASC',
            (chat_id,),
        ).fetchall()
        return [
            {'id': row[0], 'role': row[1], 'content': row[2], 'created_at': row[3]}
            for row in rows
        ]

    def get_recent_context(self, chat_id, max_messages=18):
        messages = self.get_messages(chat_id)
        return messages[-max_messages:] if len(messages) > max_messages else messages

    def get_last_assistant_message(self, chat_id):
        row = self.conn.execute(
            'SELECT id, role, content, created_at FROM messages WHERE chat_id = ? AND role = "assistant" ORDER BY id DESC LIMIT 1',
            (chat_id,),
        ).fetchone()
        if row is None:
            return None
        return {'id': row[0], 'role': row[1], 'content': row[2], 'created_at': row[3]}

    def get_last_user_message(self, chat_id):
        row = self.conn.execute(
            'SELECT id, role, content, created_at FROM messages WHERE chat_id = ? AND role = "user" ORDER BY id DESC LIMIT 1',
            (chat_id,),
        ).fetchone()
        if row is None:
            return None
        return {'id': row[0], 'role': row[1], 'content': row[2], 'created_at': row[3]}

    def list_chats(self):
        rows = self.conn.execute(
            'SELECT id, character_id, title, model, summary, created_at, updated_at FROM chats ORDER BY updated_at DESC'
        ).fetchall()
        columns = ['id', 'character_id', 'title', 'model', 'summary', 'created_at', 'updated_at']
        chats = [dict(zip(columns, row)) for row in rows]
        for chat in chats:
            chat['message_count'] = self.message_count(chat['id'])
        return chats

    def message_count(self, chat_id):
        count = self.conn.execute('SELECT COUNT(*) FROM messages WHERE chat_id = ?', (chat_id,)).fetchone()[0]
        return count

    def get_chat(self, chat_id):
        row = self.conn.execute(
            'SELECT id, character_id, title, model, summary, created_at, updated_at FROM chats WHERE id = ?',
            (chat_id,),
        ).fetchone()
        if row is None:
            return None
        columns = ['id', 'character_id', 'title', 'model', 'summary', 'created_at', 'updated_at']
        data = dict(zip(columns, row))
        data['message_count'] = self.message_count(chat_id)
        return data
