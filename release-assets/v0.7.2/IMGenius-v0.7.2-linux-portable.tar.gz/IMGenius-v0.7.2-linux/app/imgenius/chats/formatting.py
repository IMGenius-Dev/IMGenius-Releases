"""Safe message markup for the IMGenius chat view.

Only a small, controlled HTML subset is supported. The model's text must
never be passed directly as HTML to QLabel/QTextDocument, since a generated
<img> or <a href> could otherwise reference an external/local resource.
"""

from html import escape
from html.parser import HTMLParser
import re

# Asterisks have two independent meanings in AI messages:
#   *action*      -> muted, bold roleplay action
#   **emphasis**  -> strong emphasis in the normal foreground color
# Keep this parser separate from HTMLParser so all user/model text is escaped.
_MARKUP = re.compile(
    r'(?<![\\*])(?P<marker>\*\*|\*)(?![\s*])(?P<body>.+?)(?<![\s*])(?P=marker)(?!\*)',
    re.DOTALL,
)
_ACTION_STYLE = 'font-weight:700; color:#b9c4d4;'
_ALLOWED_INLINE = {'b', 'strong', 'i', 'em', 'u', 's', 'code'}
_ALLOWED_BLOCKS = {'p', 'blockquote', 'ul', 'ol', 'li'}


def _style_actions(text):
    pieces = []
    last = 0
    for match in _MARKUP.finditer(text):
        pieces.append(escape(text[last:match.start()]).replace('\n', '<br/>'))
        body = escape(match.group('body')).replace('\n', '<br/>')
        if match.group('marker') == '**':
            # <strong> inherits the active Qt/theme foreground color.
            pieces.append(f'<strong>{body}</strong>')
        else:
            pieces.append(f'<span style="{_ACTION_STYLE}">{body}</span>')
        last = match.end()
    pieces.append(escape(text[last:]).replace('\n', '<br/>'))
    return ''.join(pieces)


class _ChatMarkup(HTMLParser):
    """Sanitize all markup; preserve a tiny HTML vocabulary without attributes."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.open_tags = []

    def handle_data(self, data):
        # HTML pretty-printing often places a newline between two <p> tags.
        # Do not turn that separator into a second blank paragraph.
        if (not data.strip() and self.parts and
                self.parts[-1] in ('</p>', '</blockquote>', '</li>')):
            return
        self.parts.append(_style_actions(data))

    def _opening(self, tag):
        if tag == 'q':
            return '<span style="color:#d5ddea; font-style:italic;">“'
        if tag == 'p':
            return '<p style="margin-top:0px; margin-bottom:9px;">'
        if tag == 'blockquote':
            return '<blockquote style="margin-left:14px; margin-top:5px; margin-bottom:5px; color:#c3cedc;">'
        return f'<{tag}>'

    def _closing(self, tag):
        if tag == 'q':
            return '”</span>'
        return f'</{tag}>'

    def handle_starttag(self, tag, attrs):
        if tag == 'br':
            self.parts.append('<br/>')
        elif tag in _ALLOWED_INLINE or tag in _ALLOWED_BLOCKS or tag == 'q':
            # Attributes from generated text are deliberately discarded.
            self.parts.append(self._opening(tag))
            self.open_tags.append(tag)
        else:
            # Disallowed HTML is shown as text, never interpreted as markup.
            self.parts.append(escape(self.get_starttag_text() or f'<{tag}>'))

    def handle_startendtag(self, tag, attrs):
        if tag == 'br':
            self.parts.append('<br/>')
        elif tag in _ALLOWED_INLINE or tag in _ALLOWED_BLOCKS or tag == 'q':
            self.parts.extend((self._opening(tag), self._closing(tag)))
        else:
            self.parts.append(escape(self.get_starttag_text() or f'<{tag}/>'))

    def handle_endtag(self, tag):
        if tag not in self.open_tags:
            if tag != 'br':
                self.parts.append(escape(f'</{tag}>'))
            return
        # Recover from malformed/nested markup while keeping valid Qt HTML.
        while self.open_tags:
            closing = self.open_tags.pop()
            self.parts.append(self._closing(closing))
            if closing == tag:
                break

    def handle_entityref(self, name):
        # HTMLParser with convert_charrefs=True usually handles this already.
        self.handle_data('&' + name + ';')

    def handle_charref(self, name):
        self.handle_data('&#' + name + ';')

    def get_html(self):
        while self.open_tags:
            self.parts.append(self._closing(self.open_tags.pop()))
        return ''.join(self.parts)


def format_chat_html(text, role='assistant'):
    """Render roleplay actions and allowlisted HTML for both chat roles.

    Never pass raw user or model HTML to Qt: all markup is sanitized.
    """
    text = str(text or '')
    parser = _ChatMarkup()
    parser.feed(text)
    parser.close()
    return parser.get_html()
