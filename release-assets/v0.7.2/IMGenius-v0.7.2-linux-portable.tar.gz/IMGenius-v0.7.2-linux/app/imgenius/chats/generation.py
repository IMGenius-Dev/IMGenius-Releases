"""Save completed or user-stopped chat replies without losing prior history."""
from __future__ import annotations


def save_assistant_reply(store, chat_id, text, *, replace_message_id=None,
                         continue_after_message_id=None):
    """Persist received assistant text, complete or partial.

    Empty replies must not delete existing history, especially on regenerate.
    This helper runs on the UI thread after the worker finishes/stops.
    """
    if not str(text or '').strip():
        return False
    if replace_message_id is not None:
        store.truncate_messages(chat_id, replace_message_id, include_selected=True)
    elif continue_after_message_id is not None:
        store.truncate_messages(chat_id, continue_after_message_id)
    store.add_message(chat_id, 'assistant', str(text))
    return True
