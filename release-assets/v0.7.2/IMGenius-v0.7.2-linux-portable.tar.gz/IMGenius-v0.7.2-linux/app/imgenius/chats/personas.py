"""Persona persistence and management."""
import json
import uuid
from pathlib import Path
from imgenius.shared.paths import PERSONA_PATH
from imgenius.shared.text import safe_text

class PersonaStore:
    def __init__(self, path=PERSONA_PATH):
        self.path = Path(path)
        self.personas = []
        self._load()

    def _default_personas(self):
        return [
            {
                'id': 'default-user',
                'name': 'Default User',
                'user_name': 'User',
                'description': 'Neutral default persona.',
                'prompt': 'Respond to {{user}} naturally and treat them as the current user speaking to {{char}}.',
            },
            {
                'id': 'supportive-user',
                'name': 'Supportive Friend',
                'user_name': 'Alex',
                'description': 'Casual, friendly, encouraging user persona.',
                'prompt': '{{user}} is friendly, curious, and conversational. Keep interactions warm and natural with {{char}}.',
            },
        ]

    def _load(self):
        if self.path.exists():
            try:
                payload = json.loads(self.path.read_text(encoding='utf-8'))
                if isinstance(payload, list):
                    self.personas = payload
                else:
                    self.personas = self._default_personas()
            except (OSError, json.JSONDecodeError):
                self.personas = self._default_personas()
        else:
            self.personas = self._default_personas()
            self.save()
        if not self.personas:
            self.personas = self._default_personas()
            self.save()

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.personas, indent=2), encoding='utf-8')

    def list_personas(self):
        return list(self.personas)

    def get_persona(self, persona_id):
        for persona in self.personas:
            if persona.get('id') == persona_id:
                return dict(persona)
        return None

    def save_persona(self, persona):
        payload = {
            'id': safe_text(persona.get('id')) or uuid.uuid4().hex,
            'name': safe_text(persona.get('name'), 'New Persona') or 'New Persona',
            'user_name': safe_text(persona.get('user_name'), 'User') or 'User',
            'description': safe_text(persona.get('description')),
            'prompt': safe_text(persona.get('prompt')),
        }
        for idx, current in enumerate(self.personas):
            if current.get('id') == payload['id']:
                self.personas[idx] = payload
                self.save()
                return payload['id']
        self.personas.append(payload)
        self.save()
        return payload['id']

    def delete_persona(self, persona_id):
        self.personas = [persona for persona in self.personas if persona.get('id') != persona_id]
        if not self.personas:
            self.personas = self._default_personas()
        self.save()
