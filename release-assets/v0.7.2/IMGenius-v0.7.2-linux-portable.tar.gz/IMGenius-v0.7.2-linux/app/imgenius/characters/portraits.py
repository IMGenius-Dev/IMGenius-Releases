"""Generate/export character card artwork and maintain local portraits."""
import os
import uuid
from pathlib import Path
from textwrap import wrap
from PIL import Image, ImageDraw, ImageFont
from imgenius.shared.paths import CARD_DIR
from imgenius.shared.text import safe_text
from imgenius.characters.repository import CharacterStore
from imgenius.characters.prompts import DEFAULT_SYSTEM_PROMPT, default_first_message

def select_font(size, bold=False):
    candidates = []
    if os.name == 'nt':
        candidates.extend([
            r'C:\Windows\Fonts\arialbd.ttf' if bold else r'C:\Windows\Fonts\arial.ttf',
            r'C:\Windows\Fonts\verdanab.ttf' if bold else r'C:\Windows\Fonts\verdana.ttf',
            r'C:\Windows\Fonts\tahoma.ttf',
        ])
    else:
        candidates.extend([
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
            '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
        ])
    for path in candidates:
        if path and os.path.exists(path):
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()

def generate_character_card_png(character, output_path=None):
    data = character or {}
    name = safe_text(data.get('name'), 'Unnamed Character') or 'Unnamed Character'
    gender = safe_text(data.get('gender'), 'not specified') or 'not specified'
    personality = safe_text(data.get('personality'), 'Thoughtful and warm') or 'Thoughtful and warm'
    scenario = safe_text(data.get('scenario'), 'General conversation') or 'General conversation'
    prompt_text = safe_text(data.get('system_prompt'), DEFAULT_SYSTEM_PROMPT) or 'Helpful and in character.'

    width, height = 900, 1200
    image = Image.new('RGB', (width, height), color=(10, 15, 25))
    draw = ImageDraw.Draw(image)

    draw.rounded_rectangle((20, 20, width - 20, height - 20), radius=30, fill=(16, 23, 42), outline=(56, 189, 248), width=5)
    draw.rounded_rectangle((55, 55, width - 55, 260), radius=26, fill=(20, 35, 55))
    avatar_center = (160, 155)
    avatar_radius = 82
    draw.ellipse((avatar_center[0] - avatar_radius, avatar_center[1] - avatar_radius, avatar_center[0] + avatar_radius, avatar_center[1] + avatar_radius), fill=(56, 189, 248))
    draw.text((285, 115), name[:20].upper(), fill=(255, 255, 255), font=select_font(44, bold=True))
    draw.text((285, 170), gender.upper(), fill=(148, 163, 184), font=select_font(22))

    labels = [
        ('PERSONALITY', personality[:120]),
        ('SCENARIO', scenario[:120]),
        ('PROMPT', prompt_text[:150]),
    ]
    start_y = 310
    for label, value in labels:
        draw.text((70, start_y), label, fill=(56, 189, 248), font=select_font(20, bold=True))
        wrapped = wrap(value, width=28)
        for idx, line in enumerate(wrapped[:4]):
            draw.text((70, start_y + 28 + idx * 28), line, fill=(226, 232, 240), font=select_font(22))
        start_y += 170

    draw.text((70, 1110), 'IMGENIUS CHARACTER CARD', fill=(148, 163, 184), font=select_font(18))

    save_to = output_path if output_path is not None else CARD_DIR / f"{(name or 'character').lower().replace(' ', '_')}_{uuid.uuid4().hex[:8]}.png"
    if isinstance(save_to, str):
        save_to = Path(save_to)
    save_to.parent.mkdir(parents=True, exist_ok=True)
    image.save(save_to, format='PNG')
    return save_to

def save_default_characters():
    """Do not distribute or silently install fictional cards in public releases.

    Previously installed defaults remain in each user's personal database.
    """
    return None


def cleanup_example_characters():
    store = CharacterStore()
    removable = {'test card', 'metadata test'}
    for character in store.list_characters():
        if safe_text(character.get('name')).casefold() in removable:
            store.delete_character(character['id'])

def resolve_character_image(character):
    """Resolve portraits, including a bundled replacement for old demo avatars.

    Only the known, auto-generated placeholders for Nova and Atlas are upgraded.
    User-supplied portrait paths are always given priority.
    """
    raw = safe_text((character or {}).get('card_image'))
    name = safe_text((character or {}).get('name')).casefold()
    basename = Path(raw).name if raw else ''
    generated_placeholder = basename.startswith('auto_avatar_') and basename.endswith('.png')
    if name in ('nova', 'atlas') and (not raw or generated_placeholder):
        sample = CARD_DIR / f'{name}.png'
        if sample.is_file():
            return sample
    if not raw:
        return None
    original = Path(raw)
    for candidate in (original, CARD_DIR / original.name):
        if candidate.is_file():
            return candidate
    return None

def make_placeholder_portrait(character, destination=None):
    """Create a recognizable offline initials portrait; never replaces uploaded art."""
    import hashlib
    character_id = int(character.get('id') or 0)
    name = safe_text(character.get('name')) or 'Character'
    destination = Path(destination) if destination else CARD_DIR / f'auto_avatar_{character_id}.png'
    if destination.is_file():
        return destination
    seed = hashlib.sha256(name.encode('utf-8')).digest()
    rgb = tuple(38 + byte // 4 for byte in seed[:3])
    canvas = Image.new('RGB', (600, 600), rgb)
    drawing = ImageDraw.Draw(canvas)
    for y in range(600):
        factor = y / 600
        shade = tuple(int(min(255, c * (1.25 - factor * .45))) for c in rgb)
        drawing.line((0, y, 600, y), fill=shade)
    drawing.ellipse((125, 75, 475, 425), fill=(70, 82, 112), outline=(126, 159, 201), width=7)
    initials = ''.join(word[0].upper() for word in name.split()[:2]) or '?'
    font = select_font(154, bold=True)
    bb = drawing.textbbox((0, 0), initials, font=font)
    drawing.text(((600 - (bb[2] - bb[0])) / 2, 252 - (bb[3] - bb[1]) / 2 - bb[1]),
                 initials, font=font, fill=(231, 242, 255))
    drawing.rounded_rectangle((55, 482, 545, 558), 20, fill=(20, 26, 44))
    name_font = select_font(30, bold=True)
    display_name = name[:22]
    bb = drawing.textbbox((0, 0), display_name, font=name_font)
    drawing.text(((600 - (bb[2] - bb[0])) / 2, 503), display_name,
                 font=name_font, fill=(241, 246, 255))
    destination.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(destination, format='PNG')
    return destination

def ensure_default_character_images():
    """Attach real sample art to known defaults, preserving custom character art.

    Previous releases assigned valid auto_avatar_*.png initials pictures to
    bundled example characters, which prevented later real portraits loading.
    This narrowly upgrades those placeholders, without modifying user art.
    """
    store = CharacterStore()
    for current in store.list_characters():
        raw = safe_text(current.get('card_image'))
        name = safe_text(current.get('name')).casefold()
        basename = Path(raw).name if raw else ''
        sample = CARD_DIR / f'{name}.png' if name in ('nova', 'atlas') else None
        # Existing personal legacy portraits may be reused, but are never shipped.
        is_automatic = basename.startswith('auto_avatar_') and basename.endswith('.png')
        if sample is not None and sample.is_file() and (not raw or is_automatic):
            if raw != str(sample):
                store.conn.execute('UPDATE characters SET card_image = ? WHERE id = ?',
                                   (str(sample), current['id']))
            continue
        if resolve_character_image(current):
            continue
        portrait = make_placeholder_portrait(current)
        store.conn.execute('UPDATE characters SET card_image = ? WHERE id = ?',
                           (str(portrait), current['id']))
    store.conn.commit()

def export_character_card(character):
    if not character:
        return None
    raw_path = safe_text(character.get('card_image'))
    if raw_path:
        card_path = Path(raw_path)
        if card_path.is_file():
            return card_path
        fallback = CARD_DIR / card_path.name
        if fallback.is_file():
            return fallback
    return generate_character_card_png(character)
