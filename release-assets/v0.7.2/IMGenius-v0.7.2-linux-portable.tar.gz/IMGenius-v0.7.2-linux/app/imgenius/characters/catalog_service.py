"""Paged Chub catalog previews from the public TelegAI-hosted catalog service.

This is an independently hosted, undocumented feed, not Chub's official API.
The request shape was observed in a user-supplied Firefox network capture.
It returns public *previews*; complete character cards still come from Chub.

Batch size remains the observed 80 records. The UI displays 12 records per
page and can span batch boundaries. An in-memory bounded cache avoids fetching
an entire 80-record response for each 12-card view. No browser cookies, auth
headers, or user data are ever sent to the provider.
"""
from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from threading import RLock
from time import monotonic
from urllib.parse import urlencode, urljoin
import json

import requests

from imgenius.characters.chub import (
    ChubImportError, DOWNLOAD_HOSTS, MAX_THUMBNAIL_SIZE,
    _clean_host, _normalize_catalog_tags, _stream_https,
)
from imgenius.characters.telegai_feed import clean_feed_record

CATALOG_ENDPOINT = (
    'https://ywqesktuqvgsmrgraors.supabase.co/functions/v1/fetch-all-service'
)
CATALOG_HOST = 'ywqesktuqvgsmrgraors.supabase.co'
DISPLAY_PAGE_SIZE = 12
BATCH_SIZE = 80
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
MAX_DISPLAY_PAGE = 10000
MAX_CACHED_BATCHES = 12
CACHE_SECONDS = 300
# Only created_at is confirmed by the captured request. Other sorting fields
# are best-effort and may change if the third-party service changes its API.
SORT_FIELDS = {
    'Newest': ('created_at', 'false'),
    'Popular': ('starCount', 'false'),
    'Recently updated': ('updated_at', 'false'),
}


def build_catalog_url(*, batch=1, mature=False, tags='', exclude_tags='',
                      tag_match='Any', sort='Newest'):
    """Build bounded, URL-encoded GET parameters matching the observed feed."""
    if isinstance(batch, bool) or not isinstance(batch, int) or not 1 <= batch <= 2000:
        raise ChubImportError('Catalog batch number is out of range.')
    if type(mature) is not bool:
        raise ChubImportError('Invalid mature browsing setting.')
    if sort not in SORT_FIELDS:
        raise ChubImportError('Unsupported catalog sort selection.')
    if tag_match not in {'Any', 'All'}:
        raise ChubImportError('Choose Any or All for matching tags.')
    selected = _normalize_catalog_tags(tags)
    excluded = _normalize_catalog_tags(exclude_tags)
    if set(s.casefold() for s in selected).intersection(s.casefold() for s in excluded):
        raise ChubImportError('A tag cannot be included and excluded at the same time.')
    sort_field, asc = SORT_FIELDS[sort]
    params = {
        'asc': asc,
        'exclude_tags': ','.join(excluded),
        'first': str(BATCH_SIZE),
        'include_forks': 'false',
        'inclusive_or': 'true' if tag_match == 'Any' else 'false',
        # The two keys are present in the observed URL. `nsfl` is preserved for
        # compatibility, not assumed to be a substitute for `nsfw`.
        'nsfl': 'true',
        'nsfw': str(mature).lower(),
        'page': str(batch),
        'require_custom_prompt': 'false',
        'sort': sort_field,
        'tags': ','.join(selected),
        'venus': 'true',
    }
    return CATALOG_ENDPOINT + '?' + urlencode(params)


def _read_public_json(session, url, *, cancelled=None):
    headers = {
        'User-Agent': 'IMGenius/0.6 Public Character Catalog',
        'Accept': 'application/json',
        'Origin': 'https://www.telegai.com',
        'Referer': 'https://www.telegai.com/',
    }
    for _ in range(4):
        host, parsed = _clean_host(url)
        if host != CATALOG_HOST or parsed.path != '/functions/v1/fetch-all-service':
            raise ChubImportError('Catalog request redirected outside its permitted endpoint.')
        if cancelled is not None and cancelled.is_set():
            raise ChubImportError('Catalog request cancelled.')
        try:
            response = session.get(url, headers=headers, stream=True,
                                   allow_redirects=False, timeout=(8, 35))
        except requests.RequestException as exc:
            raise ChubImportError('Could not contact the public catalog service.') from exc
        try:
            status = response.status_code
            if status in (301, 302, 303, 307, 308):
                location = response.headers.get('Location', '')
                if not location:
                    raise ChubImportError('The public catalog returned a redirect without a destination.')
                url = urljoin(url, location)
                continue
            if status in (401, 403, 451):
                raise ChubImportError(
                    f'The public catalog denied access (HTTP {status}); '
                    'IMGenius does not bypass provider access rules.'
                )
            if status == 429:
                raise ChubImportError('The catalog is rate-limiting requests (HTTP 429). Try again later.')
            if status != 200:
                raise ChubImportError(f'The catalog returned HTTP {status}.')
            kind = response.headers.get('Content-Type', '').lower().split(';')[0].strip()
            if kind and kind not in ('application/json', 'application/x-json', 'text/json'):
                raise ChubImportError(f'The catalog returned {kind}, not JSON (HTTP 200).')
            try:
                length = int(response.headers.get('Content-Length') or 0)
            except (ValueError, TypeError):
                length = 0
            if length > MAX_RESPONSE_BYTES:
                raise ChubImportError('The catalog response exceeded the size limit.')
            chunks, total = [], 0
            for chunk in response.iter_content(chunk_size=65536):
                if cancelled is not None and cancelled.is_set():
                    raise ChubImportError('Catalog request cancelled.')
                total += len(chunk)
                if total > MAX_RESPONSE_BYTES:
                    raise ChubImportError('The catalog response exceeded the size limit.')
                chunks.append(chunk)
            try:
                payload = json.loads(b''.join(chunks).decode('utf-8-sig'))
            except (ValueError, UnicodeError) as exc:
                raise ChubImportError('The public catalog returned unreadable JSON.') from exc
            if not isinstance(payload, dict) or not isinstance(payload.get('bots'), list):
                raise ChubImportError('The public catalog response has no bots list.')
            if len(payload['bots']) > BATCH_SIZE:
                raise ChubImportError('The public catalog changed its batch size unexpectedly.')
            return payload
        except requests.RequestException as exc:
            raise ChubImportError('The public catalog download was interrupted.') from exc
        finally:
            response.close()
    raise ChubImportError('The public catalog redirected too many times.')


class CatalogClient:
    """Small TTL+LRU cache of catalog batches; safe across Qt worker threads."""

    def __init__(self):
        self._cache = OrderedDict()
        self._lock = RLock()

    def clear(self):
        with self._lock:
            self._cache.clear()

    def _fetch_batch(self, batch, *, mature, tags, exclude_tags, tag_match, sort,
                     session, cancelled):
        url = build_catalog_url(batch=batch, mature=mature, tags=tags,
                                exclude_tags=exclude_tags, tag_match=tag_match, sort=sort)
        # Fully encoded URL acts as the cache key, preventing reuse across
        # different content preferences, sorting and tags.
        with self._lock:
            cached = self._cache.get(url)
            if cached and monotonic() - cached[0] < CACHE_SECONDS:
                self._cache.move_to_end(url)
                return cached[1]
        payload = _read_public_json(session, url, cancelled=cancelled)
        with self._lock:
            self._cache[url] = (monotonic(), payload)
            self._cache.move_to_end(url)
            while len(self._cache) > MAX_CACHED_BATCHES:
                self._cache.popitem(last=False)
        return payload

    def browse(self, *, page=1, mature=False, tags='', exclude_tags='',
               tag_match='Any', sort='Newest', with_images=True,
               session=None, cancelled=None):
        if isinstance(page, bool) or not isinstance(page, int) or not 1 <= page <= MAX_DISPLAY_PAGE:
            raise ChubImportError('Catalog page number is out of range.')
        # Validate filters even on cached pages and before opening the network.
        build_catalog_url(mature=mature, tags=tags, exclude_tags=exclude_tags,
                          tag_match=tag_match, sort=sort)
        own_session = session is None
        session = session or requests.Session()
        global_start = (page - 1) * DISPLAY_PAGE_SIZE
        position = global_start
        total = DISPLAY_PAGE_SIZE
        selected = []
        last_payload = None
        last_batch = None
        end_of_catalog = False
        while total:
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Catalog request cancelled.')
            batch_number, offset = divmod(position, BATCH_SIZE)
            batch_number += 1
            payload = self._fetch_batch(batch_number, mature=mature, tags=tags,
                                        exclude_tags=exclude_tags, tag_match=tag_match,
                                        sort=sort, session=session, cancelled=cancelled)
            rows = payload['bots']
            if offset >= len(rows):
                end_of_catalog = True
                break
            take = min(total, len(rows) - offset)
            selected.extend(rows[offset:offset + take])
            total -= take
            position += take
            last_payload, last_batch = payload, batch_number
            if len(rows) < BATCH_SIZE:
                end_of_catalog = total > 0
                break
        output = []
        for node in selected:
            card = clean_feed_record(node)
            if card is None:
                continue
            if not mature and card['mature']:
                continue
            card['image_hidden'] = bool(not mature and card['nsfw_image'])
            output.append(card)
        # `count` is observed as 100000, possibly a cap. Do not claim exact
        # total pages. A full 80-item response implies a possible next batch;
        # a short final batch is authoritative, irrespective of count.
        cursor = global_start + DISPLAY_PAGE_SIZE
        if end_of_catalog or not last_payload or not selected:
            has_more = False
        elif cursor // BATCH_SIZE == (last_batch - 1):
            # Next card is within the currently cached batch.
            has_more = cursor % BATCH_SIZE < len(last_payload['bots'])
        elif cursor % BATCH_SIZE == 0:
            has_more = len(last_payload['bots']) == BATCH_SIZE
        else:
            has_more = len(last_payload['bots']) == BATCH_SIZE
        if with_images and output:
            def download_image(card, image_session):
                if card['image_hidden']:
                    return b''
                if cancelled is not None and cancelled.is_set():
                    raise ChubImportError('Catalog request cancelled.')
                try:
                    data = _stream_https(image_session, card['avatar_url'],
                                         accepted_hosts=DOWNLOAD_HOSTS,
                                         max_bytes=MAX_THUMBNAIL_SIZE,
                                         cancelled=cancelled)
                    if data.startswith((b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'RIFF')):
                        return data
                except ChubImportError:
                    pass
                return b''
            if own_session and len(output) > 1:
                def get_in_own_session(card):
                    with requests.Session() as standalone:
                        return download_image(card, standalone)
                with ThreadPoolExecutor(max_workers=6) as pool:
                    for record, data in zip(output, pool.map(get_in_own_session, output)):
                        record['image_bytes'] = data
            else:
                for record in output:
                    record['image_bytes'] = download_image(record, session)
        return output, has_more


def browse_catalog_characters(*, page=1, mature=False, tags='', exclude_tags='',
                              tag_match='Any', sort='Newest', with_images=True,
                              session=None, cancelled=None, client=None):
    """Return (up to 12 normalized card previews, has_next_display_page)."""
    return (client if client is not None else CatalogClient()).browse(
        page=page, mature=mature, tags=tags, exclude_tags=exclude_tags,
        tag_match=tag_match, sort=sort, with_images=with_images,
        session=session, cancelled=cancelled,
    )
