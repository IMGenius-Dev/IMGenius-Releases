"""Import / export portable character cards, including TavernAI PNG and Character Card V2/V3 JSON.

All operations are local. Parsing never alters the character database. An ordinary
picture is not a character card unless it contains supported embedded metadata.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
import re
import uuid
from pathlib import Path

from PIL import Image, PngImagePlugin, UnidentifiedImageError

from imgenius.domain import DEFAULT_SYSTEM_PROMPT, GENDER_CHOICES
from imgenius.characters.library import normalize_tags, normalize_audience
from imgenius.characters.lorebook import import_lorebook_data

MAX_JSON_SIZE = 8 * 1024 * 1024
MAX_PNG_SIZE = 60 * 1024 * 1024
MAX_CARD_METADATA = 8 * 1024 * 1024


def _text(value):
    return str(value).strip() if value is not None else ''


def _first(*values):
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return str(value)
    return ''


def _read_metadata_value(value):
    if isinstance(value, bytes):
        value = value.decode('utf-8-sig')
    if not isinstance(value, str):
        raise ValueError('Character metadata must contain JSON text.')
    if len(value.encode('utf-8')) > MAX_CARD_METADATA:
        raise ValueError('Character metadata exceeds the 8 MB limit.')
    # TavernAI / SillyTavern PNGs commonly embed a base64-encoded JSON string
    # under the 'chara' tEXt key. JSON text is accepted as a convenience.
    if value.lstrip().startswith('{'):
        decoded = value
    else:
        try:
            decoded = base64.b64decode(value, validate=True).decode('utf-8-sig')
        except (UnicodeError, ValueError, binascii.Error) as exc:
            raise ValueError('PNG character metadata is not valid base64 JSON.') from exc
    if len(decoded.encode('utf-8')) > MAX_CARD_METADATA:
        raise ValueError('Decoded character metadata exceeds the 8 MB limit.')
    try:
        return json.loads(decoded)
    except json.JSONDecodeError as exc:
        raise ValueError('Character metadata contains invalid JSON.') from exc


def _card_data(payload):
    if not isinstance(payload, dict):
        raise ValueError('Character card must contain a JSON object.')
    nested = payload.get('data')
    if isinstance(nested, dict) and any(key in nested for key in ('name', 'description', 'first_mes', 'personality')):
        return nested
    character = payload.get('character')
    if isinstance(character, dict) and any(key in character for key in ('name', 'description', 'personality')):
        return character
    return payload


# Card V2/V3 descriptions are frequently the *complete model-facing character
# definition*, especially when their personality property is empty. IMGenius's
# Description box, in contrast, is the short public-facing character blurb.
# Do not put multi-paragraph prompt text in that blurb automatically.
_PERSONA_SECTIONS = re.compile(
    r'(?im)^\s*(?:#{1,4}\s*|\[)?(?:personality|character profile|character '
    r'definition|appearance|traits|behavior|behaviour|background|backstory)'
    r'(?:\]|\s*:|\s*[-–—]|\s*$)'
)
_PERSONA_MARKERS = re.compile(
    r'(?i)\{\{char\}\}|\{char\}|<char>|\b(?:you are|act as|portray|'
    r'roleplay as|always respond as|never break character)\b'
)
_AGE_LABEL = re.compile(
    r'(?i)(?<!\w)\b(?:age|character age)\s*(?:\]|\*{0,2})\s*[:=\-–]\s*'
    r'([0-9]{1,3})(?![0-9])\b'
)
_AGE_PROSE = re.compile(
    r'(?i)(?<!\w)([0-9]{1,3})\s*(?:[-–‑]\s*)?(?:year[- ]old|years? old|yo\b|y/o\b)'
)
_GENDER_LABEL = re.compile(
    r'(?i)\b(?:gender(?: identity)?|sex)\s*(?:\]|\*{0,2})\s*[:=\-–]\s*'
    r'([a-z][a-z -]{0,35})(?=[\n,;.|]|$)'
)
_GENDER_ALIASES = {
    'male': 'Male', 'man': 'Male', 'boy': 'Male', 'masculine': 'Male',
    'female': 'Female', 'woman': 'Female', 'girl': 'Female',
    'futa': 'Futa', 'futanari': 'Futa',
    'non-binary': 'Non-Binary', 'nonbinary': 'Non-Binary',
    'non binary': 'Non-Binary', 'nb': 'Non-Binary',
    'other': 'Other', 'unknown': 'Other', 'intersex': 'Other',
}


def _profile_texts(data):
    """Only identity/profile text, never examples or conversation scenarios."""
    for key in ('description', 'character_description', 'char_persona',
                'personality', 'character_personality', 'short_description'):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            yield value


def _nested_info(data):
    for key in ('extensions', 'metadata'):
        info = data.get(key)
        if isinstance(info, dict):
            yield info


def _canonical_gender(value):
    value = _text(value).casefold().strip(' :,-.[]')
    if value.startswith(('trans woman', 'transgender woman', 'trans female')):
        return 'Female'
    if value.startswith(('trans man', 'transgender man', 'trans male')):
        return 'Male'
    exact = _GENDER_ALIASES.get(value, '')
    if exact:
        return exact
    # Labels like 'Female (she/her)' or 'Non-binary / they/them'.
    first = re.split(r'\s*[(|/]\s*', value, maxsplit=1)[0].strip()
    return _GENDER_ALIASES.get(first, '')


def _gender_of(data, tags):
    for raw in (data.get('gender'), data.get('sex'),
                *(info.get('gender') for info in _nested_info(data)),
                *(info.get('sex') for info in _nested_info(data))):
        if _text(raw):
            return _canonical_gender(raw) or 'Other'
    for text in _profile_texts(data):
        match = _GENDER_LABEL.search(text)
        if match:
            # Do not mistake a descriptive sentence for an identity label.
            result = _canonical_gender(match.group(1))
            if result:
                return result
            first = re.split(r'\s+', match.group(1).strip(), maxsplit=1)[0]
            result = _canonical_gender(first)
            if result:
                return result
    for tag in tags:
        result = _canonical_gender(tag)
        if result and result != 'Other':
            return result
    # Explicitly written character identities in prose, not implied identities
    # from a POV tag or assumed from the character's pronouns.
    for text in _profile_texts(data):
        match = re.search(
            r'(?i)\b(?:\{\{char\}\}|[A-Z][a-z]+|(?:the )?character)'
            r'\s+(?:is|was)\s+(?:an?\s+)?(woman|man|girl|boy|futanari|futa)\b',
            text,
        )
        if match:
            return _canonical_gender(match.group(1))
    return 'Other'


def _age_of(data):
    for raw in (data.get('age'), data.get('character_age'),
                *(info.get('age') for info in _nested_info(data)),
                *(info.get('character_age') for info in _nested_info(data))):
        if _text(raw):
            return _text(raw)
    for text in _profile_texts(data):
        match = _AGE_LABEL.search(text)
        if match:
            return match.group(1)
    for text in _profile_texts(data):
        match = _AGE_PROSE.search(text)
        if match:
            return match.group(1)
    return ''


def _looks_like_full_prompt(description):
    return bool(description and (
        len(description) >= 320 or _PERSONA_SECTIONS.search(description)
        or _PERSONA_MARKERS.search(description)
    ))


def _map_profile(data):
    """Keep public summary and model-facing character definition independent.

    A standard card may have a short `description` plus an explicit personality;
    those are kept unchanged. Large/structured description blocks and V1
    char_persona content are model-facing, not public blurbs. If a card supplies
    a separate short_description, it wins for the user-facing summary.
    """
    description = _first(data.get('description'), data.get('character_description'))
    summary = _first(data.get('short_description'), data.get('summary'),
                     data.get('tagline'))
    persona = _first(data.get('personality'), data.get('character_personality'),
                     data.get('char_persona'))
    full_prompt = bool(description and (
        _looks_like_full_prompt(description) or (bool(summary) and len(description) > 160)
    ))
    if full_prompt:
        # Full card description often holds appearance, history and behavior.
        # Preserve that whole context rather than selectively discarding it.
        if description != persona:
            persona = f'{description}\n\n{persona}'.strip() if persona else description
        return summary, persona
    return description or summary, persona


def parse_character_card(payload, *, portrait_path=None):
    """Map supported card fields into the exact set of editable IMGenius fields.

    Missing fields become empty / reset defaults rather than inheriting values
    from whichever character happened to be open before import.
    """
    data = _card_data(payload)
    tags = normalize_tags(data.get('tags') or [])
    name = _first(data.get('name'), data.get('char_name'), data.get('character_name'))
    if not name:
        raise ValueError('The selected character card has no character name.')
    raw_greetings = data.get('alternate_greetings') or []
    alternate = raw_greetings[0] if isinstance(raw_greetings, list) and raw_greetings else ''
    lorebook = []
    if any(key in data for key in ('character_book', 'lorebook', 'entries')):
        lorebook = import_lorebook_data(data)
    elif isinstance(payload, dict) and any(key in payload for key in ('character_book', 'lorebook', 'entries')):
        lorebook = import_lorebook_data(payload)
    age = _age_of(data)
    rating = _first(data.get('audience'), data.get('content_rating'), data.get('rating'))
    if rating.casefold() in {'mature', 'adult', 'nsfw', '18+', 'r18'} or any(tag.casefold() in {'mature', 'nsfw', '18+'} for tag in tags):
        audience = 'Mature'
    else:
        audience = normalize_audience(rating)
    # Provider cards vary: long V2/V3 description often *is* the roleplay
    # definition; short_description is the user's preview, when provided.
    description, personality = _map_profile(data)
    system_prompt = _first(data.get('system_prompt'), data.get('systemPrompt')) or DEFAULT_SYSTEM_PROMPT
    return {
        'name': name,
        'gender': _gender_of(data, tags),
        'age': age,
        'short_description': description,
        'personality': personality,
        'scenario': _first(data.get('scenario')),
        'example_dialogue': _first(data.get('example_dialogue'), data.get('mes_example'), data.get('example_dialogs')),
        'first_message': _first(data.get('first_message'), data.get('first_mes'), data.get('greeting'), alternate),
        'system_prompt': system_prompt,
        'lorebook': lorebook,
        'tags': tags,
        'audience': audience,
        'featured': bool(data.get('featured', False)),
        'card_image': str(portrait_path) if portrait_path else '',
    }


def load_character_card(path):
    path = Path(path)
    if not path.is_file():
        raise ValueError('Character card file does not exist.')
    suffix = path.suffix.casefold()
    if suffix == '.json':
        if path.stat().st_size > MAX_JSON_SIZE:
            raise ValueError('Character JSON exceeds 8 MB.')
        try:
            payload = json.loads(path.read_text(encoding='utf-8-sig'))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValueError('Character JSON is invalid or unreadable.') from exc
        return parse_character_card(payload)
    if suffix == '.png':
        if path.stat().st_size > MAX_PNG_SIZE:
            raise ValueError('Character PNG exceeds 60 MB.')
        try:
            with Image.open(path) as picture:
                if picture.format != 'PNG':
                    raise ValueError('The selected image is not PNG.')
                metadata = picture.info.get('chara') or picture.info.get('ccv3')
        except (OSError, UnidentifiedImageError) as exc:
            raise ValueError('The selected PNG could not be read.') from exc
        if not metadata:
            raise ValueError('This PNG has no character-card metadata. Use Attach portrait for normal images.')
        payload = _read_metadata_value(metadata)
        return parse_character_card(payload, portrait_path=path)
    raise ValueError('Choose a character-card .png or .json file.')


def export_character_card_png(character, source_path, target_path):
    """Save card art with embedded Character Card V2 metadata; never change source."""
    source = Path(source_path)
    dest = Path(target_path)
    if not source.is_file():
        raise ValueError('Character artwork is missing.')
    if dest.suffix.casefold() != '.png':
        raise ValueError('Export character card as a .png file.')
    def scalar(key):
        return _text(character.get(key))
    tags = normalize_tags(character.get('tags'))
    lore = character.get('lorebook') or []
    if isinstance(lore, str):
        try:
            lore = json.loads(lore)
        except json.JSONDecodeError:
            lore = []
    if not isinstance(lore, list):
        lore = []
    card_data = {
        'name': scalar('name'),
        'description': scalar('short_description'),
        'personality': scalar('personality'),
        'scenario': scalar('scenario'),
        'first_mes': scalar('first_message'),
        'mes_example': scalar('example_dialogue'),
        'system_prompt': scalar('system_prompt') or DEFAULT_SYSTEM_PROMPT,
        'tags': tags,
        'creator': 'IMGenius',
        'extensions': {'gender': scalar('gender'), 'age': scalar('age')},
        'audience': scalar('audience') or 'Safe',
        'featured': bool(character.get('featured', False)),
        'character_book': {'entries': [
            {'keys': (e.get('keys') or ''), 'content': (e.get('content') or ''),
             'constant': bool(e.get('constant', False))} for e in lore if isinstance(e, dict)
        ]},
    }
    if not card_data['name']:
        raise ValueError('Character must have a name to export.')
    payload = {'spec': 'chara_card_v2', 'spec_version': '2.0', 'data': card_data}
    encoded = base64.b64encode(json.dumps(payload, ensure_ascii=False).encode('utf-8')).decode('ascii')
    pnginfo = PngImagePlugin.PngInfo()
    pnginfo.add_text('chara', encoded)
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Re-exporting over the selected artwork must not truncate the image
    # before Pillow has read its pixel data.
    same_file = source.resolve() == dest.resolve()
    save_to = dest.with_name(f'.{dest.stem}.{uuid.uuid4().hex}.tmp.png') if same_file else dest
    try:
        with Image.open(source) as image:
            image.save(save_to, format='PNG', pnginfo=pnginfo)
        if same_file:
            os.replace(save_to, dest)
    finally:
        if same_file:
            save_to.unlink(missing_ok=True)
    return dest
