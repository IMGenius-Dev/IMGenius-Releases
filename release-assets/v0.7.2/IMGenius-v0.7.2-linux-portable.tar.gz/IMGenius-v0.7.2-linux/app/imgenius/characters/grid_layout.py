"""Deterministic, Qt-independent layout calculations for character discovery.

The scroll viewport, rather than the top-level window, owns the available width.
These helpers are intentionally pure so layout boundaries can be regression-tested.
"""

from __future__ import annotations


def character_grid_metrics(viewport_width: int, count: int, *, side_padding: int = 48,
                           gap: int = 14, min_card_width: int = 235,
                           max_card_width: int = 345) -> tuple[int, int]:
    """Return (columns, card_width); use all practical space without overflowing.

    A small number of cards are centered by the Qt grid's alignment rather than
    stretched to absurd widths. Typical populated pages use 4–7 columns.
    """
    space = max(1, int(viewport_width) - side_padding)
    amount = max(0, int(count))
    if amount == 0:
        return 1, max(160, min(max_card_width, space))
    cols = max(1, min(amount, (space + gap) // (min_card_width + gap)))
    width = (space - (cols - 1) * gap) // cols
    return cols, max(160, min(max_card_width, width))


def character_cover_height(image_width: int, image_height: int, card_width: int, *,
                           horizontal_inset: int = 20,
                           min_height: int = 205, max_height: int = 365) -> int:
    """Uniform portrait height for cards of the same width, regardless of image ratio.

    Source images are aspect-fill cropped in Qt. The source dimensions remain
    in the signature for backwards compatibility with existing gallery callers.
    """
    visible_width = max(140, int(card_width) - horizontal_inset)
    target_height = round(visible_width * 1.20)
    return max(min_height, min(max_height, target_height))


def shorten_character_description(description: str, max_chars: int = 86) -> str:
    """Short, whole-word preview for a portrait; never alters the saved profile.

    Return an ellipsis only when the displayed excerpt is shorter than the full
    description. Dynamic Qt layout can request a smaller budget for thin cards.
    """
    content = ' '.join(str(description or '').split())
    if not content:
        return 'Local character'
    limit = max(8, int(max_chars))
    if len(content) <= limit:
        return content
    prefix = content[:limit - 1].rstrip()
    if len(content) > len(prefix) and not content[len(prefix)].isspace():
        prefix = prefix.rsplit(' ', 1)[0] if ' ' in prefix else prefix
    return (prefix.rstrip(' ,;:-') or content[:limit - 1].rstrip()) + '…'
