"""Local IMGenius lorebook import, validation, and activation.

Supports IMGenius lists, SillyTavern world-info exports (entries mapping),
and Character Card V2 `data.character_book.entries` JSON files.
No network access or executable content is required.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_ENTRIES = 500
MAX_KEY_CHARS = 1000
MAX_BODY_CHARS = 24_000
DEFAULT_CONTEXT_BUDGET = 8000


def _normalise_keys(value):
    if isinstance(value, (list, tuple)):
        value = ', '.join(str(x).strip() for x in value if str(x).strip())
    if not isinstance(value, str):
        value = str(value or '')
    return value.strip()[:MAX_KEY_CHARS]


def normalize_lorebook(entries):
    """Produce safe, uniform [{keys, content, constant}] records."""
    if entries is None or entries == '':
        return []
    if isinstance(entries, str):
        try:
            entries = json.loads(entries)
        except json.JSONDecodeError as exc:
            raise ValueError('Lorebook data is not valid JSON.') from exc
    if not isinstance(entries, list):
        raise ValueError('Lorebook entries must be a list.')
    if len(entries) > MAX_ENTRIES:
        raise ValueError(f'Lorebook contains more than {MAX_ENTRIES} entries.')
    result = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if entry.get('disable') is True or entry.get('enabled') is False:
            continue
        keys = _normalise_keys(entry.get('keys', entry.get('key', entry.get('keyword', ''))))
        content = str(entry.get('content') or '').strip()
        constant = bool(entry.get('constant', entry.get('always_active', False)))
        if len(content) > MAX_BODY_CHARS:
            raise ValueError(f'Lorebook entry exceeds {MAX_BODY_CHARS} characters.')
        if content and (keys or constant):
            result.append({'keys': keys, 'content': content, 'constant': constant})
    return result


def import_lorebook_data(payload):
    """Accept common standalone World Info, card V2, and IMGenius JSON shapes."""
    if isinstance(payload, list):
        return normalize_lorebook(payload)
    if not isinstance(payload, dict):
        raise ValueError('Lorebook JSON must be an object or list.')
    entry_set = None
    for candidate in (
        payload.get('entries'),
        (payload.get('character_book') or {}).get('entries') if isinstance(payload.get('character_book'), dict) else None,
        (payload.get('data') or {}).get('character_book', {}).get('entries')
        if isinstance(payload.get('data'), dict) and isinstance(payload['data'].get('character_book'), dict) else None,
        payload.get('lorebook'),
    ):
        if candidate is not None:
            entry_set = candidate
            break
    if entry_set is None:
        raise ValueError('No lorebook entries found. Expected entries, character_book, data.character_book, or lorebook.')
    if isinstance(entry_set, dict):
        entry_set = list(entry_set.values())
    return normalize_lorebook(entry_set)


def import_lorebook_file(path):
    path = Path(path)
    if path.suffix.lower() != '.json':
        raise ValueError('Choose a .json lorebook file.')
    if path.stat().st_size > MAX_FILE_BYTES:
        raise ValueError('Lorebook file exceeds the 4 MB import limit.')
    try:
        raw = json.loads(path.read_text(encoding='utf-8-sig'))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError('The selected file is not valid UTF-8 JSON.') from exc
    entries = import_lorebook_data(raw)
    if not entries:
        raise ValueError('No active lorebook entries with content and triggers were found.')
    return entries


def matching_lorebook_entries(entries, messages, max_chars=DEFAULT_CONTEXT_BUDGET):
    """Only insert active lorebook entries; triggered entries match recent dialogue."""
    entries = normalize_lorebook(entries)
    if isinstance(messages, str):
        haystack = messages.casefold()
    else:
        haystack = '\n'.join(str(msg.get('content') or '') for msg in (messages or [])[-12:]
                             if isinstance(msg, dict)).casefold()
    selected = []
    used = 0
    for entry in entries:
        keys = re.split(r'[,;\n]+', entry['keys'])
        triggered = entry['constant'] or any(
            re.search(r'(?<!\w)' + re.escape(key.strip().casefold()) + r'(?!\w)', haystack)
            for key in keys if key.strip()
        )
        if not triggered:
            continue
        content = entry['content']
        if used + len(content) > max_chars:
            continue
        selected.append(content)
        used += len(content)
    return selected
