"""Pure pagination functions for IMGenius character discovery.

Paging applies *after* filtering and sorting, so page counts always match
what the user is currently viewing.
"""

PAGE_SIZE = 12


def page_count(result_count, page_size=PAGE_SIZE):
    if page_size < 1:
        raise ValueError('page_size must be at least 1')
    return max(1, (max(0, int(result_count)) + page_size - 1) // page_size)


def clamp_page(requested, result_count, page_size=PAGE_SIZE):
    """Treat invalid/empty input as page 1; clamp out-of-range requests."""
    try:
        number = int(str(requested).strip())
    except (TypeError, ValueError):
        number = 1
    return min(max(1, number), page_count(result_count, page_size))


def paginate(items, requested_page, page_size=PAGE_SIZE):
    page = clamp_page(requested_page, len(items), page_size)
    begin = (page - 1) * page_size
    return items[begin:begin + page_size], page, page_count(len(items), page_size)
