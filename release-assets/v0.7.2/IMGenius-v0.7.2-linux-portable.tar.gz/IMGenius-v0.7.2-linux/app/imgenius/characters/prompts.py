"""Character greeting defaults and lorebook-backed system prompt assembly."""
import re
from imgenius.shared.text import safe_text, apply_tokens
from imgenius.characters.lorebook import matching_lorebook_entries

DEFAULT_SYSTEM_PROMPT = (
    'You are {{char}}. Write the next reply from {{char}} in this never-ending conversation '
    'between {{char}} and {{user}}. Gestures and other non-verbal actions are written '
    'between asterisks (for example, *waves hello* or *moves closer*).'
)

GENDER_CHOICES = ('Male', 'Female', 'Futa', 'Non-Binary', 'Other')


DEFAULT_FIRST_MESSAGE = (
    '*{{char}} looks up as {{user}} approaches.* '
    '"Hello, {{user}}. What brings you here?"'
)


def default_first_message(character):
    """A stable, character-specific opening for old profiles and fresh characters.

    Keep {{user}}/{{char}} unresolved in the profile; replace when a new chat
    is created so the selected user persona is represented correctly.
    """
    character = character or {}
    name = safe_text(character.get('name')).casefold()
    scenario = safe_text(character.get('scenario'))
    dialogue = safe_text(character.get('example_dialogue'))
    description = safe_text(character.get('short_description'))
    if name == 'nova' and 'science' in (scenario + description).casefold():
        return ('*{{char}} looks up from a glowing sensor display on the science deck, '
                'then turns toward {{user}} with a welcoming smile.* '
                '"You picked an interesting time to visit the station. '
                'Want to help me investigate these readings?"')
    if name == 'atlas' and ('survival' in (scenario + description).casefold()
                             or 'camp' in scenario.casefold()):
        return ('*{{char}} studies a map beside the campfire and gestures {{user}} '
                'closer.* "We have supplies to account for and a storm coming. '
                'Are you here to help me plan?"')
    # Catalog examples usually look like '{{char}}: *gesture* "dialogue"'.
    # Each of the 200 seed profiles has a distinct example and scenario.
    dialogue = re.sub(r'^\s*(?:\{\{char\}\}|[^:]{1,45})\s*:\s*', '', dialogue,
                      count=1, flags=re.IGNORECASE)
    if dialogue:
        if scenario:
            # The first two scenario sentences contain the setting and the
            # character's unique predicament; exclude generic arrival text.
            sentences = re.split(r'(?<=[.!?])\s+', scenario)
            introduction = ' '.join(sentences[:2]).strip()
            if introduction:
                return f'*{introduction}*\n\n{dialogue}'
        return dialogue
    if scenario:
        short = re.split(r'(?<=[.!?])\s+', scenario)[0].strip()
        return (f'*{short}*\n\n*{{{{char}}}} turns toward {{{{user}}}}.* '
                '"What should we do first?"')
    if description:
        return (f'*{description.rstrip(". ")}.*\n\n*{{{{char}}}} greets {{{{user}}}}.* '
                '"What brings you here?"')
    return DEFAULT_FIRST_MESSAGE

def build_character_prompt(character, user_name='User', persona=None, extra_context='', recent_messages=None):
    """Build chat instructions using only active character fields and matched lore.

    Old optional columns stay in storage for compatibility, but never enter
    newly assembled prompts after the editor simplification.
    """
    character = character or {}
    persona = persona or {}
    char_name = safe_text(character.get('name')) or 'Assistant'
    active_user = safe_text(persona.get('user_name'), user_name) or user_name
    prompt_template = safe_text(character.get('system_prompt')) or DEFAULT_SYSTEM_PROMPT
    lines = [apply_tokens(prompt_template, active_user, char_name)]
    gender = safe_text(character.get('gender'))
    age = safe_text(character.get('age'))
    description = safe_text(character.get('short_description'))
    personality = safe_text(character.get('personality'))
    scenario = safe_text(character.get('scenario'))
    examples = safe_text(character.get('example_dialogue'))
    if gender:
        lines.append('Gender: ' + apply_tokens(gender, active_user, char_name))
    if age:
        lines.append('Age: ' + apply_tokens(age, active_user, char_name))
    if description:
        lines.append('Description: ' + apply_tokens(description, active_user, char_name))
    if personality:
        lines.append('Personality: ' + apply_tokens(personality, active_user, char_name))
    if scenario:
        lines.append('Scenario: ' + apply_tokens(scenario, active_user, char_name))
    if examples:
        lines.append('Example dialogue: ' + apply_tokens(examples, active_user, char_name))
    persona_description = safe_text(persona.get('description'))
    persona_prompt = safe_text(persona.get('prompt'))
    if persona_description:
        lines.append('About the user: ' + apply_tokens(persona_description, active_user, char_name))
    if persona_prompt:
        lines.append('User persona: ' + apply_tokens(persona_prompt, active_user, char_name))
    # For activated entries, keys are a match condition; only their content is sent.
    lore = matching_lorebook_entries(character.get('lorebook'), recent_messages or [])
    if lore:
        lines.append('Relevant lorebook context:\n' + '\n'.join(
            apply_tokens(entry, active_user, char_name) for entry in lore
        ))
    return '\n\n'.join(lines)
