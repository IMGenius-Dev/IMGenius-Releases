"""Backwards-compatible Chub/TelegAI importer names (see chub.py)."""

from imgenius.characters.chub import (
    API_BASE, CDN_BASE, DOWNLOAD_HOSTS, PUBLIC_SITE, SEARCH_BASE,
    SITE_HOSTS, DISCOVERY_PAGE_SIZE, SORT_OPTIONS, MAX_SEARCH_RESPONSE,
    MAX_THUMBNAIL_SIZE, TelegAIImportError, ChubImportError,
    character_from_url, pull_public_character, browse_public_characters,
    parse_discovery_response, _api_avatar_url, _stream_https,
    _clean_public_record, _is_mature_record, _content_rating,
    browse_chub_characters, pull_chub_character, chub_character_from_url,
)

# v0.5.8 public TelegAI discovery (legacy Chub aliases above are kept for callers).
from imgenius.characters.telegai_feed import (
    TELEGAI_FEED, browse_telegai_feed, clean_feed_record, parse_feed_response,
    classify_topics,
)
