"""Public Chub character-card search and download integration.

This module does not scrape logged-in pages or require account credentials.
Only public Character Card PNGs bearing embedded card metadata are accepted.
Chub pages use public author/slug IDs; the export
address is attempted first, followed by a bounded Chub API lookup and PNG export fallback.

Chub is third-party infrastructure and may change its URLs. Surface
errors to the user and offer the regular PNG/JSON import instead of fabricating
character fields from a rendered web page.
"""
from __future__ import annotations

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit, quote
import uuid

import requests

from imgenius.characters.card_io import load_character_card, MAX_PNG_SIZE
from imgenius.shared.paths import DATA_DIR

PUBLIC_SITE = 'https://chub.ai/characters'
API_BASE = 'https://api.chub.ai/api/characters'
CDN_BASE = 'https://avatars.charhub.io/avatars'
SITE_HOSTS = frozenset({'telegai.com', 'www.telegai.com', 'chub.ai', 'www.chub.ai',
                        'characterhub.org', 'www.characterhub.org'})
DOWNLOAD_HOSTS = frozenset({'avatars.charhub.io', 'avatars.chub.ai',
                            'cdn.chub.ai', 'api.chub.ai'})


class ChubImportError(ValueError):
    """An invalid URL, inaccessible character card or invalid download."""


def _clean_host(url):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ChubImportError('Only secure HTTPS links from supported character providers are allowed.')
    return (parsed.hostname or '').casefold(), parsed


def character_from_url(url):
    """Return public (author, slug) identifier, rejecting other web URLs."""
    if not isinstance(url, str) or len(url) > 2048:
        raise ChubImportError('Paste a valid Chub character link.')
    try:
        host, parsed = _clean_host(url.strip())
    except ValueError as exc:
        raise ChubImportError('The character link is invalid.') from exc
    if host not in SITE_HOSTS:
        raise ChubImportError('This importer accepts only supported Chub-format character links.')
    parts = [p for p in parsed.path.split('/') if p]
    if len(parts) != 3 or parts[0].casefold() not in ('bots', 'chat', 'characters'):
        raise ChubImportError('Open a character detail page first, then choose Import Current Character.')
    author, slug = parts[1:]
    # Safe route tokens only; disallow path traversal and encoded separators.
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,90}', author) or not re.fullmatch(r'[A-Za-z0-9_-]{1,180}', slug):
        raise ChubImportError('The character URL contains an unsupported identifier.')
    return author, slug


def _stream_https(session, url, *, accepted_hosts, max_bytes, cancelled=None):
    """Bounded HTTPS download, including host validation for each redirect."""
    for redirect in range(4):
        host, _ = _clean_host(url)
        if host not in accepted_hosts:
            raise ChubImportError('The download redirected to an untrusted server.')
        if cancelled is not None and cancelled.is_set():
            raise ChubImportError('Import cancelled.')
        try:
            response = session.get(url, stream=True, allow_redirects=False, timeout=(8, 35),
                                   headers={'User-Agent': 'IMGenius/0.5 Character Card Importer'})
        except requests.RequestException as exc:
            raise ChubImportError('Could not contact Chub. Check your network connection.') from exc
        try:
            if response.status_code in (301, 302, 303, 307, 308):
                from urllib.parse import urljoin
                location = response.headers.get('Location')
                if not location:
                    raise ChubImportError('Chub returned an invalid redirect.')
                url = urljoin(url, location)
                continue
            if response.status_code != 200:
                if response.status_code in (401, 403, 451) and host == 'api.chub.ai':
                    raise ChubImportError(
                        f'The public directory denied access (HTTP {response.status_code}). '
                        'An IMGenius preference does not complete Chub website age '
                        'verification or override account/region restrictions.'
                    )
                raise ChubImportError(f'Card download returned HTTP {response.status_code}.')
            length = response.headers.get('Content-Length')
            if length:
                try:
                    declared_length = int(length)
                except ValueError:
                    declared_length = 0
                if declared_length > max_bytes:
                    raise ChubImportError('The card download is larger than the allowed limit.')
            chunks = []
            count = 0
            for chunk in response.iter_content(chunk_size=65536):
                if cancelled is not None and cancelled.is_set():
                    raise ChubImportError('Import cancelled.')
                count += len(chunk)
                if count > max_bytes:
                    raise ChubImportError('The card download exceeds the size limit.')
                chunks.append(chunk)
            return b''.join(chunks)
        except requests.RequestException as exc:
            raise ChubImportError('Card download interrupted.') from exc
        finally:
            response.close()
    raise ChubImportError('Too many redirects while fetching the character card.')


def _api_avatar_url(payload):
    """Find a public CDN card image URL in common Chub API response forms."""
    if not isinstance(payload, dict):
        return None
    candidates = [payload]
    for key in ('node', 'data', 'character', 'result'):
        if isinstance(payload.get(key), dict):
            candidates.append(payload[key])
    for item in candidates:
        for key in ('max_res_url', 'png_url', 'card_url', 'avatar_url'):
            value = item.get(key)
            if not isinstance(value, str):
                continue
            try:
                host, parsed = _clean_host(value)
            except (ValueError, ChubImportError):
                continue
            if host in DOWNLOAD_HOSTS and parsed.path.lower().endswith('.png'):
                return value
    return None


def _download_export_png(session, full_path, *, cancelled=None):
    """Try Chub's public Tavern PNG export route (as used by SillyTavern).

    This is a normal provider export, not a login/age-gate bypass. Automatic
    redirects are disabled, and downloads use the regular 60 MiB limit.
    """
    if not _IDENTIFIER_RE.fullmatch(full_path):
        raise ChubImportError('Invalid Chub character identifier.')
    url = 'https://api.chub.ai/api/characters/download'
    try:
        response = session.post(
            url,
            json={'format': 'tavern', 'fullPath': full_path},
            headers={'User-Agent': 'IMGenius/0.5 Chub Character Importer',
                     'Accept': 'image/png,application/octet-stream'},
            stream=True, allow_redirects=False, timeout=(8, 35),
        )
    except requests.RequestException as exc:
        raise ChubImportError('Could not contact Chub export service.') from exc
    try:
        if cancelled is not None and cancelled.is_set():
            raise ChubImportError('Import cancelled.')
        if response.status_code != 200:
            if response.status_code in (401, 403, 451):
                raise ChubImportError('Chub export denied access; check account and regional restrictions.')
            raise ChubImportError(f'Chub card export returned HTTP {response.status_code}.')
        if int(response.headers.get('Content-Length') or 0) > MAX_PNG_SIZE:
            raise ChubImportError('Chub exported file is larger than the allowed limit.')
        chunks, total = [], 0
        for chunk in response.iter_content(chunk_size=65536):
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Import cancelled.')
            total += len(chunk)
            if total > MAX_PNG_SIZE:
                raise ChubImportError('Chub card export exceeds the size limit.')
            chunks.append(chunk)
        blob = b''.join(chunks)
        if not blob.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ChubImportError('Chub export did not return a PNG card.')
        return blob
    finally:
        response.close()


def pull_public_character(url, *, cache_dir=None, session=None, cancelled=None, status=None):
    """Download a public V2 PNG card and return its validated IMGenius draft.

    The user must explicitly save the returned draft in the Character Editor.
    Successful files are cached under the user's data folder so their portrait
    remains available until the user saves or discards the draft.
    """
    author, slug = character_from_url(url)
    session = session or requests.Session()
    author_path = quote(author, safe='_-')
    slug_path = quote(slug, safe='_-')
    direct = f'{CDN_BASE}/{author_path}/{slug_path}/chara_card_v2.png'
    possibilities = [direct]
    if status:
        status('Checking the public character-card PNG…')
    # API lookup is only used to obtain an alternate exported PNG location;
    # no text is guessed from card landing pages.
    try:
        api_bytes = _stream_https(session, f'{API_BASE}/{author_path}/{slug_path}',
                                  accepted_hosts=frozenset({'api.chub.ai'}),
                                  max_bytes=2 * 1024 * 1024, cancelled=cancelled)
        import json
        avatar_url = _api_avatar_url(json.loads(api_bytes.decode('utf-8-sig')))
        if avatar_url and avatar_url not in possibilities:
            possibilities.append(avatar_url)
    except (ChubImportError, ValueError, UnicodeError):
        pass  # Direct V2 export may still be available without the API.

    folder = Path(cache_dir) if cache_dir is not None else DATA_DIR / 'online_card_cache'
    folder.mkdir(parents=True, exist_ok=True)
    last_failure = None
    for index, candidate in enumerate(possibilities):
        if status:
            status(f'Downloading public character card ({index + 1}/{len(possibilities)})…')
        filename = folder / f'chub_{uuid.uuid4().hex}.png'
        try:
            content = _stream_https(session, candidate, accepted_hosts=DOWNLOAD_HOSTS,
                                    max_bytes=MAX_PNG_SIZE, cancelled=cancelled)
            if not content.startswith(b'\x89PNG\r\n\x1a\n'):
                raise ChubImportError('The downloaded file is not a PNG character card.')
            # File is created exclusively under a writable user-controlled cache.
            with open(filename, 'xb') as fp:
                fp.write(content)
            card = load_character_card(filename)
            card['source_url'] = url
            return card
        except (OSError, ValueError, ChubImportError) as exc:
            last_failure = str(exc)
            filename.unlink(missing_ok=True)
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Import cancelled.') from exc
    # Newer Chub cards may not expose a CDN metadata PNG. Chub also provides
    # an export endpoint used by common third-party clients.
    if hasattr(session, 'post'):
        filename = folder / f'chub_{uuid.uuid4().hex}.png'
        try:
            if status:
                status('Trying Chub character-card export…')
            blob = _download_export_png(session, f'{author}/{slug}', cancelled=cancelled)
            with open(filename, 'xb') as fp:
                fp.write(blob)
            card = load_character_card(filename)
            card['source_url'] = url
            return card
        except (OSError, ValueError, ChubImportError) as exc:
            last_failure = str(exc)
            filename.unlink(missing_ok=True)
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Import cancelled.') from exc
    raise ChubImportError(
        'Could not retrieve a complete Chub character card. '
        'The site may restrict downloads or its export route may have changed. '
        'Try downloading a V2 PNG or JSON on the website and importing the file in Character Editor. '
        + (f'Details: {last_failure}' if last_failure else '')
    )

# Public Chub discovery powers the character cards shown inside the
# IMGenius Characters page. Unlike the old embedded browser, no web view or
# website JavaScript is required.
from urllib.parse import urlencode
import re

SEARCH_BASE = 'https://api.chub.ai/search'
DISCOVERY_PAGE_SIZE = 12
MAX_SEARCH_RESPONSE = 3 * 1024 * 1024
MAX_THUMBNAIL_SIZE = 2 * 1024 * 1024
SORT_OPTIONS = {
    'Popular': 'download_count',
    'Newest': 'created_at',
    'Recently updated': 'last_activity_at',
}
_IDENTIFIER_RE = re.compile(r'^[A-Za-z0-9_-]{1,100}/[A-Za-z0-9_-]{1,200}$')
# The public API sometimes includes rated results in a response requested with
# nsfw=false. Keep the server-side query parameter, but also honor explicit
# content labels in the returned metadata before presenting a Safe-only view.
_MATURE_RATINGS = frozenset({'mature', 'adult', 'nsfw', 'nsfl', '18+', 'r18', 'explicit', 'xxx'})


def _content_rating(node):
    """Classify only explicit Chub rating metadata; unknown is NOT safe.

    Chub search responses are not guaranteed to include any rating field.
    Never infer safety from the absence of an NSFW flag.
    """
    if not isinstance(node, dict):
        return 'Unrated'
    source = node.get('node', node)
    if not isinstance(source, dict):
        return 'Unrated'
    known_safe = False
    for key in ('nsfw', 'isNsfw', 'isNSFW', 'is_nsfw', 'naughty', 'adult', 'isAdult'):
        value = source.get(key)
        if value is None or isinstance(value, (list, dict)):
            continue
        if value is True:
            return 'Mature'
        if value is False:
            known_safe = True
            continue
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if value > 0:
                return 'Mature'
            if value == 0:
                known_safe = True
        elif isinstance(value, str):
            normalized = value.strip().casefold()
            if normalized in _MATURE_RATINGS | {'true', '1', 'yes'}:
                return 'Mature'
            if normalized in {'safe', 'sfw', 'false', '0', 'no'}:
                known_safe = True
    for key in ('rating', 'content_rating', 'contentRating', 'audience', 'content_label'):
        rating = source.get(key)
        if isinstance(rating, str):
            value = rating.strip().casefold()
            if value in _MATURE_RATINGS:
                return 'Mature'
            if value in {'safe', 'sfw', 'everyone', 'general', 'g'}:
                known_safe = True
    tags = source.get('tags') or []
    if isinstance(tags, list):
        for tag in tags:
            label = tag.get('name', '') if isinstance(tag, dict) else tag
            if isinstance(label, str) and label.strip().casefold() in _MATURE_RATINGS:
                return 'Mature'
    return 'Safe' if known_safe else 'Unrated'


def _is_mature_record(node):
    return _content_rating(node) == 'Mature'


def _clean_public_record(node):
    """Normalize a public search hit without treating preview text as a card."""
    if not isinstance(node, dict):
        return None
    source = node.get('node', node)
    if not isinstance(source, dict):
        return None
    path = source.get('fullPath') or source.get('full_path') or source.get('path')
    if not isinstance(path, str) or not _IDENTIFIER_RE.fullmatch(path):
        return None
    name = source.get('name')
    if not isinstance(name, str) or not name.strip():
        return None
    name = name.strip()[:160]
    description = (source.get('tagline') or source.get('description') or
                   source.get('summary') or source.get('creatorNotes') or '')
    if not isinstance(description, str):
        description = ''
    tags = source.get('tags', [])
    if not isinstance(tags, list):
        tags = []
    tags = [str(t.get('name') if isinstance(t, dict) else t)[:50] for t in tags[:10]]
    tags = [t for t in tags if t and t != 'None']
    avatar_url = source.get('avatar_url') or source.get('avatarUrl') or source.get('max_res_url')
    if not isinstance(avatar_url, str):
        avatar_url = ''
    if avatar_url:
        try:
            host, parsed = _clean_host(avatar_url)
            if host not in DOWNLOAD_HOSTS or not parsed.path.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                avatar_url = ''
        except (ValueError, ChubImportError):
            avatar_url = ''
    if not avatar_url:
        avatar_url = f'{CDN_BASE}/{quote(path, safe="/_-")}/avatar.png'
    return {
        'id': path,
        'name': name,
        'mature': _is_mature_record(node),
        'content_rating': _content_rating(node),
        'description': description.strip()[:1800],
        'tags': tags,
        'source_url': f'https://chub.ai/characters/{path}',
        'avatar_url': avatar_url,
        'image_bytes': b'',
    }


def parse_discovery_response(payload, *, page=1, include_mature=True):
    """Return sanitized public card previews and a conservative next-page flag."""
    if not isinstance(payload, dict):
        raise ChubImportError('The Chub character directory returned invalid data.')
    content = payload.get('data', payload)
    if not isinstance(content, dict):
        raise ChubImportError('The Chub character directory returned invalid data.')
    nodes = content.get('nodes', content.get('characters', content.get('results')))
    if not isinstance(nodes, list):
        raise ChubImportError('The Chub directory format has changed. Try again later.')
    entries = []
    identifiers = set()
    for node in nodes[:DISCOVERY_PAGE_SIZE]:
        entry = _clean_public_record(node)
        if entry and not include_mature and entry['mature']:
            continue
        if entry and entry['id'] not in identifiers:
            identifiers.add(entry['id'])
            entries.append(entry)
    count = content.get('count', content.get('totalCount', content.get('total')))
    # Some search deployments return the total hit count while others return
    # the current batch length under `count`. Never hide a potentially valid
    # next page when a full batch was returned. The next request can confirm
    # the end, even if the total-count field is ambiguous.
    if isinstance(content.get('has_more'), bool):
        has_next = content['has_more']
    elif isinstance(count, int) and not isinstance(count, bool) and count >= 0:
        has_next = (int(page) * DISCOVERY_PAGE_SIZE < count or
                    len(nodes) >= DISCOVERY_PAGE_SIZE)
    else:
        has_next = len(nodes) >= DISCOVERY_PAGE_SIZE
    return entries, has_next


def _normalize_catalog_tags(tags):
    """Bounded, comma-separated, exact tag names for Chub's `topics` filter.

    The provider can change how it interprets multiple tags; keeping the
    submitted value visible in the UI avoids implying client-side indexing.
    """
    if not isinstance(tags, str) or len(tags) > 240:
        raise ChubImportError('Tag filter is too long.')
    parts = [part.strip() for part in tags.split(',')]
    if len(parts) > 8 or any(len(part) > 60 for part in parts):
        raise ChubImportError('Use up to eight tags, each at most 60 characters.')
    return tuple(dict.fromkeys(part for part in parts if part))


def browse_public_characters(*, query='', page=1, sort='Popular', mature=False,
                             tags='', with_images=True, session=None, cancelled=None):
    """Search only publicly listed characters via Chub’s public search API.

    The returned fields are *previews*, not imported chat prompts. Searching
    and tag filtering use Chub's indexed catalog API, not local feed-page
    filtering. Selecting a card still validates the V2 PNG separately.
    """
    if not isinstance(query, str) or len(query) > 150:
        raise ChubImportError('Search text is too long.')
    normalized_tags = _normalize_catalog_tags(tags)
    if isinstance(page, bool) or not isinstance(page, int) or page < 1 or page > 10000:
        raise ChubImportError('Page number is out of range.')
    if sort not in SORT_OPTIONS:
        raise ChubImportError('Unknown directory sorting option.')
    # This is Chub's own documented-in-the-wild public search protocol, not
    # TelegAI's website. 'venus=false' is used by existing Chub discovery
    # clients in both content modes; changing it does not grant age access.
    search_params = {
        'search': query.strip(), 'first': DISCOVERY_PAGE_SIZE, 'page': page,
        'sort': SORT_OPTIONS[sort], 'asc': 'false', 'nsfw': str(bool(mature)).lower(),
        'venus': 'false',
    }
    if normalized_tags:
        search_params['topics'] = ','.join(normalized_tags)
    params = urlencode(search_params)
    own_session = session is None
    session = session or requests.Session()
    raw = _stream_https(session, f'{SEARCH_BASE}?{params}',
                        accepted_hosts=frozenset({'api.chub.ai'}),
                        max_bytes=MAX_SEARCH_RESPONSE, cancelled=cancelled)
    import json
    try:
        payload = json.loads(raw.decode('utf-8-sig'))
    except (ValueError, UnicodeError) as exc:
        raise ChubImportError('The character directory returned unreadable data.') from exc
    # Safety: do not display explicitly rated Mature results when the user
    # selected SFW, even if the upstream service does not honor nsfw=false.
    # Unrated records remain labeled Unrated, never incorrectly as Safe.
    entries, has_next = parse_discovery_response(payload, page=page,
                                                 include_mature=mature)
    if with_images:
        def fetch_preview(entry, download_session):
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Discovery cancelled.')
            try:
                data = _stream_https(download_session, entry['avatar_url'],
                                     accepted_hosts=DOWNLOAD_HOSTS,
                                     max_bytes=MAX_THUMBNAIL_SIZE, cancelled=cancelled)
                if data.startswith((b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'RIFF')):
                    return data
            except ChubImportError:
                pass  # Missing thumbnails never prevent browsing/importing.
            return b''

        # Parallelize public image loads without sharing a requests.Session
        # between worker threads; injected unit-test sessions stay sequential.
        if own_session and len(entries) > 1:
            def fetch_in_session(entry):
                with requests.Session() as isolated:
                    return fetch_preview(entry, isolated)
            with ThreadPoolExecutor(max_workers=6) as pool:
                for entry, data in zip(entries, pool.map(fetch_in_session, entries)):
                    entry['image_bytes'] = data
        else:
            for entry in entries:
                entry['image_bytes'] = fetch_preview(entry, session)
    return entries, has_next


# Preferred provider-specific API for v0.5.7 and later.
browse_chub_characters = browse_public_characters
pull_chub_character = pull_public_character
chub_character_from_url = character_from_url
TelegAIImportError = ChubImportError  # compatibility for older integrations
