"""Characters components for IMGenius."""
