"""Character discovery metadata and filtering. Pure Python; shared by Qt and tests."""
from __future__ import annotations
import re
from collections import Counter

# Familiar selectable tags from the requested reference. These are local metadata,
# not remotely retrieved tags or content-moderation assertions.
TAG_CATALOG = [
    'Female', 'Male', 'Non-binary', 'Gay', 'Lesbian', 'Bisexual', 'Femboy', 'Futa',
    'Human', 'Non-human', 'Monster', 'Vampire', 'Werewolf', 'Elf', 'Furry', 'Alien',
    'Robot', 'Multiple', 'Fictional', 'Original Character', 'Non-English',
    'Streamer', 'VTuber', 'Celebrity', 'Musician', 'Detective', 'Chef', 'Athlete',
    'Royalty', 'Assistant', 'Teacher', 'Student', 'Coworker', 'Maid', 'AI Assistant',
    'Soldier', 'Doctor', 'Prostitute', 'Slave', 'Angel', 'Demon', 'Tsundere',
    'Yandere', 'Girlfriend', 'Boyfriend', 'Wife', 'Husband', 'Game', 'Anime',
    'Manga', 'TV Show', 'Movie', 'Cartoon', 'Historical', 'Politics', 'RPG',
    'Religion', 'Books', 'Work', 'Hero', 'Villain', 'Magical', 'Sci-Fi',
    'Fantasy', 'Horror', 'Food', 'Dominant', 'Submissive', 'Cheating', 'Romance',
    'Male POV', 'Female POV',
]

TAG_ICONS = {
    'Female': '👩', 'Male': '👨', 'Non-binary': '👤', 'Gay': '🏳️‍🌈',
    'Lesbian': '🏳️‍🌈', 'Bisexual': '💗', 'Femboy': '🧑', 'Futa': '🎭',
    'Human': '🧑', 'Non-human': '🦄', 'Monster': '👹', 'Vampire': '🧛',
    'Werewolf': '🐺', 'Elf': '🧝', 'Furry': '🐱', 'Alien': '👽',
    'Robot': '🤖', 'Multiple': '👥', 'Fictional': '📚', 'Original Character': '🎨',
    'Non-English': '🌍', 'Streamer': '🎥', 'VTuber': '👩‍💻',
    'Celebrity': '🎭', 'Musician': '🎼', 'Detective': '🕵️', 'Chef': '👨‍🍳',
    'Athlete': '⚽', 'Royalty': '👑', 'Assistant': '🧑‍💼', 'Teacher': '👩‍🏫',
    'Student': '🎓', 'Coworker': '💼', 'Maid': '🧹', 'AI Assistant': '🤖',
    'Soldier': '⚔️', 'Doctor': '🩺', 'Prostitute': '👠', 'Slave': '⛓️',
    'Angel': '😇', 'Demon': '😈', 'Tsundere': '🖤', 'Yandere': '💘',
    'Girlfriend': '💕', 'Boyfriend': '💖', 'Wife': '💍', 'Husband': '💍',
    'Game': '🎮', 'Anime': '🌟', 'Manga': '📒', 'TV Show': '📺',
    'Movie': '🎥', 'Cartoon': '🐻', 'Historical': '📜', 'Politics': '🏛️',
    'RPG': '🎲', 'Religion': '⛪', 'Books': '📚', 'Work': '💼',
    'Hero': '🦸', 'Villain': '🦹', 'Magical': '🔮', 'Sci-Fi': '🚀',
    'Fantasy': '🧝', 'Horror': '👻', 'Food': '🍲', 'Dominant': '⛓️',
    'Submissive': '🧡', 'Cheating': '🤫', 'Romance': '💕',
    'Male POV': '👨', 'Female POV': '👩',
}


# Tag-chip options in the character editor. Most options apply to characters
# regardless of content label. More adult-specific roleplay tags appear when
# the editor's Content label is Mature. Selected tags are always preserved.
EDITOR_POPULAR_TAGS = (
    'Female', 'Male', 'Non-binary', 'Human', 'Non-human', 'Monster',
    'Fictional', 'Original Character', 'Anime', 'Fantasy', 'Sci-Fi',
    'Horror', 'Romance', 'AI Assistant', 'Robot', 'Alien', 'Furry',
    'Hero', 'Villain', 'Magical', 'Teacher', 'Student', 'Coworker',
    'Girlfriend', 'Boyfriend', 'RPG', 'Game', 'Multiple',
)
MATURE_EDITOR_TAGS = (
    'Futa', 'Prostitute', 'Slave', 'Dominant', 'Submissive',
    'Cheating', 'Male POV', 'Female POV',
)


def editor_tag_options(audience='Safe', selected_tags=()):
    """All eligible tag chips, including selected imports/custom tags.

    Changing Safe/Mature never erases a previously selected tag. Mature-only
    chips are hidden when Safe unless already selected, to make it possible to
    deselect them without losing or modifying the stored character metadata.
    """
    mature = normalize_audience(audience) == 'Mature'
    restricted = {t.casefold() for t in MATURE_EDITOR_TAGS}
    selected = normalize_tags(selected_tags)
    options = []
    seen = set()
    ordered = list(EDITOR_POPULAR_TAGS)
    if mature:
        ordered.extend(MATURE_EDITOR_TAGS)
    ordered.extend(TAG_CATALOG)
    ordered.extend(selected)
    selected_keys = {t.casefold() for t in selected}
    for tag in ordered:
        key = tag.casefold()
        if key in seen or (not mature and key in restricted and key not in selected_keys):
            continue
        seen.add(key)
        options.append(tag)
    return options


def visible_editor_tags(audience='Safe', selected_tags=(), expanded=False, limit=12):
    """Return (visible tags, eligible count) for the editor tag picker.

    Mature's additional chips are surfaced even when the ordinary catalog is
    collapsed. Selected custom/imported chips are pinned in both modes.
    """
    options = editor_tag_options(audience, selected_tags)
    if expanded:
        return options, len(options)
    pinned = {t.casefold() for t in normalize_tags(selected_tags)}
    if normalize_audience(audience) == 'Mature':
        pinned.update(t.casefold() for t in MATURE_EDITOR_TAGS)
    common = {t.casefold() for t in options[:max(0, int(limit))]}
    return [t for t in options if t.casefold() in common or t.casefold() in pinned], len(options)


def normalize_tags(value):
    """Case-insensitive de-duplication preserving readable user-given labels."""
    if isinstance(value, (tuple, list, set)):
        raw = value
    else:
        raw = re.split(r'[,;\n]+', str(value or ''))
    tags = []
    seen = set()
    for tag in raw:
        tag = str(tag).strip()
        if not tag:
            continue
        key = tag.casefold()
        if key not in seen:
            seen.add(key)
            tags.append(tag[:60])
    return tags


def normalize_audience(value):
    return 'Mature' if str(value or '').casefold() == 'mature' else 'Safe'


def tag_catalog(characters=()):
    result = list(TAG_CATALOG)
    found = {tag.casefold() for tag in result}
    custom = set()
    for character in characters:
        for tag in normalize_tags(character.get('tags')):
            if tag.casefold() not in found:
                custom.add(tag)
    result.extend(sorted(custom, key=str.casefold))
    return result




def ordered_tags_by_frequency(characters):
    """All known tags, with the most-used tags first (stable ties)."""
    characters = tuple(characters)
    options = tag_catalog(characters)
    counts = Counter(tag.casefold() for character in characters
                     for tag in normalize_tags(character.get('tags')))
    # Stable original-catalog order is the secondary sort key.
    return sorted(options, key=lambda tag: -counts[tag.casefold()])


def visible_discovery_tags(characters, selected_tags=(), search='', expanded=False, limit=12):
    """Return (visible tags, total count) for the collapsible tag picker.

    Searching always examines *all* tags, even when collapsed. Selected tags
    are pinned in the collapsed view so filtering never hides an active chip.
    """
    ordered = ordered_tags_by_frequency(characters)
    lookup = {str(item).casefold() for item in selected_tags}
    query = str(search or '').strip().casefold()
    if query:
        return [tag for tag in ordered if query in tag.casefold() or tag.casefold() in lookup], len(ordered)
    if expanded:
        return ordered, len(ordered)
    primary = ordered[:max(0, int(limit))]
    used = {tag.casefold() for tag in primary}
    primary.extend(tag for tag in ordered if tag.casefold() in lookup and tag.casefold() not in used)
    return primary, len(ordered)


def filter_characters(characters, query='', tag_query='', selected_tags=(), audience='All',
                      featured_only=False, favorites_only=False, sort='Newest'):
    """Selected tags are combined with AND; text/tag searches are case-insensitive."""
    q = str(query).strip().casefold()
    tq = str(tag_query).strip().casefold()
    required = {str(tag).casefold() for tag in selected_tags}
    results = []
    for character in characters:
        tags = {tag.casefold() for tag in normalize_tags(character.get('tags'))}
        if required and not required.issubset(tags):
            continue
        if tq and not any(tq in tag for tag in tags):
            continue
        if audience in ('Safe', 'Mature') and normalize_audience(character.get('audience')) != audience:
            continue
        if featured_only and not bool(character.get('featured')):
            continue
        if favorites_only and not bool(character.get('favorite')):
            continue
        if q:
            haystack = ' '.join(str(character.get(field) or '') for field in
                                ('name', 'short_description', 'personality', 'scenario', 'tags'))
            if q not in haystack.casefold():
                continue
        results.append(character)
    if sort == 'Name A–Z':
        results.sort(key=lambda x: str(x.get('name') or '').casefold())
    elif sort == 'Name Z–A':
        results.sort(key=lambda x: str(x.get('name') or '').casefold(), reverse=True)
    elif sort == 'Favorites first':
        results.sort(key=lambda x: (bool(x.get('favorite')), str(x.get('created_at') or '')), reverse=True)
    else:
        results.sort(key=lambda x: str(x.get('created_at') or ''), reverse=True)
    return results
