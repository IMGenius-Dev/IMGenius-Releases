"""Optional catalog interface (v0.7.0 public builds ship without character cards)."""
from __future__ import annotations

EXPECTED_COUNT = 0

def load_catalog(path=None):
    """Public packages deliberately contain no preloaded character profiles."""
    return []

def seed_character_catalog(store=None, catalog=None):
    """No automatic character seeding. User-generated/imported cards remain intact."""
    return 0
