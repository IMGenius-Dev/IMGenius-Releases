"""SQLite character data access and non-destructive schema upgrades."""
import json
import sqlite3
from datetime import datetime, timezone
from imgenius.shared.paths import DB_PATH
from imgenius.shared.text import safe_text
from imgenius.characters.library import normalize_tags, normalize_audience
from imgenius.characters.lorebook import normalize_lorebook
from imgenius.characters.prompts import DEFAULT_SYSTEM_PROMPT, default_first_message

class CharacterStore:
    def __init__(self, db_path=str(DB_PATH)):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._initialize()

    def _initialize(self):
        self.conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS characters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                gender TEXT,
                pronouns TEXT,
                age TEXT,
                occupation TEXT,
                short_description TEXT,
                personality TEXT,
                backstory TEXT,
                likes TEXT,
                dislikes TEXT,
                voice TEXT,
                speech_style TEXT,
                scenario TEXT,
                world TEXT,
                prompt TEXT,
                style TEXT,
                memory TEXT,
                long_term_memory TEXT,
                example_dialogue TEXT,
                first_message TEXT,
                tags TEXT,
                safety_notes TEXT,
                card_image TEXT,
                audience TEXT NOT NULL DEFAULT 'Safe',
                featured INTEGER NOT NULL DEFAULT 0,
                favorite INTEGER NOT NULL DEFAULT 0,
                reaction INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
            '''
        )
        columns = [row[1] for row in self.conn.execute('PRAGMA table_info(characters)').fetchall()]
        required = [
            'gender', 'personality', 'scenario', 'prompt', 'style', 'memory',
            'pronouns', 'age', 'occupation', 'short_description', 'backstory', 'likes', 'dislikes', 'voice',
            'speech_style', 'world', 'long_term_memory', 'example_dialogue', 'tags', 'safety_notes', 'card_image'
        ]
        for column in required:
            if column not in columns:
                self.conn.execute(f'ALTER TABLE characters ADD COLUMN {column} TEXT')
        for column, definition in (
            ('audience', "TEXT NOT NULL DEFAULT 'Safe'"),
            ('featured', 'INTEGER NOT NULL DEFAULT 0'),
            ('favorite', 'INTEGER NOT NULL DEFAULT 0'),
            ('reaction', 'INTEGER NOT NULL DEFAULT 0'),
            ('system_prompt', 'TEXT'),
            ('first_message', 'TEXT'),
            ('lorebook', "TEXT NOT NULL DEFAULT '[]'"),
        ):
            if column not in columns:
                self.conn.execute(f'ALTER TABLE characters ADD COLUMN {column} {definition}')
        # Existing characters get the new System Prompt; legacy 'prompt' remains archived.
        self.conn.execute('UPDATE characters SET system_prompt=? WHERE system_prompt IS NULL',
                          (DEFAULT_SYSTEM_PROMPT,))
        self.conn.execute("UPDATE characters SET lorebook='[]' WHERE lorebook IS NULL")
        # v0.3.14: backfill only missing greetings, never rewrite customized ones.
        missing = self.conn.execute(
            "SELECT id, name, scenario, example_dialogue, short_description FROM characters "
            "WHERE first_message IS NULL OR TRIM(first_message) = ''"
        ).fetchall()
        for ident, name, scenario, dialogue, description in missing:
            greeting = default_first_message({
                'name': name, 'scenario': scenario, 'example_dialogue': dialogue,
                'short_description': description,
            })
            self.conn.execute('UPDATE characters SET first_message=? WHERE id=?',
                              (greeting, ident))
        self.conn.commit()

    def save_character(self, character):
        payload = {
            'name': safe_text(character.get('name'), 'Unnamed Character') or 'Unnamed Character',
            'gender': safe_text(character.get('gender')),
            'pronouns': safe_text(character.get('pronouns')),
            'age': safe_text(character.get('age')),
            'occupation': safe_text(character.get('occupation')),
            'short_description': safe_text(character.get('short_description')),
            'personality': safe_text(character.get('personality')),
            'backstory': safe_text(character.get('backstory')),
            'likes': safe_text(character.get('likes')),
            'dislikes': safe_text(character.get('dislikes')),
            'voice': safe_text(character.get('voice')),
            'speech_style': safe_text(character.get('speech_style')),
            'scenario': safe_text(character.get('scenario')),
            'world': safe_text(character.get('world')),
            'prompt': safe_text(character.get('prompt')),
            'style': safe_text(character.get('style')),
            'memory': safe_text(character.get('memory')),
            'long_term_memory': safe_text(character.get('long_term_memory')),
            'example_dialogue': safe_text(character.get('example_dialogue')),
            'first_message': safe_text(character.get('first_message')) or default_first_message(character),
            'tags': ', '.join(normalize_tags(character.get('tags'))),
            'safety_notes': safe_text(character.get('safety_notes')),
            'card_image': safe_text(character.get('card_image')),
            'audience': normalize_audience(character.get('audience')),
            'featured': int(bool(character.get('featured'))),
            'favorite': int(bool(character.get('favorite'))),
            'reaction': int(character.get('reaction') or 0) if int(character.get('reaction') or 0) in (-1, 0, 1) else 0,
            'system_prompt': safe_text(character.get('system_prompt')) if character.get('system_prompt') is not None else DEFAULT_SYSTEM_PROMPT,
            'lorebook': json.dumps(normalize_lorebook(character.get('lorebook')), ensure_ascii=False),
            'created_at': datetime.now(timezone.utc).isoformat(),
        }
        self.conn.execute(
            '''
            INSERT INTO characters (
                name, gender, pronouns, age, occupation, short_description, personality,
                backstory, likes, dislikes, voice, speech_style, scenario, world, prompt,
                style, memory, long_term_memory, example_dialogue, tags, safety_notes, card_image, audience, featured, favorite, reaction, created_at, system_prompt, lorebook, first_message
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                payload['name'], payload['gender'], payload['pronouns'], payload['age'], payload['occupation'],
                payload['short_description'], payload['personality'], payload['backstory'], payload['likes'],
                payload['dislikes'], payload['voice'], payload['speech_style'], payload['scenario'], payload['world'],
                payload['prompt'], payload['style'], payload['memory'], payload['long_term_memory'],
                payload['example_dialogue'], payload['tags'], payload['safety_notes'], payload['card_image'],
                payload['audience'], payload['featured'], payload['favorite'], payload['reaction'], payload['created_at'],
                payload['system_prompt'], payload['lorebook'], payload['first_message']
            ),
        )
        self.conn.commit()
        return self.conn.execute('SELECT last_insert_rowid()').fetchone()[0]

    def update_character(self, character_id, character):
        self.conn.execute(
            '''
            UPDATE characters
            SET name = ?, gender = ?, pronouns = ?, age = ?, occupation = ?, short_description = ?, personality = ?,
                backstory = ?, likes = ?, dislikes = ?, voice = ?, speech_style = ?, scenario = ?, world = ?,
                prompt = ?, style = ?, memory = ?, long_term_memory = ?, example_dialogue = ?, tags = ?,
                safety_notes = ?, card_image = ?, audience = ?, featured = ?, favorite = ?, reaction = ?,
                system_prompt = ?, lorebook = ?, first_message = ?
            WHERE id = ?
            ''',
            (
                safe_text(character.get('name'), 'Unnamed Character') or 'Unnamed Character',
                safe_text(character.get('gender')),
                safe_text(character.get('pronouns')),
                safe_text(character.get('age')),
                safe_text(character.get('occupation')),
                safe_text(character.get('short_description')),
                safe_text(character.get('personality')),
                safe_text(character.get('backstory')),
                safe_text(character.get('likes')),
                safe_text(character.get('dislikes')),
                safe_text(character.get('voice')),
                safe_text(character.get('speech_style')),
                safe_text(character.get('scenario')),
                safe_text(character.get('world')),
                safe_text(character.get('prompt')),
                safe_text(character.get('style')),
                safe_text(character.get('memory')),
                safe_text(character.get('long_term_memory')),
                safe_text(character.get('example_dialogue')),
                ', '.join(normalize_tags(character.get('tags'))),
                safe_text(character.get('safety_notes')),
                safe_text(character.get('card_image')),
                normalize_audience(character.get('audience')),
                int(bool(character.get('featured'))),
                int(bool(character.get('favorite'))),
                int(character.get('reaction') or 0) if int(character.get('reaction') or 0) in (-1, 0, 1) else 0,
                safe_text(character.get('system_prompt')) if character.get('system_prompt') is not None else DEFAULT_SYSTEM_PROMPT,
                json.dumps(normalize_lorebook(character.get('lorebook')), ensure_ascii=False),
                safe_text(character.get('first_message')) or default_first_message(character),
                character_id,
            ),
        )
        self.conn.commit()

    def get_character(self, character_id):
        row = self.conn.execute(
            'SELECT id, name, gender, pronouns, age, occupation, short_description, personality, backstory, likes, dislikes, voice, speech_style, scenario, world, prompt, style, memory, long_term_memory, example_dialogue, tags, safety_notes, card_image, audience, featured, favorite, reaction, created_at, system_prompt, lorebook, first_message FROM characters WHERE id = ?',
            (character_id,),
        ).fetchone()
        if row is None:
            return None
        columns = [
            'id', 'name', 'gender', 'pronouns', 'age', 'occupation', 'short_description', 'personality', 'backstory',
            'likes', 'dislikes', 'voice', 'speech_style', 'scenario', 'world', 'prompt', 'style', 'memory',
            'long_term_memory', 'example_dialogue', 'tags', 'safety_notes', 'card_image', 'audience', 'featured', 'favorite', 'reaction', 'created_at', 'system_prompt', 'lorebook', 'first_message'
        ]
        return dict(zip(columns, row))

    def list_characters(self):
        rows = self.conn.execute(
            'SELECT id, name, gender, pronouns, age, occupation, short_description, personality, backstory, likes, dislikes, voice, speech_style, scenario, world, prompt, style, memory, long_term_memory, example_dialogue, tags, safety_notes, card_image, audience, featured, favorite, reaction, created_at, system_prompt, lorebook, first_message FROM characters ORDER BY created_at DESC'
        ).fetchall()
        columns = [
            'id', 'name', 'gender', 'pronouns', 'age', 'occupation', 'short_description', 'personality', 'backstory',
            'likes', 'dislikes', 'voice', 'speech_style', 'scenario', 'world', 'prompt', 'style', 'memory',
            'long_term_memory', 'example_dialogue', 'tags', 'safety_notes', 'card_image', 'audience', 'featured', 'favorite', 'reaction', 'created_at', 'system_prompt', 'lorebook', 'first_message'
        ]
        return [dict(zip(columns, row)) for row in rows]

    def set_character_flags(self, character_id, **changes):
        """Update local library state without overwriting the character profile."""
        allowed = {'favorite', 'featured', 'reaction'}
        if not changes or set(changes) - allowed:
            raise ValueError('Unsupported character state change')
        values = {}
        for key, value in changes.items():
            if key == 'reaction':
                value = int(value)
                if value not in (-1, 0, 1):
                    raise ValueError('Reaction must be -1, 0, or 1')
            else:
                value = int(bool(value))
            values[key] = value
        assignments = ', '.join(f'{key} = ?' for key in values)
        self.conn.execute(f'UPDATE characters SET {assignments} WHERE id = ?',
                          (*values.values(), character_id))
        self.conn.commit()

    def delete_character(self, character_id):
        self.conn.execute('DELETE FROM characters WHERE id = ?', (character_id,))
        self.conn.commit()
