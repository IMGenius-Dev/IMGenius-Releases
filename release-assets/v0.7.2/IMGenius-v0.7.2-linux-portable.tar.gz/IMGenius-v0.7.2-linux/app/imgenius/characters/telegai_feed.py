"""Read TelegAI's publicly served character discovery feed.

The native IMGenius gallery uses TelegAI's directly addressable
``/api/user/foryou`` JSON endpoint, not the HTML ``/foryou`` page,
browser scraping, or an authenticated website session. This
is an experimental third-party interface: TelegAI may change/remove it. Card
previews are NEVER treated as complete character definitions; importing still
uses Chub's supported public character-card export via ``chub.py``.

The response schema was verified against a user-supplied public feed capture:
``bots``, ``has_more``, ``bot_name``, ``id``, ``topics``, ``image_url``, and
``nsfw_image``. ``rating`` is a star score, not an age/content classification.
"""
from __future__ import annotations

import json
from urllib.parse import urljoin
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlencode

import requests

from imgenius.characters.chub import (
    ChubImportError, DOWNLOAD_HOSTS, CDN_BASE, MAX_THUMBNAIL_SIZE,
    _IDENTIFIER_RE, _clean_host, _stream_https,
)

TELEGAI_FEED = 'https://www.telegai.com/api/user/foryou'
TELEGAI_HOSTS = frozenset({'www.telegai.com', 'telegai.com'})
# Unlike the HTML-facing /foryou route, the direct /api/user/foryou
# endpoint was verified in a Firefox private-window JSON response.
MAX_FEED_BYTES = 4 * 1024 * 1024
MAX_RESULTS = 100
SORT_OPTIONS = ('For you', 'Popular', 'Newest', 'Recently updated')
MATURE_TOPICS = frozenset({'nsfw', '18+', 'adult', 'mature', 'explicit', 'r18', 'xxx'})


def classify_topics(topics):
    """Content label from topics, NOT star ``rating`` or ``nsfw_image``.

    A response without a mature topic isn't proof of SFW safety. TelegAI's
    ``nsfw=false`` feed is used for Safe browsing; unrated content remains
    labeled Unrated to avoid inventing an age classification.
    """
    if isinstance(topics, list) and any(isinstance(t, str) and
                                        t.strip().casefold() in MATURE_TOPICS
                                        for t in topics):
        return 'Mature'
    return 'Unrated'


def _safe_avatar_url(value, identifier):
    if isinstance(value, str):
        try:
            host, parsed = _clean_host(value)
            if (host in DOWNLOAD_HOSTS and
                    parsed.path.lower().endswith(('.png', '.jpeg', '.jpg', '.webp'))):
                return value
        except (ValueError, ChubImportError):
            pass
    return f'{CDN_BASE}/{quote(identifier, safe="/_-")}/avatar.webp'


def clean_feed_record(node):
    """Normalize a third-party listing into the existing Qt card schema."""
    if not isinstance(node, dict) or node.get('is_public') is False:
        return None
    identifier = node.get('id')
    name = node.get('bot_name')
    if (not isinstance(identifier, str) or not _IDENTIFIER_RE.fullmatch(identifier) or
            not isinstance(name, str) or not name.strip()):
        return None
    description = node.get('description')
    if not isinstance(description, str):
        description = ''
    raw_topics = node.get('topics')
    tags = ([t.strip()[:70] for t in raw_topics[:40]
             if isinstance(t, str) and t.strip()]
            if isinstance(raw_topics, list) else [])
    content_rating = classify_topics(raw_topics)
    return {
        'id': identifier,
        'name': name.strip()[:160],
        'description': description.strip()[:1800],
        'tags': tags,
        'content_rating': content_rating,
        'mature': content_rating == 'Mature',
        # Portrait rating is distinct from the character's content rating.
        'nsfw_image': node.get('nsfw_image') is True,
        'source_url': f'https://chub.ai/characters/{identifier}',
        'avatar_url': _safe_avatar_url(node.get('image_url'), identifier),
        'image_bytes': b'',
        'created_at': node.get('created_at') if isinstance(node.get('created_at'), str) else '',
        'chats': node.get('nChats') if type(node.get('nChats')) is int else 0,
    }


def parse_feed_response(payload, *, include_mature=False, query='', sort='For you'):
    """Parse TelegAI's page without pretending it is a site-wide search API."""
    if not isinstance(payload, dict) or not isinstance(payload.get('bots'), list):
        raise ChubImportError('Chub catalog feed changed its response format (missing bots list).')
    if sort not in SORT_OPTIONS:
        raise ChubImportError('Unknown Chub sorting option.')
    seen = set()
    records = []
    for node in payload['bots'][:MAX_RESULTS]:
        record = clean_feed_record(node)
        if record is None or record['id'] in seen:
            continue
        seen.add(record['id'])
        if not include_mature and record['mature']:
            continue
        # Even a card without a Mature tag may have an explicitly flagged
        # adult portrait. Keep the card visible, but suppress that thumbnail
        # while Safe browsing is enabled.
        record['image_hidden'] = bool(not include_mature and record['nsfw_image'])
        records.append(record)
    # Only filter the returned feed page. This route has no observed `search`
    # parameter, so claiming a catalog-wide server search would mislead users.
    normalized = query.strip().casefold()
    if normalized:
        records = [r for r in records if normalized in (
            r['name'] + ' ' + r['description'] + ' ' + ' '.join(r['tags'])
        ).casefold()]
    if sort in {'Newest', 'Recently updated'}:
        records.sort(key=lambda r: r['created_at'], reverse=True)
    elif sort == 'Popular':
        records.sort(key=lambda r: r['chats'], reverse=True)
    # TelegAI supplies an authoritative page-continuation signal; `count`
    # describes only returned items, NOT the total size of the public catalog.
    has_more = payload.get('has_more') is True
    return records, has_more


def _request_public_feed(session, url, *, cancelled=None):
    """Fetch the direct JSON API route, never the similarly named HTML page.

    The /foryou website route returns HTML to a Python HTTP client even when
    asked for JSON. A Firefox private-window test showed that the public
    /api/user/foryou route returns the bots JSON. No browser cookies or
    authentication tokens are required by IMGenius. Redirects remain restricted
    to TelegAI HTTPS hosts.
    """
    headers = {
        'User-Agent': 'IMGenius/0.5 Public Character Discovery',
        'Accept': 'application/json',
    }
    for _ in range(4):
        host, parsed = _clean_host(url)
        if host not in TELEGAI_HOSTS:
            raise ChubImportError('Chub catalog feed redirected outside its trusted source.')
        if cancelled is not None and cancelled.is_set():
            raise ChubImportError('Discovery cancelled.')
        try:
            response = session.get(url, headers=headers, stream=True,
                                   allow_redirects=False, timeout=(8, 35))
        except requests.RequestException as exc:
            raise ChubImportError('Could not reach the Chub catalog feed. Check your network connection.') from exc
        try:
            status = response.status_code
            if status in (301, 302, 303, 307, 308):
                location = response.headers.get('Location')
                if not location:
                    raise ChubImportError(f'Chub catalog feed returned HTTP {status} without a redirect target.')
                url = urljoin(url, location)
                continue
            if status in (401, 403, 451):
                raise ChubImportError(
                    f'Chub catalog feed denied access (HTTP {status}). '
                    'Complete any required website verification; IMGenius does not bypass access restrictions.'
                )
            if status != 200:
                raise ChubImportError(f'Chub catalog feed returned HTTP {status}.')
            content_type = response.headers.get('Content-Type', 'unknown').split(';', 1)[0].strip()
            try:
                length = int(response.headers.get('Content-Length') or '0')
            except (TypeError, ValueError):
                length = 0
            if length > MAX_FEED_BYTES:
                raise ChubImportError('Chub catalog feed exceeds the allowed 4 MiB size.')
            chunks, total = [], 0
            for chunk in response.iter_content(chunk_size=65536):
                if cancelled is not None and cancelled.is_set():
                    raise ChubImportError('Discovery cancelled.')
                total += len(chunk)
                if total > MAX_FEED_BYTES:
                    raise ChubImportError('Chub catalog feed exceeds the allowed 4 MiB size.')
                chunks.append(chunk)
            blob = b''.join(chunks)
            try:
                return json.loads(blob.decode('utf-8-sig'))
            except (UnicodeError, ValueError) as exc:
                kind = ('HTML' if blob.lstrip().lower().startswith((b'<!doctype html', b'<html'))
                        else 'non-JSON data')
                raise ChubImportError(
                    f'Chub catalog feed did not return JSON: '
                    f'/api/user/foryou returned HTTP 200 ({content_type}; {kind}). '
                    'The upstream provider may have changed its API or require additional permissions. '
                    'IMGenius does not use or request browser cookies or access tokens.'
                ) from exc
        except requests.RequestException as exc:
            raise ChubImportError('Chub catalog feed download was interrupted.') from exc
        finally:
            response.close()
    raise ChubImportError('Chub catalog feed redirected too many times.')


def browse_telegai_feed(*, query='', page=1, sort='For you', mature=False,
                         with_images=True, session=None, cancelled=None):
    """Fetch public TelegAI card previews and optional thumbnail bytes.

    No cookies, browser session, access token, or age-gate bypass is used.
    The caller is responsible for its existing 18+ local confirmation.
    """
    if not isinstance(query, str) or len(query) > 150:
        raise ChubImportError('Search text is too long.')
    if type(page) is not int or not 1 <= page <= 10000:
        raise ChubImportError('Page number is out of range.')
    if sort not in SORT_OPTIONS:
        raise ChubImportError('Unknown Chub sorting option.')
    if type(mature) is not bool:
        raise ChubImportError('Invalid mature-content selection.')
    params = urlencode({'page': page, 'nsfw': 'true' if mature else 'false'})
    own_session = session is None
    session = session or requests.Session()
    payload = _request_public_feed(session, f'{TELEGAI_FEED}?{params}', cancelled=cancelled)
    records, has_more = parse_feed_response(payload, include_mature=mature,
                                            query=query, sort=sort)
    if with_images:
        def fetch_thumbnail(record, download_session):
            if record.get('image_hidden'):
                return b''
            if cancelled is not None and cancelled.is_set():
                raise ChubImportError('Discovery cancelled.')
            try:
                image = _stream_https(download_session, record['avatar_url'],
                                      accepted_hosts=DOWNLOAD_HOSTS,
                                      max_bytes=MAX_THUMBNAIL_SIZE, cancelled=cancelled)
                if image.startswith((b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'RIFF')):
                    return image
            except ChubImportError:
                pass  # A missing thumbnail should never block the card.
            return b''

        # The feed normally contains ~42 cards; do not wait for 42 network
        # transfers one-by-one. Each worker owns its own Session, so no
        # requests.Session object is shared between threads. Injected test
        # sessions deliberately use the predictable sequential path.
        if len(records) > 1 and own_session:
            def download_with_own_session(record):
                with requests.Session() as isolated:
                    return fetch_thumbnail(record, isolated)
            with ThreadPoolExecutor(max_workers=6) as pool:
                for record, image in zip(records, pool.map(download_with_own_session, records)):
                    record['image_bytes'] = image
        else:
            for record in records:
                record['image_bytes'] = fetch_thumbnail(record, session)
    return records, has_more
