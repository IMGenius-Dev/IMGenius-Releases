"""IMGenius visual assets used in source and PyInstaller builds."""
from pathlib import Path
from imgenius.shared.paths import ASSET_DIR


def assets_dir():
    """Resolve bundled files without needing network access or a working cwd."""
    return ASSET_DIR


def app_icon_path():
    return assets_dir() / 'IMGenius.png'


def sidebar_icon_path(page):
    name = str(page).replace('/', '').replace('\\', '')
    return assets_dir() / 'nav' / f'{name}.png'
