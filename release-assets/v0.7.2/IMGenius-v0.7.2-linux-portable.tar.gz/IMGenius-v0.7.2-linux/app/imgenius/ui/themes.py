"""Cross-platform IMGenius themes, with no optional Qt theme packages.

Breeze is a KDE-Breeze-inspired palette.  The app works without the desktop
Breeze style plugin on Windows as well as Linux.
"""
from __future__ import annotations
import re

THEMES = ('Breeze', 'Dark', 'Black', 'Light', 'Ocean', 'Plum')

# Original CSS color -> semantic theme role. All stylesheet colors are covered;
# this prevents Light/Breeze retaining hard-coded dark boxes.
_COLOR_GROUPS = {
    'background': '#111421',
    'field': '#111625 #121725',
    'header': '#151929',
    'panel': '#161b2a #1a2031 #1b2030',
    'sidebar': '#181c2b',
    'bubble': '#1d2435',
    'tag': '#1b2232 #222a43 #252d40 #303a53',
    'selected': '#202b43 #2b405f #2c3456 #33476b #344664 #415b97 #424b70',
    'button': '#23293a #283249 #2a3045',
    'disabled': '#242735',
    'hover': '#25334c #27394c #29314a #363f5d',
    'accent_soft': '#25547a',
    'accent': '#27779a #287fa6 #4798c4',
    'accent_hover': '#338faf #3693be #45add9 #56b3e2 #5ba7d8 #68bce8 #69c4ff #71c8fc #78bff1 #7ecfff #81c6f0',
    'bubble_user': '#2d4f80',
    'border': '#30384e #323b52 #333951 #34384a #35405a #36415c #36435c #3b4e64 #3c465e #3c4761 #464f6a #46506e #465676 #47516c #56657a #566b8f #4f76a7',
    'muted': '#647087 #98a3c7 #99aac8 #a6adc3 #b1bfda #b5bfd5 #b7cbe8 #bac5e6',
    'disabled_text': '#72798c',
    'accent_text': '#a1ddff #a8e4ff #b8e1ff #bcddfa #c0befd',
    'success': '#8adfd8',
    'text': '#d5e3fa #e2edff #e5e9f5 #e8f9ff #ebedff #edf2ff #eef2ff #f0f5ff #f1f8ff #f2f6ff #f3f4ff',
}
SOURCE_ROLES = {color: role for role, value in _COLOR_GROUPS.items() for color in value.split()}

PRESETS = {
    'Breeze': dict(background='#eff1f4', field='#ffffff', header='#e7ebf0',
        sidebar='#e9edf3', panel='#ffffff', bubble='#f1f5fa', tag='#e2eaf4',
        selected='#d6e8f8', button='#e3e9f1', disabled='#e8eaed',
        hover='#dce6f3', accent_soft='#bbd8f0', accent='#2477bb',
        accent_hover='#3690d1', bubble_user='#2477bb', border='#bfccd8',
        muted='#53647a', disabled_text='#7b8494', accent_text='#17679e',
        success='#137d70', text='#1d2938', user_text='#ffffff'),
    'Dark': dict(background='#111421', field='#111625', header='#151929',
        sidebar='#181c2b', panel='#1a2031', bubble='#1d2435', tag='#252d40',
        selected='#33476b', button='#2a3045', disabled='#242735',
        hover='#363f5d', accent_soft='#25547a', accent='#27779a',
        accent_hover='#45add9', bubble_user='#2d4f80', border='#3c4761',
        muted='#a6adc3', disabled_text='#72798c', accent_text='#a1ddff',
        success='#8adfd8', text='#e5e9f5', user_text='#ffffff'),
    'Black': dict(background='#07090c', field='#0c0e12', header='#0c0d10',
        sidebar='#090b0f', panel='#14161c', bubble='#191c23', tag='#1c2028',
        selected='#243a55', button='#242833', disabled='#171a20',
        hover='#303542', accent_soft='#193950', accent='#176da5',
        accent_hover='#2da0d7', bubble_user='#20527d', border='#343943',
        muted='#a2a6b2', disabled_text='#636873', accent_text='#9cdeff',
        success='#75d0b9', text='#f1f3f7', user_text='#ffffff'),
    'Light': dict(background='#faf9f7', field='#ffffff', header='#f1f1ef',
        sidebar='#f0f0ee', panel='#ffffff', bubble='#f3f3f3', tag='#ebe9e5',
        selected='#dfedff', button='#e9edf3', disabled='#efefef',
        hover='#dfe8f5', accent_soft='#cbdcf7', accent='#2563a6',
        accent_hover='#3379be', bubble_user='#285f9f', border='#c9cbd1',
        muted='#596472', disabled_text='#8b9098', accent_text='#205d91',
        success='#177b68', text='#252931', user_text='#ffffff'),
    'Ocean': dict(background='#091c28', field='#0b2532', header='#0b2030',
        sidebar='#102838', panel='#123042', bubble='#173649', tag='#1b4554',
        selected='#215d6f', button='#205063', disabled='#193542',
        hover='#28677c', accent_soft='#146477', accent='#07889c',
        accent_hover='#29b9ce', bubble_user='#167588', border='#366675',
        muted='#a2c8d0', disabled_text='#6d9ba8', accent_text='#a3f3ff',
        success='#7ce2c7', text='#e7f9fa', user_text='#ffffff'),
    'Plum': dict(background='#191420', field='#201829', header='#211a2d',
        sidebar='#241c30', panel='#2b2136', bubble='#30263d', tag='#3b2a48',
        selected='#563b75', button='#44324e', disabled='#302738',
        hover='#594363', accent_soft='#57365b', accent='#9462bb',
        accent_hover='#bd87df', bubble_user='#66428c', border='#66516f',
        muted='#c7b3d2', disabled_text='#8d7b97', accent_text='#edc1ff',
        success='#97dbc3', text='#f4e9f8', user_text='#ffffff'),
}


def theme_palette(name):
    return PRESETS.get(name, PRESETS['Dark'])


def build_theme_stylesheet(base_css, name, font_family):
    """Render the legacy QSS with every color replaced for the selected theme."""
    palette = theme_palette(name)
    base = base_css.replace('__IMG_FAMILY__', font_family.replace('"', ''))
    if name == 'Dark':
        return base
    def replace(match):
        source = match.group().lower()
        role = SOURCE_ROLES.get(source)
        if role is None:
            return source
        return palette[role]
    rewritten = re.sub(r'#[a-fA-F0-9]{6}\b', replace, base)
    return rewritten + f'''\nQToolTip {{background:{palette['panel']};color:{palette['text']};border:1px solid {palette['border']};}}\nQPushButton#Primary, QPushButton#SendIcon {{ color:#ffffff; }}\nQFrame#ChatBubbleUser QLabel#ChatMeta, QFrame#ChatBubbleUser QLabel#ChatText {{color:{palette['user_text']};}}\n'''
