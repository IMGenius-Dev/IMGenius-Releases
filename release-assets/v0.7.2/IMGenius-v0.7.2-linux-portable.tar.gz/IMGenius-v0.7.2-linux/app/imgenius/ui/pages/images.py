"""Images page: layout and handlers only."""
from __future__ import annotations

from PIL import Image
from PySide6.QtCore import QSize
from PySide6.QtCore import QUrl
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QDesktopServices
from PySide6.QtGui import QIcon
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFileDialog, QInputDialog, QMessageBox, QApplication
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QGridLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QListView
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QListWidgetItem
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.domain import DATA_DIR
from imgenius.images.comfy import build_workflow
from imgenius.images.prompt_library import ImagePromptLibrary
from imgenius.images.comfy import comfy_choices
from imgenius.images.comfy import comfy_object_info
from imgenius.images.comfy import generate_image
from imgenius.images.comfy import save_outputs
from imgenius.images.comfy import upload_image
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import dspin
from imgenius.ui.widgets.controls import make_card
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import section_panel
from imgenius.ui.widgets.controls import spin
from imgenius.ui.widgets.controls import textedit
from imgenius.ui.widgets.visuals import ClickableImageLabel, LightboxDialog
from pathlib import Path
import json


class ImageStudioPageMixin:
    def _make_images(self):
        outer, body = scroll_content()
        body.addWidget(section_label('SDXL / Illustrious. ComfyUI runs the inference; IMGenius handles the workflow and gallery.'))

        top_row = QHBoxLayout()
        self.image_mode = NoWheelComboBox()
        self.image_mode.addItems(['Text to image', 'Image to image'])
        top_row.addWidget(QLabel('Mode'))
        top_row.addWidget(self.image_mode)
        self.image_preset = NoWheelComboBox()
        self.image_preset.addItems(['SDXL', 'Illustrious XL'])
        self.image_preset.currentIndexChanged.connect(self.apply_image_preset)
        top_row.addWidget(QLabel('Preset'))
        top_row.addWidget(self.image_preset)
        self.refresh_image_models_button = button('Refresh checkpoints + LoRAs', self.refresh_comfy_models)
        top_row.addWidget(self.refresh_image_models_button)
        top_row.addStretch(1)
        body.addLayout(top_row)

        workspace = QHBoxLayout()
        workspace.setSpacing(16)
        left_col = QVBoxLayout()
        left_col.setSpacing(15)
        right_col = QVBoxLayout()
        right_col.setSpacing(15)
        workspace.addLayout(left_col, 7)
        workspace.addLayout(right_col, 3)
        body.addLayout(workspace)

        main = make_card('Prompt & source', left_col)
        main.addWidget(QLabel('Positive prompt'))
        self.image_prompt = textedit('Describe the image…', 105)
        main.addWidget(self.image_prompt)
        main.addWidget(QLabel('Negative prompt'))
        self.image_negative = textedit('Things to avoid…', 75)
        main.addWidget(self.image_negative)

        preset_tools = QHBoxLayout()
        preset_tools.setSpacing(8)
        preset_tools.addWidget(QLabel('Saved negatives'))
        self.negative_preset_combo = NoWheelComboBox()
        self.negative_preset_combo.setMinimumWidth(155)
        self.negative_preset_combo.setToolTip('Select a named preset to paste it into the negative prompt field.')
        self.negative_preset_combo.currentIndexChanged.connect(self.load_negative_prompt_preset)
        preset_tools.addWidget(self.negative_preset_combo, 1)
        preset_tools.addWidget(button('Save as preset…', self.save_negative_prompt_preset))
        preset_tools.addWidget(button('Delete preset', self.delete_negative_prompt_preset))
        main.addLayout(preset_tools)
        self.image_source_area = QWidget()
        source_row = QHBoxLayout(self.image_source_area)
        source_row.setContentsMargins(0,0,0,0)
        self.image_source = QLineEdit()
        self.image_source.setReadOnly(True)
        self.image_source.setPlaceholderText('Choose a source PNG/JPEG/WebP for img2img')
        source_row.addWidget(self.image_source, 1)
        source_row.addWidget(button('Browse…', self.choose_source_image))
        main.addWidget(self.image_source_area)
        self.image_mode.currentIndexChanged.connect(self.update_image_mode)

        options = make_card('Checkpoint & sampling', left_col)
        settings_grid = QGridLayout()
        self.checkpoint = NoWheelComboBox()
        self.checkpoint.setEditable(False)
        self.checkpoint.setMinimumWidth(260)
        self.image_width = spin(1024,256,2048,64)
        self.image_height = spin(1024,256,2048,64)
        self.image_steps = spin(28,1,150)
        self.image_cfg = dspin(6.0,1,30,.5)
        self.image_seed = QLineEdit('-1')
        self.image_seed.setToolTip('Use -1 to randomize each generation')
        self.image_batch = spin(1,1,4)
        self.image_denoise = dspin(.55,.05,1,.05)
        self.image_sampler = NoWheelComboBox()
        self.image_sampler.addItems(['dpmpp_2m','dpmpp_2m_sde','euler_ancestral','euler','dpmpp_sde','ddim'])
        self.image_scheduler = NoWheelComboBox()
        self.image_scheduler.addItems(['karras','normal','sgm_uniform','exponential','simple'])
        self.clip_skip = spin(1,1,8)
        fields = [('Checkpoint',self.checkpoint), ('Width',self.image_width),
                  ('Height',self.image_height), ('Steps',self.image_steps),
                  ('CFG',self.image_cfg), ('Seed (-1 = random)',self.image_seed),
                  ('Batch (VRAM intensive)',self.image_batch), ('Denoise (img2img)',self.image_denoise),
                  ('Sampler',self.image_sampler), ('Scheduler',self.image_scheduler),
                  ('CLIP skip',self.clip_skip)]
        for i, (label, field) in enumerate(fields):
            r, c = divmod(i, 2)
            settings_grid.addWidget(QLabel(label),r,c*2)
            settings_grid.addWidget(field,r,c*2+1)
        options.addLayout(settings_grid)

        lora_layout = make_card('LoRAs', left_col)
        lora_layout.addWidget(section_label('Optional style/character adapters; adjustable per model.'))
        self.lora_holder = QVBoxLayout()
        lora_layout.addLayout(self.lora_holder)
        lora_layout.addWidget(button('+ Add LoRA', self.add_lora_row))

        second_layout = make_card('Optional refinement / high resolution', left_col)
        refinement_grid = QFormLayout()
        self.refine_scale = dspin(1.0,1.0,2.0,.1)
        self.refine_steps = spin(12,1,100)
        self.refine_denoise = dspin(.30,.05,1.0,.05)
        refinement_grid.addRow('Scale (1 = off)', self.refine_scale)
        refinement_grid.addRow('Second-pass steps', self.refine_steps)
        refinement_grid.addRow('Second-pass denoise', self.refine_denoise)
        second_layout.addLayout(refinement_grid)

        controls = QHBoxLayout()
        controls.addWidget(button('Export workflow JSON', self.export_workflow))
        controls.addWidget(button('Generate', self.start_image_generation, True))
        controls.addWidget(button('Stop waiting', self.cancel_image_generation))
        controls.addStretch(1)
        left_col.addLayout(controls)
        self.image_status = section_label('No image generated this session.')
        left_col.addWidget(self.image_status)

        preview_group, preview_layout = section_panel('Preview')
        self.image_preview_panel = preview_group
        # The portrait/landscape image determines the preview's height. Unlike
        # an expanding QLabel, this section never reserves a large empty box.
        self.image_preview = ClickableImageLabel('Generated images appear here.')
        self.image_preview.setObjectName('ImageStudioPreview')
        self.image_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_preview.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.image_preview.setFixedSize(250, 160)
        self.image_preview.setWordWrap(True)
        self.image_preview.setStyleSheet('background:#111625;border:1px solid #3c4761;border-radius:12px;')
        self.image_preview.clicked.connect(self.enlarge_image_preview)
        preview_layout.addWidget(self.image_preview, 0, Qt.AlignmentFlag.AlignHCenter)
        self.image_preview_meta = section_label('No image selected. Click a preview to enlarge.')
        self.image_preview_meta.setWordWrap(True)
        self.image_preview_meta.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        preview_layout.addWidget(self.image_preview_meta)
        # Only the image consumes preview height; spare vertical space belongs
        # to the previous-images browser below it.
        right_col.addWidget(preview_group, 0)
        self.image_preview_panel.installEventFilter(self)

        recent_group, recent_layout = section_panel('Previous images')
        self.image_recent = QListWidget()
        self.image_recent.setViewMode(QListView.ViewMode.IconMode)
        self.image_recent.setResizeMode(QListView.ResizeMode.Adjust)
        self.image_recent.setMovement(QListView.Movement.Static)
        self.image_recent.setWrapping(True)
        self.image_recent.setSpacing(10)
        self.image_recent.setIconSize(QSize(150, 150))
        self.image_recent.setMinimumHeight(260)
        self.image_recent.itemSelectionChanged.connect(self.image_browser_selected)
        self.image_recent.itemDoubleClicked.connect(self.open_recent_image)
        recent_layout.addWidget(self.image_recent)
        thumb_actions = QHBoxLayout()
        thumb_actions.addWidget(button('Open image', self.open_recent_image))
        thumb_actions.addWidget(button('Refresh list', self.refresh_image_browser))
        thumb_actions.addStretch(1)
        recent_layout.addLayout(thumb_actions)
        right_col.addWidget(recent_group, 1)

        self.current_preview_path = None
        self._image_preview_original = QPixmap()
        self._image_preview_reflow_scheduled = False
        self._init_image_prompt_library()
        self.update_image_mode()
        self.register_page('images', outer)

    def _init_image_prompt_library(self):
        self.image_prompt_library = ImagePromptLibrary()
        # Load before connecting textChanged to avoid unnecessary writes.
        self.image_prompt.setPlainText(self.image_prompt_library.last_positive)
        self.image_negative.setPlainText(self.image_prompt_library.last_negative)
        self._refresh_negative_preset_list()
        self.image_prompt_save_timer = QTimer(self)
        self.image_prompt_save_timer.setSingleShot(True)
        self.image_prompt_save_timer.setInterval(350)
        self.image_prompt_save_timer.timeout.connect(self._persist_image_prompts)
        self.image_prompt.textChanged.connect(self._image_prompt_changed)
        self.image_negative.textChanged.connect(self._image_prompt_changed)

    def _image_prompt_changed(self):
        if self.negative_preset_combo.currentData() is not None:
            name = self.negative_preset_combo.currentData()
            if self.image_negative.toPlainText() != self.image_prompt_library.get_negative_preset(name):
                self.negative_preset_combo.blockSignals(True)
                self.negative_preset_combo.setCurrentIndex(0)
                self.negative_preset_combo.blockSignals(False)
        self.image_prompt_save_timer.start()

    def _persist_image_prompts(self):
        if not hasattr(self, 'image_prompt_library'):
            return
        if hasattr(self, 'image_prompt_save_timer'):
            self.image_prompt_save_timer.stop()
        try:
            self.image_prompt_library.update_drafts(
                self.image_prompt.toPlainText(), self.image_negative.toPlainText()
            )
        except (OSError, ValueError) as exc:
            self.status(f'Unable to save image prompt: {exc}')

    def _refresh_negative_preset_list(self, select_name=None):
        combo = self.negative_preset_combo
        combo.blockSignals(True)
        combo.clear()
        combo.addItem('Choose saved negative…', None)
        for name in sorted(self.image_prompt_library.negative_presets, key=str.casefold):
            combo.addItem(name, name)
        index = combo.findData(select_name) if select_name else 0
        combo.setCurrentIndex(index if index >= 0 else 0)
        combo.blockSignals(False)

    def load_negative_prompt_preset(self, *_):
        name = self.negative_preset_combo.currentData()
        if name is None:
            return
        content = self.image_prompt_library.get_negative_preset(name)
        if content is None:
            return
        self.image_negative.setPlainText(content)
        self._persist_image_prompts()
        self.status(f'Negative preset loaded: {name}')

    def save_negative_prompt_preset(self):
        content = self.image_negative.toPlainText()
        if not content.strip():
            self.error('Enter a negative prompt before saving it as a preset.')
            return
        suggested = self.negative_preset_combo.currentData() or ''
        name, accepted = QInputDialog.getText(
            self, 'Save negative prompt', 'Preset name:', text=suggested
        )
        if not accepted:
            return
        name = name.strip()
        existing = name in self.image_prompt_library.negative_presets
        if existing:
            decision = QMessageBox.question(
                self, 'Replace saved preset?',
                f'Replace the negative prompt stored as "{name}"?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if decision != QMessageBox.StandardButton.Yes:
                return
        try:
            self.image_prompt_library.save_negative_preset(name, content, replace=existing)
        except (ValueError, OSError) as exc:
            self.error(exc)
            return
        self._refresh_negative_preset_list(name)
        self._persist_image_prompts()
        self.status(f'Saved negative preset: {name}')

    def delete_negative_prompt_preset(self):
        name = self.negative_preset_combo.currentData()
        if name is None:
            self.status('Select a saved negative prompt to delete it.')
            return
        decision = QMessageBox.question(
            self, 'Delete saved negative prompt?',
            f'Delete the preset "{name}"? The text currently in the editor will be kept.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if decision != QMessageBox.StandardButton.Yes:
            return
        try:
            self.image_prompt_library.delete_negative_preset(name)
        except OSError as exc:
            self.error(exc)
            return
        self._refresh_negative_preset_list()
        self.status(f'Deleted negative preset: {name}')

    def enlarge_image_preview(self):
        pixmap = getattr(self, '_image_preview_original', QPixmap())
        if pixmap is None or pixmap.isNull():
            return
        overlay = LightboxDialog(pixmap, self)
        # Qt top-level dialog geometry uses screen coordinates.
        overlay.setGeometry(self.geometry())
        overlay.exec()

    def _schedule_image_preview_reflow(self):
        if getattr(self, '_image_preview_reflow_scheduled', False):
            return
        self._image_preview_reflow_scheduled = True
        QTimer.singleShot(0, self._deferred_image_preview_reflow)

    def _deferred_image_preview_reflow(self):
        self._image_preview_reflow_scheduled = False
        self._resize_image_preview()

    def _resize_image_preview(self):
        if not hasattr(self, 'image_preview'):
            return
        pixmap = getattr(self, '_image_preview_original', QPixmap())
        if pixmap is None or pixmap.isNull():
            self.image_preview.set_image_state(False)
            if self.image_preview.size() != QSize(250, 160):
                self.image_preview.setFixedSize(250, 160)
            return
        # Respect the panel width and the usable window height. The preview
        # frame fits the scaled image itself, not a fixed 320px+ empty region.
        panel = self.image_preview_panel
        width = max(160, min(700, panel.contentsRect().width() - 50))
        height = max(210, min(560, self.height() - 235))
        new_pix = pixmap.scaled(QSize(width, height),
                                Qt.AspectRatioMode.KeepAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
        if self.image_preview.size() != new_pix.size():
            self.image_preview.setFixedSize(new_pix.size())
        # QLabel.setText() clears its pixmap; clear the placeholder first.
        self.image_preview.setText('')
        self.image_preview.setPixmap(new_pix)
        self.image_preview.set_image_state(True)

    def update_image_mode(self, *_):
        mode = self.image_mode.currentIndex() == 1
        self.image_source_area.setVisible(mode)
        self.image_denoise.setEnabled(mode)

    def apply_image_preset(self, *_):
        if self.image_preset.currentIndex() == 1:  # Illustrious
            self.image_steps.setValue(28)
            self.image_cfg.setValue(5.0)
            self.image_sampler.setCurrentText('euler_ancestral')
            self.image_scheduler.setCurrentText('normal')
        else:
            self.image_steps.setValue(28)
            self.image_cfg.setValue(6.0)
            self.image_sampler.setCurrentText('dpmpp_2m')
            self.image_scheduler.setCurrentText('karras')

    def choose_source_image(self):
        file, _ = QFileDialog.getOpenFileName(self, 'Choose source image', str(Path.home()),
                                             'Images (*.png *.jpg *.jpeg *.webp)')
        if file: self.image_source.setText(file)

    def add_lora_row(self):
        if len(self.lora_rows) >= 6:
            self.status('Limit: 6 LoRA slots')
            return
        row = QWidget()
        line = QHBoxLayout(row)
        line.setContentsMargins(0,0,0,0)
        name = NoWheelComboBox()
        name.setEditable(False)
        name.setMinimumWidth(180)
        name.addItems([''] + comfy_choices(self.comfy_info,'LoraLoader','lora_name'))
        strength = dspin(.7,-2.0,2.0,.05)
        remove = button('Remove')
        line.addWidget(name, 1)
        line.addWidget(QLabel('Strength'))
        line.addWidget(strength)
        line.addWidget(remove)
        self.lora_holder.addWidget(row)
        entry = (row,name,strength)
        self.lora_rows.append(entry)
        def dispose():
            if entry in self.lora_rows:
                self.lora_rows.remove(entry)
            row.setParent(None)
            row.deleteLater()
        remove.clicked.connect(dispose)

    def refresh_comfy_models(self):
        base = self.comfy_url()
        self.status('Reading ComfyUI models…')
        def task(cancel, token, status): return comfy_object_info(base)
        def done(info):
            self.comfy_info = info
            checkpoints = comfy_choices(info,'CheckpointLoaderSimple','ckpt_name')
            previous = self.checkpoint.currentText()
            self.checkpoint.clear()
            self.checkpoint.addItems(checkpoints)
            if previous and previous in checkpoints:
                self.checkpoint.setCurrentText(previous)
            elif checkpoints:
                self.checkpoint.setCurrentIndex(0)
            if hasattr(self, 'chat_image_checkpoint'):
                self._sync_chat_image_checkpoints(checkpoints)
            loras = comfy_choices(info,'LoraLoader','lora_name')
            for _, picker, _ in self.lora_rows:
                old = picker.currentText()
                picker.clear(); picker.addItems(['']+loras)
                if old and old in loras:
                    picker.setCurrentText(old)
                else:
                    picker.setCurrentIndex(0)
            if not checkpoints:
                self.status('Connected; no checkpoints found in ComfyUI/models/checkpoints')
            else:
                self.status(f'ComfyUI: {len(checkpoints)} checkpoints / {len(loras)} LoRAs')
            self.model_comfy_status.setPlainText('\n'.join(checkpoints) or 'No checkpoints installed.')
        self.run_job(task,done)

    def _image_args(self):
        seed_text = self.image_seed.text().strip()
        try: seed = int(seed_text) if seed_text else -1
        except ValueError: raise ValueError('Seed must be a whole number or -1.')
        return dict(model=self.checkpoint.currentText().strip(),
                    prompt=self.image_prompt.toPlainText().strip(),
                    negative_prompt=self.image_negative.toPlainText().strip(),
                    width=self.image_width.value(), height=self.image_height.value(),
                    steps=self.image_steps.value(), cfg=self.image_cfg.value(),
                    sampler=self.image_sampler.currentText(), scheduler=self.image_scheduler.currentText(),
                    seed=seed, mode='img2img' if self.image_mode.currentIndex() else 'txt2img',
                    input_filename=self.image_source.text().strip() if self.image_mode.currentIndex() else None,
                    denoise=self.image_denoise.value(), clip_skip=self.clip_skip.value(),
                    batch=self.image_batch.value(), upscale=self.refine_scale.value(),
                    refine_steps=self.refine_steps.value(), refine_denoise=self.refine_denoise.value(),
                    loras=[{'name': name.currentText().strip(), 'strength': weight.value()}
                           for _,name,weight in self.lora_rows if name.currentText().strip()])

    def export_workflow(self):
        try:
            args = self._image_args()
            if args['mode'] == 'img2img':
                # A portable workflow refers to the image's basename; upload it before running on ComfyUI.
                args['input_filename'] = Path(args['input_filename']).name
            workflow = build_workflow(**args)
            filename, _ = QFileDialog.getSaveFileName(self,'Save ComfyUI API workflow', 'IMGenius_workflow.json','JSON (*.json)')
            if not filename: return
            Path(filename).write_text(json.dumps(workflow, indent=2), encoding='utf-8')
            self.status('Workflow exported (API format).')
        except (ValueError, OSError) as exc: self.error(exc)

    def start_image_generation(self):
        if self.current_image_worker:
            self.status('Image generation is already running.')
            return
        try:
            args = self._image_args()
            # validate without attempting a network call
            dummy = dict(args)
            if dummy['mode']=='img2img' and not Path(dummy['input_filename'] or '').is_file():
                raise ValueError('Choose an existing source image.')
            build_workflow(**dummy)
        except (ValueError, OSError) as exc:
            self.error(exc)
            return
        self.image_status.setText('Submitting image job to ComfyUI…')
        base = self.comfy_url()
        def task(cancel, token_cb, status_cb):
            actual = dict(args)
            if actual['mode'] == 'img2img':
                status_cb('Uploading reference image…')
                actual['input_filename'] = upload_image(base, actual['input_filename'])
            graph = build_workflow(**actual)
            prompt_id, images = generate_image(base, graph, on_status=status_cb, cancel=cancel)
            return save_outputs(prompt_id, images)
        def done(paths):
            self.current_image_worker = None
            self.image_paths = list(paths)
            if paths:
                self._show_preview(paths[0])
                self.image_status.setText(f'{len(paths)} image(s) saved to {DATA_DIR / "images"}')
                self.refresh_image_browser(paths[0])
                self.refresh_gallery()
            self.status('Image generation complete')
        def fail(message):
            self.current_image_worker = None
            self.image_status.setText(message)
            self.error(message)
        job = self.run_job(task, done, on_status=lambda text: (self.status(text),self.image_status.setText(text)), on_error=fail)
        job.signals.cancelled.connect(self._image_cancelled)
        self.current_image_worker = job

    def _image_cancelled(self, message):
        self.current_image_worker = None
        self.image_status.setText(message)

    def cancel_image_generation(self):
        if self.current_image_worker: self.current_image_worker.cancel_event.set()

    def _show_preview(self, path):
        preview_path = Path(path) if path else None
        self.current_preview_path = preview_path
        if not preview_path or not preview_path.is_file():
            self._image_preview_original = QPixmap()
            self.image_preview.setPixmap(QPixmap())
            self.image_preview.setText('Generated images appear here.')
            self.image_preview_meta.setText('No image selected.')
            self._resize_image_preview()
            return
        pix = QPixmap(str(preview_path))
        if pix.isNull():
            self._image_preview_original = QPixmap()
            self.image_preview.setPixmap(QPixmap())
            self.image_preview.setText(f'Could not preview {preview_path.name}')
            self.image_preview_meta.setText(str(preview_path))
            self._resize_image_preview()
            return
        self._image_preview_original = pix
        self._resize_image_preview()
        self.image_preview_meta.setText(f'{preview_path.name}  •  {pix.width()}×{pix.height()}  ·  Click to enlarge')

    def refresh_image_browser(self, select_path=None):
        folder = DATA_DIR / 'images'
        self.image_recent.clear()
        chosen = str(Path(select_path)) if select_path else None
        if folder.exists():
            files = sorted((p for p in folder.iterdir() if p.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp')),
                           key=lambda p: p.stat().st_mtime, reverse=True)
            for p in files:
                pix = QPixmap(str(p))
                icon = QIcon(pix.scaled(150, 150, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)) if not pix.isNull() else QIcon()
                item = QListWidgetItem(icon, p.name)
                item.setData(Qt.ItemDataRole.UserRole, str(p))
                item.setToolTip(str(p))
                item.setSizeHint(QSize(170, 190))
                self.image_recent.addItem(item)
                if chosen and str(p) == chosen:
                    self.image_recent.setCurrentItem(item)
            if self.image_recent.currentRow() < 0 and self.image_recent.count():
                self.image_recent.setCurrentRow(0)
        if self.image_recent.currentItem() is None and self.current_preview_path:
            self._show_preview(self.current_preview_path)

    def image_browser_selected(self):
        item = self.image_recent.currentItem()
        if not item:
            return
        self._show_preview(Path(item.data(Qt.ItemDataRole.UserRole)))

    def open_recent_image(self, *_):
        item = self.image_recent.currentItem()
        if not item:
            return
        path = Path(item.data(Qt.ItemDataRole.UserRole))
        if path.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.resolve())))

