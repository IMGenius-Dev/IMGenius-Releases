"""Chats page: layout and handlers only."""
from __future__ import annotations

from PySide6.QtCore import QSize
from PySide6.QtCore import QTimer
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QFrame
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QLayout
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QListWidgetItem
from PySide6.QtWidgets import QMessageBox
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QScrollArea
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QSplitter
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.characters.library import TAG_ICONS
from imgenius.characters.library import normalize_audience
from imgenius.characters.library import normalize_tags
from imgenius.domain import apply_tokens
from imgenius.domain import build_character_prompt
from imgenius.domain import default_first_message
from imgenius.domain import resolve_character_image
from imgenius.domain import safe_text
from imgenius.images.comfy import ollama_chat
from imgenius.images.comfy import build_workflow, generate_image, save_outputs
from imgenius.chats.scene_images import SCENE_SYSTEM, clean_scene_prompt, scene_prompt_messages
from imgenius.chats.generation import save_assistant_reply
from imgenius.domain import DATA_DIR
from pathlib import Path
from imgenius.ui.widgets.characters import FlowLayout
from imgenius.ui.widgets.chats import ChatBubbleWidget
from imgenius.ui.widgets.chats import ChatHistoryList
from imgenius.ui.widgets.chats import ChatImageWidget
from imgenius.ui.widgets.chats import MessageEditDialog
from imgenius.ui.widgets.chats import ConversationRow
from imgenius.ui.widgets.chats import PersonaEditorDialog
from imgenius.ui.widgets.chats import SendTextEdit
from imgenius.ui.widgets.chats import send_button_icon
from imgenius.ui.widgets.controls import ContextSizeCombo
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import SettingSlider
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import section_panel
from imgenius.ui.widgets.controls import spin, dspin
from imgenius.ui.widgets.visuals import ClickableImageLabel


class ChatsPageMixin:
    def _make_chats(self):
        root = QWidget()
        layout = QHBoxLayout(root)
        layout.setContentsMargins(18, 15, 18, 16)
        splitter = QSplitter(Qt.Orientation.Horizontal)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.addWidget(section_label('Conversations'))
        self.chat_list = QListWidget()
        self.chat_list.setObjectName('ConversationList')
        self.chat_list.setSpacing(5)
        self.chat_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.chat_list.setVerticalScrollMode(QListWidget.ScrollMode.ScrollPerPixel)
        self.chat_list.itemSelectionChanged.connect(self.select_chat)
        left_layout.addWidget(self.chat_list, 1)
        footer_actions = QHBoxLayout()
        footer_actions.addWidget(button('+ New chat', self.new_chat, True), 1)
        self.delete_selected_chat_button = button('Delete selected', self.delete_selected_chat)
        footer_actions.addWidget(self.delete_selected_chat_button)
        left_layout.addLayout(footer_actions)
        splitter.addWidget(left)

        middle = QWidget()
        middle_layout = QVBoxLayout(middle)
        middle_layout.setContentsMargins(6, 0, 0, 0)
        self.chat_heading = QLabel('Choose a chat')
        self.chat_heading.setStyleSheet('font-size:18px;font-weight:700;color:#eef3ff;')
        middle_layout.addWidget(self.chat_heading)
        self.chat_subheading = QLabel('Select a conversation or start a new one.')
        self.chat_subheading.setObjectName('Muted')
        # A character's scenario can be thousands of words. Do not let it
        # expand this header and squeeze the actual messages off-screen.
        self.chat_subheading.setWordWrap(False)
        self.chat_subheading.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        middle_layout.addWidget(self.chat_subheading)

        self.chat_history = ChatHistoryList()
        self.chat_history.setObjectName('ChatHistory')
        self.chat_history.setSpacing(4)
        self.chat_history.setAutoScroll(False)
        self.chat_history.itemSelectionChanged.connect(self.update_chat_action_states)
        # Smoothly follow generated replies; user wheel/scrollbar interactions
        # always take priority over programmatic auto-scrolling.
        self._chat_rendered_id = None
        self._chat_refresh_serial = 0
        self._chat_follow_bottom = False
        self._chat_scroll_timer = QTimer(self.chat_history)
        self._chat_scroll_timer.setInterval(16)
        self._chat_scroll_timer.timeout.connect(self._chat_scroll_step)
        self.chat_history.userScrollStarted.connect(self._chat_user_scrolled)
        bar = self.chat_history.verticalScrollBar()
        bar.sliderPressed.connect(self._chat_user_scrolled)
        bar.sliderReleased.connect(lambda: QTimer.singleShot(0, self._chat_recheck_follow))
        middle_layout.addWidget(self.chat_history, 1)

        # Generation controls stay immediately above the compact message entry.
        composer = QFrame()
        composer.setObjectName('ComposerCard')
        composer_layout = QVBoxLayout(composer)
        composer_layout.setContentsMargins(10, 9, 10, 9)
        composer_layout.setSpacing(7)
        actions = QHBoxLayout()
        actions.setSpacing(6)
        self.regenerate_button = button('Regenerate', lambda: self.regenerate_chat())
        self.continue_button = button('Continue', lambda: self.continue_chat())
        self.chat_image_button = button('Generate scene image', self.generate_chat_scene_image)
        self.stop_button = button('Stop', self.stop_chat)
        actions.addWidget(self.regenerate_button)
        actions.addWidget(self.continue_button)
        actions.addWidget(self.chat_image_button)
        actions.addWidget(self.stop_button)
        actions.addStretch(1)
        composer_layout.addLayout(actions)

        entry_row = QWidget()
        entry_row.setObjectName('ComposerEntryRow')
        entry_layout = QHBoxLayout(entry_row)
        entry_layout.setContentsMargins(0, 0, 0, 0)
        entry_layout.setSpacing(8)
        self.chat_input = SendTextEdit()
        self.chat_input.setPlaceholderText('Type a message…')
        self.chat_input.setFixedHeight(max(69, self.chat_input.fontMetrics().lineSpacing() * 3 + 20))
        self.chat_input.sendRequested.connect(self.send_chat)
        self.chat_input.textChanged.connect(self.update_chat_action_states)
        entry_layout.addWidget(self.chat_input, 1)
        self.send_button = QPushButton()
        self.send_button.setObjectName('SendIcon')
        self.send_button.setIcon(send_button_icon())
        self.send_button.setIconSize(QSize(25, 25))
        self.send_button.setFixedSize(47, 47)
        self.send_button.setToolTip('Send message (Enter)')
        self.send_button.setAccessibleName('Send message')
        self.send_button.clicked.connect(self.send_chat)
        entry_layout.addWidget(self.send_button, 0, Qt.AlignmentFlag.AlignBottom)
        composer_layout.addWidget(entry_row)
        hint = QLabel('Enter to send  ·  Shift+Enter for a new line')
        hint.setObjectName('Hint')
        composer_layout.addWidget(hint)
        middle_layout.addWidget(composer)
        splitter.addWidget(middle)

        # The right panel scrolls independently. This prevents artwork, labels and
        # persona controls from overlapping when the window is shorter.
        right_scroll = QScrollArea()
        right_scroll.setObjectName('ChatControlScroll')
        right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        right_scroll.setFrameShape(QFrame.Shape.NoFrame)
        right_scroll.setMinimumWidth(282)
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(8, 2, 8, 12)
        right_layout.setSpacing(13)
        right_layout.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        right_layout.addWidget(section_label('CHAT CONTROLS'))

        image_card, image_layout = section_panel('Character')
        image_layout.setSpacing(9)
        self.chat_character_image = ClickableImageLabel('No portrait available')
        self.chat_character_image.setObjectName('ChatPortrait')
        self.chat_character_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.chat_character_image.setMinimumSize(160, 140)
        self.chat_character_image.setMaximumWidth(260)
        self.chat_character_image.setStyleSheet('background:#161d30;border:1px solid #364563;border-radius:10px;padding:8px;')
        self.chat_character_image.clicked.connect(lambda: self.open_lightbox(getattr(self, '_chat_character_pixmap', QPixmap())))
        image_layout.addWidget(self.chat_character_image, 0, Qt.AlignmentFlag.AlignHCenter)
        self.chat_character_name = QLabel('No character selected')
        self.chat_character_name.setObjectName('CharacterTitle')
        self.chat_character_name.setWordWrap(True)
        image_layout.addWidget(self.chat_character_name)
        self.chat_character_tag_panel = QWidget()
        self.chat_character_tag_panel.setObjectName('ChatTagsPanel')
        self.chat_character_tag_layout = FlowLayout(self.chat_character_tag_panel, spacing=5)
        self.chat_character_tag_panel.setMinimumHeight(30)
        image_layout.addWidget(self.chat_character_tag_panel)
        right_layout.addWidget(image_card)

        persona_card, persona_layout = section_panel('Persona')
        self.chat_persona = NoWheelComboBox()
        self.chat_persona.currentIndexChanged.connect(self.persona_changed)
        persona_layout.addWidget(self.chat_persona)
        self.chat_user_label = section_label('User: User')
        self.chat_user_label.setWordWrap(True)
        persona_layout.addWidget(self.chat_user_label)
        self.chat_persona_summary = section_label('No persona notes.')
        self.chat_persona_summary.setWordWrap(True)
        persona_layout.addWidget(self.chat_persona_summary)
        persona_buttons = QHBoxLayout()
        persona_buttons.addWidget(button('New', self.new_persona))
        persona_buttons.addWidget(button('Edit', self.edit_persona))
        persona_buttons.addWidget(button('Delete', self.delete_persona))
        persona_layout.addLayout(persona_buttons)
        right_layout.addWidget(persona_card)

        model_card, model_layout = section_panel('LLM settings', QFormLayout)
        model_layout.setSpacing(11)
        self.chat_side_model = NoWheelComboBox()
        self.chat_side_model.setEditable(True)
        self.chat_side_model.addItem('qwen3:4b')
        self.chat_temperature = SettingSlider(.7, 0, 2, .01)
        self.chat_top_p = SettingSlider(.9, 0, 1, .01)
        self.chat_repeat_penalty = SettingSlider(1.1, .1, 3, .01)
        self.chat_context = ContextSizeCombo(4096)
        self.chat_tokens = SettingSlider(512, 128, 16384, 128, decimals=0)
        model_layout.addRow('Model', self.chat_side_model)
        model_layout.addRow('Temperature', self.chat_temperature)
        model_layout.addRow('Top-p', self.chat_top_p)
        model_layout.addRow('Repeat penalty', self.chat_repeat_penalty)
        model_layout.addRow('Context tokens', self.chat_context)
        model_layout.addRow('Max response', self.chat_tokens)
        right_layout.addWidget(model_card)

        # Scene image generation has its own compact, chat-local settings.
        # Keep these independent from Image Studio's advanced workflow controls.
        scene_card, scene_layout = section_panel('Scene image settings', QFormLayout)
        scene_layout.setSpacing(9)
        self.chat_image_checkpoint = NoWheelComboBox()
        self.chat_image_checkpoint.setToolTip('ComfyUI checkpoint for Generate scene image.')
        self.chat_image_width = spin(1024, 256, 2048, 64)
        self.chat_image_height = spin(1024, 256, 2048, 64)
        dimension_row = QWidget()
        dimension_layout = QHBoxLayout(dimension_row)
        dimension_layout.setContentsMargins(0, 0, 0, 0)
        dimension_layout.setSpacing(4)
        dimension_layout.addWidget(self.chat_image_width)
        dimension_layout.addWidget(QLabel('×'))
        dimension_layout.addWidget(self.chat_image_height)
        self.chat_image_steps = spin(28, 1, 150)
        self.chat_image_cfg = dspin(6.0, 1.0, 30.0, .5)
        self.chat_image_sampler = NoWheelComboBox()
        self.chat_image_sampler.addItems(['dpmpp_2m', 'dpmpp_2m_sde', 'euler_ancestral',
                                          'euler', 'dpmpp_sde', 'ddim'])
        self.chat_image_scheduler = NoWheelComboBox()
        self.chat_image_scheduler.addItems(['karras', 'normal', 'sgm_uniform',
                                            'exponential', 'simple'])
        self.chat_image_negative = QLineEdit()
        self.chat_image_negative.setPlaceholderText('Optional negative prompt')
        scene_layout.addRow('Checkpoint', self.chat_image_checkpoint)
        scene_layout.addRow('Size', dimension_row)
        scene_layout.addRow('Steps', self.chat_image_steps)
        scene_layout.addRow('CFG', self.chat_image_cfg)
        scene_layout.addRow('Sampler', self.chat_image_sampler)
        scene_layout.addRow('Scheduler', self.chat_image_scheduler)
        scene_layout.addRow('Negative', self.chat_image_negative)
        refresh_button = button('Refresh checkpoints', self.refresh_comfy_models)
        scene_layout.addRow(refresh_button)
        right_layout.addWidget(scene_card)
        right_layout.addStretch(1)
        right_scroll.setWidget(right)
        splitter.addWidget(right_scroll)
        splitter.setChildrenCollapsible(False)
        splitter.setSizes([255, 760, 334])
        layout.addWidget(splitter)
        self.register_page('chats', root)
        self.refresh_personas()
        self.update_chat_action_states()

    def _chat_image_args(self):
        """Snapshot scene image settings from chat, not the Image Studio widgets.

        Advanced options (e.g. LoRAs, batch and CLIP skip) continue to come
        from Image Studio; the controls shown alongside chat take precedence.
        """
        args = self._image_args()
        args.update(model=self.chat_image_checkpoint.currentText().strip(),
                    width=self.chat_image_width.value(),
                    height=self.chat_image_height.value(),
                    steps=self.chat_image_steps.value(),
                    cfg=self.chat_image_cfg.value(),
                    sampler=self.chat_image_sampler.currentText(),
                    scheduler=self.chat_image_scheduler.currentText(),
                    negative_prompt=self.chat_image_negative.text().strip())
        return args

    def _sync_chat_image_checkpoints(self, checkpoints):
        """Refresh available models without losing a saved choice when possible."""
        combo = self.chat_image_checkpoint
        wanted = combo.currentText() or str(self.settings.value('chat_image_checkpoint', '') or '')
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(checkpoints)
        if wanted and wanted in checkpoints:
            combo.setCurrentText(wanted)
        combo.blockSignals(False)

    def _save_chat_image_settings(self):
        """Persist settings immediately so closing the app does not lose edits."""
        s = self.settings
        for key, widget in (
            ('chat_image_checkpoint', self.chat_image_checkpoint),
            ('chat_image_sampler', self.chat_image_sampler),
            ('chat_image_scheduler', self.chat_image_scheduler),
        ):
            s.setValue(key, widget.currentText())
        for key, widget in (
            ('chat_image_width', self.chat_image_width),
            ('chat_image_height', self.chat_image_height),
            ('chat_image_steps', self.chat_image_steps),
            ('chat_image_cfg', self.chat_image_cfg),
        ):
            s.setValue(key, widget.value())
        s.setValue('chat_image_negative', self.chat_image_negative.text())

    def _load_chat_image_settings(self):
        s = self.settings
        for key, widget in (
            ('chat_image_width', self.chat_image_width),
            ('chat_image_height', self.chat_image_height),
            ('chat_image_steps', self.chat_image_steps),
            ('chat_image_cfg', self.chat_image_cfg),
        ):
            value = s.value(key, None)
            if value is not None:
                try:
                    widget.setValue(float(value))
                except (TypeError, ValueError):
                    pass
        for key, widget in (
            ('chat_image_sampler', self.chat_image_sampler),
            ('chat_image_scheduler', self.chat_image_scheduler),
        ):
            choice = s.value(key, None)
            if choice and widget.findText(str(choice)) >= 0:
                widget.setCurrentText(str(choice))
        self.chat_image_negative.setText(str(s.value('chat_image_negative', '') or ''))
        # The model choice is restored when a ComfyUI model list arrives.
        self.chat_image_checkpoint.setToolTip('Refresh checkpoints to choose an installed ComfyUI model.')

    def _connect_chat_image_settings(self):
        for control in (self.chat_image_checkpoint, self.chat_image_sampler,
                        self.chat_image_scheduler):
            control.currentIndexChanged.connect(self._save_chat_image_settings)
        for control in (self.chat_image_width, self.chat_image_height,
                        self.chat_image_steps, self.chat_image_cfg):
            control.valueChanged.connect(self._save_chat_image_settings)
        self.chat_image_negative.editingFinished.connect(self._save_chat_image_settings)

    def resize_chat_bubbles(self):
        if not hasattr(self, 'chat_history'):
            return
        available = self.chat_history.viewport().width() - 14
        if available < 240:
            return
        for index in range(self.chat_history.count()):
            item = self.chat_history.item(index)
            bubble = self.chat_history.itemWidget(item)
            if isinstance(bubble, (ChatBubbleWidget, ChatImageWidget)):
                item.setSizeHint(bubble.resize_for_width(available))

    def _chat_user_scrolled(self):
        """Pause follow mode immediately when a person scrolls the conversation."""
        self._chat_follow_bottom = False
        self._chat_scroll_timer.stop()
        QTimer.singleShot(0, self._chat_recheck_follow)

    def _chat_recheck_follow(self):
        """Re-enable following only if the reader has manually reached bottom."""
        if not hasattr(self, 'chat_history') or self._chat_scroll_timer.isActive():
            return
        bar = self.chat_history.verticalScrollBar()
        self._chat_follow_bottom = (bar.maximum() - bar.value() <= 36)

    def _chat_scroll_step(self):
        bar = self.chat_history.verticalScrollBar()
        if not self._chat_follow_bottom:
            self._chat_scroll_timer.stop()
            return
        remaining = bar.maximum() - bar.value()
        if remaining <= 0:
            self._chat_scroll_timer.stop()
            return
        # Gradual movement rather than QListWidget.scrollToBottom(), which
        # jumps over enormous greetings and paragraphs in one frame.
        bar.setValue(min(bar.maximum(), bar.value() + max(2, min(90, (remaining + 5) // 6))))

    def _chat_scroll_smoothly(self):
        if self._chat_follow_bottom and not self._chat_scroll_timer.isActive():
            self._chat_scroll_timer.start()

    def _chat_restore_scroll(self, chat_id, serial, old_position, new_conversation,
                             has_multiple_messages, follow, snap_to_bottom=False):
        if self.active_chat != chat_id or serial != self._chat_refresh_serial:
            return
        bar = self.chat_history.verticalScrollBar()
        if new_conversation:
            if has_multiple_messages:
                # Opening an existing conversation starts with its latest reply.
                bar.setValue(bar.maximum())
                self._chat_follow_bottom = True
            else:
                # The first message may be much taller than the viewport.
                # Start at the beginning and let the reader scroll through it.
                bar.setValue(0)
                self._chat_follow_bottom = False
        elif snap_to_bottom:
            # Editing/regeneration should remain at the latest visible text.
            # Do not animate through thousands of previous messages.
            bar.setValue(bar.maximum())
            self._chat_follow_bottom = True
        else:
            bar.setValue(min(old_position, bar.maximum()))
            self._chat_follow_bottom = follow
            if follow:
                self._chat_scroll_smoothly()

    def _chat_finish_refresh(self, chat_id, serial, old_position,
                             new_conversation, has_multiple_messages, following,
                             stick_to_bottom):
        if self.active_chat != chat_id or serial != self._chat_refresh_serial:
            return
        try:
            self.chat_history.doItemsLayout()
            self._chat_restore_scroll(chat_id, serial, old_position,
                                      new_conversation, has_multiple_messages,
                                      following, snap_to_bottom=stick_to_bottom)
        finally:
            self.chat_history.setUpdatesEnabled(True)
            self.chat_history.viewport().update()

    def refresh_chat_list(self):
        previous = self.active_chat
        self.chat_list.blockSignals(True)
        self.chat_list.clear()
        for chat in self.chats.list_chats():
            character = self.characters.get_character(chat['character_id']) or {}
            preview = (chat.get('summary') or '').strip()
            if not preview:
                messages = self.chats.get_messages(chat['id'])
                preview = messages[-1]['content'].replace('\n', ' ')[:120] if messages else ''
            item = QListWidgetItem()
            item.setData(Qt.ItemDataRole.UserRole, chat['id'])
            item.setText('')
            row = ConversationRow(chat, character, preview)
            row.clicked.connect(self.select_chat_by_id)
            row.deleteRequested.connect(self.delete_chat_by_id)
            row.delete_button.setEnabled(self.current_chat_worker is None)
            item.setSizeHint(QSize(250, 88))
            self.chat_list.addItem(item)
            self.chat_list.setItemWidget(item, row)
            if chat['id'] == previous:
                self.chat_list.setCurrentItem(item)
        if self.chat_list.currentRow() < 0 and self.chat_list.count():
            self.chat_list.setCurrentRow(0)
        self.chat_list.blockSignals(False)
        if self.chat_list.currentItem() is not None:
            selected_id = self.chat_list.currentItem().data(Qt.ItemDataRole.UserRole)
            if selected_id != self.active_chat:
                self.select_chat()
            else:
                # Sidebar previews change after each response. Do not rebuild
                # the *same* chat a second time (that resets its scroll bar).
                self.style_chat_selection()
                self.update_chat_sidebar()
        else:
            self.active_chat = None
            self.refresh_chat_messages()
        self.update_chat_action_states()

    def select_chat_by_id(self, chat_id):
        for index in range(self.chat_list.count()):
            item = self.chat_list.item(index)
            if item.data(Qt.ItemDataRole.UserRole) == chat_id:
                self.chat_list.setCurrentItem(item)
                return

    def delete_selected_chat(self):
        item = self.chat_list.currentItem()
        if item is not None:
            self.delete_chat_by_id(item.data(Qt.ItemDataRole.UserRole))

    def delete_chat_by_id(self, chat_id):
        if self.current_chat_worker is not None:
            self.status('Stop the current AI response before deleting a conversation.')
            return
        chat = self.chats.get_chat(chat_id)
        if chat is None:
            self.refresh_chat_list()
            return
        confirmation = QMessageBox.question(
            self, 'Delete conversation?',
            f'Delete "{chat["title"]}" and all {chat["message_count"]} of its messages? '
            'This cannot be undone.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirmation != QMessageBox.StandardButton.Yes:
            return
        if self.chats.delete_chat(chat_id):
            if self.active_chat == chat_id:
                self.active_chat = None
            self.refresh_chat_list()
            self.refresh_characters(rebuild_tags=False)
            self.status('Conversation deleted.')

    def style_chat_selection(self):
        for index in range(self.chat_list.count()):
            item = self.chat_list.item(index)
            widget = self.chat_list.itemWidget(item)
            if isinstance(widget, ConversationRow):
                widget.set_active(item is self.chat_list.currentItem())

    def current_persona(self):
        if not hasattr(self, 'chat_persona'):
            return None
        return self.personas.get_persona(self.chat_persona.currentData())

    def current_user_name(self):
        persona = self.current_persona() or {}
        return safe_text(persona.get('user_name'), 'User') or 'User'

    def refresh_personas(self, select_id=None):
        current_id = select_id or (self.chat_persona.currentData() if hasattr(self, 'chat_persona') else None)
        personas = self.personas.list_personas()
        if hasattr(self, 'chat_persona'):
            self.chat_persona.blockSignals(True)
            self.chat_persona.clear()
            for persona in personas:
                self.chat_persona.addItem(persona.get('name') or 'Unnamed Persona', persona.get('id'))
            idx = self.chat_persona.findData(current_id)
            if idx < 0 and self.chat_persona.count():
                idx = 0
            if idx >= 0:
                self.chat_persona.setCurrentIndex(idx)
            self.chat_persona.blockSignals(False)
        self.persona_changed()

    def persona_changed(self):
        persona = self.current_persona() or {}
        name = safe_text(persona.get('user_name'), 'User') or 'User'
        self.chat_user_label.setText(f'User: {name}')
        desc = safe_text(persona.get('description')) or safe_text(persona.get('prompt')) or 'No persona notes.'
        self.chat_persona_summary.setText(desc)

    def new_persona(self):
        dialog = PersonaEditorDialog(parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            payload = dialog.value()
            if not payload['name']:
                self.error('Persona name is required.')
                return
            persona_id = self.personas.save_persona(payload)
            self.refresh_personas(persona_id)

    def edit_persona(self):
        current = self.current_persona()
        if not current:
            return
        dialog = PersonaEditorDialog(current, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            payload = dialog.value()
            if not payload['name']:
                self.error('Persona name is required.')
                return
            persona_id = self.personas.save_persona(payload)
            self.refresh_personas(persona_id)

    def delete_persona(self):
        current = self.current_persona()
        if not current:
            return
        if QMessageBox.question(self, 'Delete persona?', f'Delete persona "{current.get("name")}"?') == QMessageBox.StandardButton.Yes:
            self.personas.delete_persona(current.get('id'))
            self.refresh_personas()

    def _clear_chat_tags(self):
        while self.chat_character_tag_layout.count():
            item = self.chat_character_tag_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def update_chat_sidebar(self):
        self._clear_chat_tags()
        if self.active_chat is None:
            self.chat_character_name.setText('No character selected')
            self._chat_character_pixmap = QPixmap()
            self.chat_character_image.setPixmap(QPixmap())
            self.chat_character_image.setText('No portrait available')
            self._refresh_chat_character_image()
            self.chat_character_tag_panel.setMinimumHeight(30)
            return
        chat = self.chats.get_chat(self.active_chat)
        character = self.characters.get_character(chat['character_id']) if chat else None
        if not character:
            self.chat_character_name.setText('Character removed')
            self._chat_character_pixmap = QPixmap()
            self.chat_character_image.setPixmap(QPixmap())
            self.chat_character_image.setText("This chat\'s original character was deleted.")
            self._refresh_chat_character_image()
            self.chat_character_tag_panel.setMinimumHeight(30)
            return
        self.chat_character_name.setText(character.get('name') or 'Unknown character')
        image_file = resolve_character_image(character)
        picture = QPixmap(str(image_file)) if image_file else QPixmap()
        self._chat_character_pixmap = picture
        if picture.isNull():
            self.chat_character_image.setText('Add a portrait in Character editor')
            self._refresh_chat_character_image()
        else:
            self.chat_character_image.setText('')
            self._refresh_chat_character_image()
        tags = [normalize_audience(character.get('audience'))] + normalize_tags(character.get('tags'))
        shown = tags[:9]
        for tag in shown:
            label = QLabel(((TAG_ICONS.get(tag) or '') + ' ' + tag).strip())
            label.setObjectName('ChatTag')
            self.chat_character_tag_layout.addWidget(label)
        if len(tags) > len(shown):
            extra = QLabel(f'+{len(tags) - len(shown)}')
            extra.setObjectName('ChatTag')
            self.chat_character_tag_layout.addWidget(extra)
        height = self.chat_character_tag_layout.heightForWidth(max(220, self.chat_character_tag_panel.width() - 8))
        self.chat_character_tag_panel.setMinimumHeight(max(34, height + 10))
        self.chat_character_tag_layout.invalidate()
        self.persona_changed()

    def select_chat(self):
        entry = self.chat_list.currentItem()
        if not entry:
            self.active_chat = None
            self.update_chat_sidebar()
            self.update_chat_action_states()
            return
        self.active_chat = entry.data(Qt.ItemDataRole.UserRole)
        self.style_chat_selection()
        self.refresh_chat_messages()

    def refresh_chat_messages(self, visible_messages=None, stick_to_bottom=False):
        self._chat_scroll_timer.stop()
        bar = self.chat_history.verticalScrollBar()
        old_position = bar.value()
        current_chat = self.active_chat
        new_conversation = self._chat_rendered_id != current_chat
        following = (self._chat_follow_bottom or
                     (not new_conversation and bar.maximum() - old_position <= 36))
        self._chat_refresh_serial += 1
        serial = self._chat_refresh_serial
        self._chat_rendered_id = current_chat
        # Hide repaints BEFORE clearing the list; otherwise a large chat flashes
        # at scroll position 0 before its widgets have been laid out again.
        self.chat_history.setUpdatesEnabled(False)
        self.chat_history.clear()
        if current_chat is None:
            self.chat_heading.setText('Choose a chat')
            self.chat_subheading.setText('Select a conversation or start a new one.')
            self.update_chat_sidebar()
            self.update_chat_action_states()
            self.chat_history.setUpdatesEnabled(True)
            return
        chat = self.chats.get_chat(current_chat)
        if not chat:
            self.update_chat_sidebar()
            self.update_chat_action_states()
            self.chat_history.setUpdatesEnabled(True)
            return
        character = self.characters.get_character(chat['character_id']) or {}
        # Full scenario stays accessible as a tooltip, not a multi-page header.
        subtitle_bits = [character.get('name') or 'Unknown character',
                         chat.get('model') or 'No model selected']
        self.chat_heading.setText(chat['title'])
        self.chat_subheading.setText('  •  '.join(subtitle_bits))
        self.chat_subheading.setToolTip(safe_text(character.get('scenario')))
        messages = (self.chats.get_messages(current_chat) if visible_messages is None
                    else visible_messages)
        events = [(msg.get('created_at', ''), 0, msg['id'], 'message', msg)
                  for msg in messages if msg.get('id') is not None]
        if visible_messages is None:
            events.extend((entry.get('created_at', ''), 1, entry['id'], 'image', entry)
                          for entry in self.chats.get_chat_images(current_chat))
        for _, _, _, kind, data in sorted(events):
            if kind == 'message':
                self.add_chat_row(data['role'], data['content'], data['id'], data.get('created_at'))
            else:
                self.add_chat_image_row(data)
        self.resize_chat_bubbles()
        # Keep repaints blocked through Qt's deferred item geometry pass.
        # A regeneration or edit pins the view immediately to its bottom.
        QTimer.singleShot(0, lambda: self._chat_finish_refresh(
            current_chat, serial, old_position, new_conversation,
            len(events) > 1, following, stick_to_bottom))
        self.update_chat_sidebar()
        self.update_chat_action_states()

    def add_chat_row(self, role, content, msg_id=None, created_at='', pending=False):
        item = QListWidgetItem()
        item.setData(Qt.ItemDataRole.UserRole, msg_id)
        item.setText('')
        chat = self.chats.get_chat(self.active_chat) if self.active_chat is not None else None
        character = self.characters.get_character(chat['character_id']) if chat else None
        sender_name = safe_text((character or {}).get('name')) or 'Assistant'
        widget = ChatBubbleWidget(
            role, content, created_at, sender_name=sender_name,
            message_id=msg_id, action_callback=self.message_action, pending=pending,
        )
        item.setSizeHint(widget.resize_for_width(max(240, self.chat_history.viewport().width() - 14)))
        self.chat_history.addItem(item)
        self.chat_history.setItemWidget(item, widget)
        return item, widget

    def add_chat_image_row(self, entry):
        """Display a gallery image in chat with a click-to-enlarge thumbnail."""
        item = QListWidgetItem()
        item.setData(Qt.ItemDataRole.UserRole, None)
        widget = ChatImageWidget(DATA_DIR / 'images' / entry['filename'], entry['prompt'],
                                 on_open=self.open_lightbox)
        item.setSizeHint(widget.resize_for_width(max(240, self.chat_history.viewport().width() - 14)))
        self.chat_history.addItem(item)
        self.chat_history.setItemWidget(item, widget)

    def message_action(self, action, message_id):
        """Dispatch controls attached to their exact message, never list selection."""
        if action == 'stop':
            self.stop_chat()
        elif action == 'regenerate':
            self.regenerate_chat(message_id)
        elif action == 'continue':
            self.continue_chat(message_id)
        elif action == 'edit':
            self.edit_chat_message(message_id)
        elif action == 'delete':
            self.delete_chat_message(message_id)

    def new_chat(self):
        if self.active_character is None:
            c = self.characters.list_characters()
            if c: self.active_character = c[0]['id']
        if self.active_character is None:
            self.error('Create a character first.')
            return
        c = self.characters.get_character(self.active_character)
        model = self.current_model() or 'qwen3:4b'
        greeting = apply_tokens(c.get('first_message') or default_first_message(c),
                                self.current_user_name(), c['name'])
        self.active_chat = self.chats.create_chat(
            self.active_character, f'{c["name"]} chat', model, first_message=greeting
        )
        self.refresh_chat_list()
        self.refresh_chat_messages()
        self.navigate('chats')

    def _run_chat(self, context, persist_user=False, replace_message_id=None,
                  continue_after_message_id=None):
        if self.current_chat_worker is not None:
            self.error('A chat generation is already running. Stop it first.')
            return
        if self.active_chat is None:
            self.error('Create a chat first.')
            return
        chat_id = self.active_chat
        chat = self.chats.get_chat(chat_id)
        character = self.characters.get_character(chat['character_id']) if chat else None
        if not character:
            self.error('Chat character is missing.')
            return
        persona = self.current_persona() or {}
        user_name = safe_text(persona.get('user_name'), 'User') or 'User'
        char_name = safe_text(character.get('name'), 'Assistant') or 'Assistant'
        context = apply_tokens(context, user_name, char_name)

        if persist_user:
            self.chats.add_message(chat_id, 'user', context)
        all_messages = self.chats.get_messages(chat_id)
        messages = all_messages
        if replace_message_id is not None:
            index = next((i for i, msg in enumerate(all_messages)
                          if msg['id'] == replace_message_id and msg['role'] == 'assistant'), None)
            if index is None:
                self.status('That response no longer exists.')
                return
            messages = all_messages[:index]
        elif continue_after_message_id is not None:
            index = next((i for i, msg in enumerate(all_messages)
                          if msg['id'] == continue_after_message_id and msg['role'] == 'assistant'), None)
            if index is None:
                self.status('That response no longer exists.')
                return
            messages = all_messages[:index + 1]
        if context and not persist_user:
            messages = messages + [{'role': 'user', 'content': context}]

        self._chat_follow_bottom = True
        # Regeneration draws only the messages before the replaced reply, and
        # preserves the database copy until replacement succeeds. Rebuild the
        # view once while repaints are blocked to avoid flashing at the top.
        preview = (messages if replace_message_id is not None or
                   continue_after_message_id is not None else None)
        self.refresh_chat_messages(visible_messages=preview, stick_to_bottom=True)
        # Continue's internal instruction belongs only in Ollama's context,
        # never as a fake user message in the visible conversation.
        pending_item, pending_widget = self.add_chat_row('assistant', '', pending=True)
        pending_text = ['']

        def on_token(token):
            if self.active_chat != chat_id:
                return
            pending_text[0] += token
            rendered = apply_tokens(pending_text[0], user_name, char_name)
            pending_widget.set_content(rendered)
            pending_item.setSizeHint(pending_widget.resize_for_width(
                max(240, self.chat_history.viewport().width() - 14)))
            self._chat_scroll_smoothly()

        model = self.current_model() or chat['model']
        base = self.ollama_url()
        options = self.llm_options()
        system = build_character_prompt(character, user_name=user_name,
                                        persona=persona, recent_messages=messages)
        self.status(f'Ollama: generating with {model}')

        def task(cancel, token_cb, status_cb):
            response = ollama_chat(base, model, system, messages, options,
                                   on_token=token_cb, cancel=cancel,
                                   preserve_partial_on_cancel=True)
            return response, cancel.is_set()

        def finish(result):
            self.current_chat_worker = None
            response, stopped = result
            response = apply_tokens(response, user_name, char_name)
            # Stopping a stream keeps its received text in the chat database.
            # Empty or failed regenerations never delete the previous response.
            saved = save_assistant_reply(
                self.chats, chat_id, response,
                replace_message_id=replace_message_id,
                continue_after_message_id=continue_after_message_id,
            )
            if self.active_chat == chat_id:
                self.refresh_chat_messages(stick_to_bottom=True)
            self.refresh_chat_list()
            self.update_chat_action_states()
            if stopped:
                self.status('Response stopped — partial reply saved.' if saved else
                            'Response stopped before any text was generated.')
            else:
                self.status('Response complete' if saved else 'No response generated.')

        def fail(message):
            self.current_chat_worker = None
            if self.active_chat == chat_id:
                self.refresh_chat_messages(stick_to_bottom=True)
            self.update_chat_action_states()
            self.error(message)

        job = self.run_job(task, finish, on_token, on_error=fail)
        job.signals.cancelled.connect(lambda msg: self._chat_cancelled(msg))
        self.current_chat_worker = job
        self.update_chat_action_states()

    def _chat_cancelled(self, msg):
        self.current_chat_worker = None
        self.refresh_chat_messages(stick_to_bottom=True)
        self.update_chat_action_states()
        self.status(msg)

    def update_chat_action_states(self):
        thinking = self.current_chat_worker is not None
        has_chat = self.active_chat is not None
        input_ready = hasattr(self, 'chat_input') and bool(self.chat_input.toPlainText().strip())
        messages = self.chats.get_messages(self.active_chat) if has_chat else []
        has_assistant = any(message['role'] == 'assistant' for message in messages)
        can_regenerate = (has_assistant and any(m['role'] == 'user' for m in messages)
                          and bool(messages) and messages[-1]['role'] == 'assistant')
        has_messages = bool(messages)
        image_thinking = getattr(self, 'current_chat_image_worker', None) is not None
        if hasattr(self, 'chat_image_button'):
            self.chat_image_button.setEnabled(has_chat and has_messages and not thinking and not image_thinking)
        if hasattr(self, 'send_button'):
            self.send_button.setEnabled(has_chat and input_ready and not thinking)
            self.regenerate_button.setEnabled(has_chat and can_regenerate and not thinking)
            self.continue_button.setEnabled(has_chat and has_messages and not thinking)
            self.stop_button.setEnabled(thinking or image_thinking)
        if hasattr(self, 'delete_selected_chat_button'):
            self.delete_selected_chat_button.setEnabled(has_chat and not thinking)
        if hasattr(self, 'chat_list'):
            for index in range(self.chat_list.count()):
                row = self.chat_list.itemWidget(self.chat_list.item(index))
                if isinstance(row, ConversationRow):
                    row.delete_button.setEnabled(not thinking)

        # Each message owns its own controls; actions reference that message ID.
        if hasattr(self, 'chat_history'):
            msg_index = {msg['id']: idx for idx, msg in enumerate(messages)}
            for row in range(self.chat_history.count()):
                item = self.chat_history.item(row)
                widget = self.chat_history.itemWidget(item)
                if not isinstance(widget, ChatBubbleWidget):
                    continue
                if widget.is_pending:
                    if 'stop' in widget.action_buttons:
                        widget.action_buttons['stop'].setEnabled(thinking)
                    continue
                current_id = widget.message_id
                idx = msg_index.get(current_id)
                is_saved = idx is not None
                can_repeat = (is_saved and widget.role == 'assistant'
                              and any(m['role'] == 'user' for m in messages[:idx]))
                permissions = {
                    'regenerate': can_repeat and not thinking,
                    'continue': is_saved and widget.role == 'assistant' and not thinking,
                    'edit': is_saved and not thinking,
                    'delete': is_saved and not thinking,
                }
                for action, action_button in widget.action_buttons.items():
                    action_button.setEnabled(bool(permissions.get(action, False)))

    def send_chat(self):
        text = self.chat_input.toPlainText().strip()
        if not text:
            return
        if self.current_chat_worker is not None:
            self.status('Stop the current response before sending again.')
            return
        self.chat_input.clear()
        self.update_chat_action_states()
        self._run_chat(text, persist_user=True)

    def _target_message(self, message_id):
        if self.active_chat is None or message_id is None:
            return None, []
        messages = self.chats.get_messages(self.active_chat)
        return next((m for m in messages if m['id'] == message_id), None), messages

    def regenerate_chat(self, message_id=None):
        if self.current_chat_worker is not None or self.active_chat is None:
            return
        messages = self.chats.get_messages(self.active_chat)
        if message_id is None:
            # Global Regenerate acts only on the most recent assistant reply.
            if not messages or messages[-1]['role'] != 'assistant':
                self.status('The most recent message must be an AI reply to regenerate.')
                return
            message_id = messages[-1]['id']
        target, messages = self._target_message(message_id)
        if not target or target['role'] != 'assistant':
            return
        index = next(i for i, m in enumerate(messages) if m['id'] == message_id)
        if not any(m['role'] == 'user' for m in messages[:index]):
            self.status('The opening greeting cannot be regenerated before you send a message.')
            return
        if index != len(messages) - 1:
            confirmation = QMessageBox.question(
                self, 'Regenerate older response?',
                'Regenerating this message will replace it and remove all later '
                'messages after the new response succeeds. Continue?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if confirmation != QMessageBox.StandardButton.Yes:
                return
        self._run_chat('', replace_message_id=message_id)

    def continue_chat(self, message_id=None):
        if self.current_chat_worker is not None or self.active_chat is None:
            return
        if message_id is not None:
            target, messages = self._target_message(message_id)
            if not target or target['role'] != 'assistant':
                return
            index = next(i for i, m in enumerate(messages) if m['id'] == message_id)
            if index != len(messages) - 1:
                confirmation = QMessageBox.question(
                    self, 'Continue older response?',
                    'Continuing from this message will remove later messages '
                    'after the new response succeeds. Continue?',
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                if confirmation != QMessageBox.StandardButton.Yes:
                    return
            self._run_chat('Continue from where you left off, without repeating the previous text.',
                           continue_after_message_id=message_id)
        else:
            self._run_chat('Continue from where you left off, without repeating the previous text.')

    def generate_chat_scene_image(self):
        """Ask the current roleplay LLM for a scene prompt, then call ComfyUI.

        Prompt-writing instructions are never inserted into chat history.
        Images are gallery files associated with the originating conversation.
        """
        if self.current_chat_worker is not None or getattr(self, 'current_chat_image_worker', None):
            self.status('Wait for the current chat or scene-image job to finish.')
            return
        if self.active_chat is None:
            self.error('Open a conversation first.')
            return
        chat_id = self.active_chat
        chat = self.chats.get_chat(chat_id)
        character = self.characters.get_character(chat['character_id']) if chat else None
        if not character:
            self.error('The selected chat no longer has a character.')
            return
        try:
            scene_messages = scene_prompt_messages(character, self.chats.get_messages(chat_id))
            image_args = self._chat_image_args()
            image_args['mode'] = 'txt2img'
            image_args['input_filename'] = None
            if not image_args['model']:
                raise ValueError('Select a ComfyUI checkpoint in Create image first.')
            # Early validation before starting the slower Ollama request.
            build_workflow(**{**image_args, 'prompt': 'scene preview'})
        except (ValueError, OSError) as exc:
            self.error(exc)
            return

        model = self.current_model() or chat.get('model') or 'qwen3:4b'
        llm_url, comfy_url = self.ollama_url(), self.comfy_url()
        # Do not alter the manual image prompt, its saved draft, or chat text.
        self.status('Writing scene-image prompt with Ollama…')

        def task(cancel, token_cb, status_cb):
            status_cb('Ollama is describing the current scene…')
            text = ollama_chat(llm_url, model, SCENE_SYSTEM, scene_messages,
                               {**llm_options, 'temperature': 0.45,
                                'num_predict': 320}, cancel=cancel)
            if cancel.is_set():
                from imgenius.images.comfy import Cancelled
                raise Cancelled('Scene-image generation stopped.')
            prompt = clean_scene_prompt(text)
            status_cb('ComfyUI is generating the scene image…')
            graph = build_workflow(**{**image_args, 'prompt': prompt})
            prompt_id, images = generate_image(comfy_url, graph,
                                               on_status=status_cb, cancel=cancel)
            files = save_outputs(prompt_id, images)
            return prompt, files

        # Snapshot all Qt widget values on the UI thread, never in the worker.
        llm_options = dict(self.llm_options())

        def done(result):
            self.current_chat_image_worker = None
            prompt, paths = result
            if not self.chats.get_chat(chat_id):
                self.status('Images saved to the gallery; the original conversation was deleted.')
                self.refresh_gallery()
                return
            for path in paths:
                self.chats.add_chat_image(chat_id, Path(path).name, prompt)
            if self.active_chat == chat_id:
                self.refresh_chat_messages()
            if paths:
                self.image_paths = list(paths)
                self._show_preview(paths[0])
                self.refresh_image_browser(paths[0])
                self.refresh_gallery()
            self.update_chat_action_states()
            self.status(f'Scene image saved ({len(paths)} file(s)); click it in chat to enlarge.')

        def fail(message):
            self.current_chat_image_worker = None
            self.update_chat_action_states()
            self.error(message)

        job = self.run_job(task, done, on_status=self.status, on_error=fail)
        job.signals.cancelled.connect(self._chat_scene_cancelled)
        self.current_chat_image_worker = job
        self.update_chat_action_states()

    def _chat_scene_cancelled(self, message):
        self.current_chat_image_worker = None
        self.update_chat_action_states()
        self.status(message)

    def stop_chat(self):
        job = self.current_chat_worker or getattr(self, 'current_chat_image_worker', None)
        if not job:
            self.status('Nothing to stop right now.')
            self.update_chat_action_states()
            return
        job.cancel_event.set()
        self.status('Stopping after the next response chunk…')
        self.update_chat_action_states()

    def _selected_message(self):
        item = self.chat_history.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def edit_chat_message(self, message_id=None):
        if self.current_chat_worker is not None:
            return
        if message_id is None:
            message_id = self._selected_message()
        target, _ = self._target_message(message_id)
        if not target:
            return
        dialog = MessageEditDialog(target['content'], self)
        if dialog.exec() == QDialog.DialogCode.Accepted and dialog.text().strip():
            text = dialog.text()
            character = self.characters.get_character(
                self.chats.get_chat(self.active_chat)['character_id']
            ) if self.active_chat else None
            char_name = safe_text((character or {}).get('name'), 'Assistant')
            self.chats.update_message(
                self.active_chat, message_id,
                apply_tokens(text.strip(), self.current_user_name(), char_name),
            )
            self.refresh_chat_messages(stick_to_bottom=True)
            self.refresh_chat_list()
            self.update_chat_action_states()

    def delete_chat_message(self, message_id=None):
        if self.current_chat_worker is not None:
            return
        if message_id is None:
            message_id = self._selected_message()
        target, _ = self._target_message(message_id)
        if not target:
            return
        if QMessageBox.question(
            self, 'Delete message?', 'Remove the selected message?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        ) == QMessageBox.StandardButton.Yes:
            self.chats.delete_message(self.active_chat, message_id)
            self.refresh_chat_messages()
            self.refresh_chat_list()
            self.update_chat_action_states()

