"""Editor page: layout and handlers only."""
from __future__ import annotations

from PIL import Image
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QCheckBox
from PySide6.QtWidgets import QComboBox
from PySide6.QtWidgets import QFileDialog
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QInputDialog
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QPlainTextEdit
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.characters.card_io import export_character_card_png
from imgenius.characters.card_io import load_character_card
from imgenius.characters.library import TAG_ICONS
from imgenius.characters.library import editor_tag_options
from imgenius.characters.library import normalize_audience
from imgenius.characters.library import normalize_tags
from imgenius.characters.library import visible_editor_tags
from imgenius.characters.lorebook import import_lorebook_file
from imgenius.characters.lorebook import normalize_lorebook
from imgenius.domain import CARD_DIR
from imgenius.domain import DEFAULT_FIRST_MESSAGE
from imgenius.domain import DEFAULT_SYSTEM_PROMPT
from imgenius.domain import GENDER_CHOICES
from imgenius.domain import default_first_message
from imgenius.domain import ensure_default_character_images
from imgenius.domain import export_character_card
from imgenius.domain import safe_text
from imgenius.images.avatar_generation import generate_character_portrait
from imgenius.ui.widgets.characters import FIELD_LABELS
from imgenius.ui.widgets.characters import FlowLayout
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import make_card
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import section_panel
from imgenius.ui.widgets.controls import textedit
from imgenius.ui.widgets.visuals import ClickableImageLabel
from imgenius.ui.widgets.visuals import LightboxDialog
from pathlib import Path


class CharacterEditorPageMixin:
    def _make_character_editor(self):
        outer, body = scroll_content()
        body.addWidget(section_label('Create a character with a flexible system prompt and an optional keyword-triggered lorebook.'))
        discover = make_card('Discovery settings', body)
        meta = QFormLayout()
        self.editor_audience = NoWheelComboBox()
        self.editor_audience.addItems(['Safe', 'Mature'])
        self.editor_featured = QCheckBox('Show in Featured filter')
        meta.addRow('Content label', self.editor_audience)
        meta.addRow('Featured', self.editor_featured)
        discover.addLayout(meta)
        self.editor_tag_tip = section_label('Select tags below. Mature reveals additional adult-theme tags.')
        discover.addWidget(self.editor_tag_tip)
        self.editor_tag_palette = QWidget()
        self.editor_tag_palette.setObjectName('TagPanel')
        self.editor_tag_layout = FlowLayout(self.editor_tag_palette, spacing=5)
        self.editor_tag_buttons = {}
        self.editor_selected_tags = []
        self.editor_tags_expanded = str(self.settings.value('editor_tags_expanded', 'false')).lower() in ('1','true','yes')
        # Include the complete catalog, not just the previous 28 hard-coded
        # chips. Eligibility/visibility is decided by the Safe/Mature dropdown.
        for label in editor_tag_options('Mature'):
            self._ensure_editor_tag_button(label)
        discover.addWidget(self.editor_tag_palette)
        tag_tools = QHBoxLayout()
        self.editor_tag_summary = section_label('No tags selected')
        self.editor_tag_summary.setWordWrap(True)
        tag_tools.addWidget(self.editor_tag_summary, 1)
        self.editor_tag_expand = button('Show all tags', self.toggle_editor_tags)
        self.editor_tag_expand.setObjectName('ChipClear')
        tag_tools.addWidget(self.editor_tag_expand)
        tag_tools.addWidget(button('Add custom tag…', self.add_editor_custom_tag))
        discover.addLayout(tag_tools)
        # Update the visible options immediately when Content label changes.
        self.editor_audience.currentTextChanged.connect(self.update_editor_tag_buttons)
        self.update_editor_tag_buttons()

        art = make_card('Character portrait', body)
        art_row = QHBoxLayout()
        self.character_editor_image = ClickableImageLabel('Upload portrait or save to create an avatar.')
        self.character_editor_image.setObjectName('CharacterAvatar')
        self.character_editor_image.setMinimumSize(150, 150)
        self.character_editor_image.setMaximumSize(280, 360)
        self.character_editor_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.character_editor_image.setWordWrap(True)
        self.character_editor_image.clicked.connect(lambda: self.open_lightbox(getattr(self, '_editor_character_pixmap', QPixmap())))
        art_row.addWidget(self.character_editor_image, 0, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
        art_actions = QVBoxLayout()
        art_actions.addWidget(button('Import character card (PNG / JSON)…', self.import_character_card))
        art_actions.addWidget(button('Browse Chub', self.browse_telegai_in_characters))
        art_actions.addWidget(button('Attach portrait (PNG / JPEG / WebP)', self.attach_character_card))
        self.generate_avatar_button = button('Use generated avatar (on save)')
        self.generate_avatar_button.setObjectName('UseGeneratedAvatar')
        self.generate_avatar_button.setCheckable(True)
        self.generate_avatar_button.setToolTip(
            'On Save character, ask the current Ollama model to write an image prompt, '
            'generate a portrait in ComfyUI, then open a new chat.'
        )
        self.generate_avatar_button.toggled.connect(self.toggle_generated_avatar)
        art_actions.addWidget(self.generate_avatar_button)
        art_actions.addWidget(button('Export character card PNG', self.export_card))
        art_actions.addStretch()
        art_row.addLayout(art_actions)
        art_row.addStretch()
        art.addLayout(art_row)
        self.card_path_label = section_label('No artwork selected')
        art.addWidget(self.card_path_label)
        self.avatar_status_label = section_label(
            'To generate a portrait: select Use generated avatar, then Save character.'
        )
        art.addWidget(self.avatar_status_label)
        self.cancel_avatar_button = button('Cancel avatar generation', self.cancel_avatar_generation)
        self.cancel_avatar_button.setVisible(False)
        art.addWidget(self.cancel_avatar_button)

        form_layout = make_card('Character profile', body)
        self.character_fields = {}
        grid = QFormLayout()
        for key, title in FIELD_LABELS:
            if key == 'gender':
                w = NoWheelComboBox()
                w.addItems(GENDER_CHOICES)
            elif key in ('name', 'age'):
                w = QLineEdit()
            else:
                w = textedit(height=86)
            self.character_fields[key] = w
            grid.addRow(title, w)
        form_layout.addLayout(grid)

        first_card = make_card('First Message', body)
        first_card.addWidget(section_label(
            'Shown as the character’s opening message in every new chat. Supports {{char}} and {{user}}.'
        ))
        self.character_first_message = textedit(height=145)
        self.character_first_message.setPlainText(DEFAULT_FIRST_MESSAGE)
        first_card.addWidget(self.character_first_message)

        prompt_card = make_card('System Prompt', body)
        prompt_card.addWidget(section_label('Editable instructions used for every response. Supports {{char}} and {{user}}.'))
        self.character_system_prompt = textedit(height=135)
        self.character_system_prompt.setPlainText(DEFAULT_SYSTEM_PROMPT)
        prompt_card.addWidget(self.character_system_prompt)

        lorebook_card = make_card('Lorebook', body)
        lorebook_card.addWidget(section_label('A trigger word activates its matching lore during chat. Always-active entries require no trigger.'))
        self.lorebook_holder = QVBoxLayout()
        self.lorebook_holder.setSpacing(10)
        lorebook_card.addLayout(self.lorebook_holder)
        self.lorebook_rows = []
        lore_buttons = QHBoxLayout()
        lore_buttons.addWidget(button('+ Add entry', self.add_lorebook_entry))
        lore_buttons.addWidget(button('Import lorebook (.json)…', self.import_character_lorebook))
        lore_buttons.addStretch(1)
        lorebook_card.addLayout(lore_buttons)
        self.add_lorebook_entry()

        row = QHBoxLayout()
        self.save_character_button = button('Save character', self.save_character, True)
        row.addWidget(self.save_character_button)
        row.addWidget(button('New blank character', self.new_character))
        row.addStretch()
        body.addLayout(row)
        self.edit_card_path = None
        self.register_page('editor', outer)

    def _ensure_editor_tag_button(self, label):
        key = label.casefold()
        if key in self.editor_tag_buttons:
            return self.editor_tag_buttons[key]
        chip = QPushButton(((TAG_ICONS.get(label) or '') + ' ' + label).strip())
        chip.setObjectName('TagChip')
        chip.setCheckable(True)
        chip.toggled.connect(lambda checked, tag=label: self.toggle_editor_tag(tag, checked))
        self.editor_tag_buttons[key] = chip
        self.editor_tag_layout.addWidget(chip)
        return chip

    def toggle_editor_tag(self, label, enabled):
        current = [tag for tag in self.editor_selected_tags if tag.casefold() != label.casefold()]
        if enabled:
            current.append(label)
        self.editor_selected_tags = normalize_tags(current)
        self.update_editor_tag_buttons()

    def update_editor_tag_buttons(self, *_):
        audience = self.editor_audience.currentText()
        visible, total = visible_editor_tags(
            audience, self.editor_selected_tags, expanded=self.editor_tags_expanded,
        )
        allowed = editor_tag_options(audience, self.editor_selected_tags)
        # Imported and newly created custom tags get their own clickable chips,
        # so they can be removed or re-selected from the editor itself.
        for label in allowed:
            self._ensure_editor_tag_button(label)
        tags = {tag.casefold() for tag in self.editor_selected_tags}
        shown = {tag.casefold() for tag in visible}
        for key, chip in self.editor_tag_buttons.items():
            chip.blockSignals(True)
            chip.setChecked(key in tags)
            chip.blockSignals(False)
            chip.setVisible(key in shown)
        hidden = max(0, total - len(visible))
        self.editor_tag_expand.setVisible(self.editor_tags_expanded or hidden > 0)
        self.editor_tag_expand.setText('Show fewer tags' if self.editor_tags_expanded else
                                       f'Show all tags (+{hidden})')
        self.editor_tag_tip.setText(
            'Mature tags are available below alongside the regular character tags.'
            if normalize_audience(audience) == 'Mature' else
            'Select tags below. Switch Content label to Mature for additional adult-theme tags.'
        )
        self.editor_tag_layout.invalidate()
        self.editor_tag_palette.updateGeometry()
        self.editor_tag_summary.setText('Selected: ' + ', '.join(self.editor_selected_tags) if tags else 'No tags selected')

    def toggle_editor_tags(self):
        self.editor_tags_expanded = not self.editor_tags_expanded
        self.settings.setValue('editor_tags_expanded', self.editor_tags_expanded)
        self.update_editor_tag_buttons()

    def add_editor_custom_tag(self):
        value, ok = QInputDialog.getText(self, 'Custom tag', 'Tag name:')
        if ok and value.strip():
            label = value.strip()[:60]
            if label.casefold() not in {tag.casefold() for tag in self.editor_selected_tags}:
                self.editor_selected_tags.append(label)
            self.update_editor_tag_buttons()

    def _load_editor_tags(self, saved_tags):
        self.editor_selected_tags = normalize_tags(saved_tags)
        self.update_editor_tag_buttons()

    def add_lorebook_entry(self, data=None):
        """Each entry has a 1-line trigger and >=3-line body with separate delete actions."""
        data = data or {}
        group, block = section_panel(f'Lore entry {len(self.lorebook_rows) + 1}')
        trigger_row = QHBoxLayout()
        trigger_row.addWidget(QLabel('Trigger keywords'))
        keys = QLineEdit(str(data.get('keys') or ''))
        keys.setPlaceholderText('Keywords, separated by commas')
        trigger_row.addWidget(keys, 1)
        trigger_row.addWidget(button('Delete keywords', keys.clear))
        block.addLayout(trigger_row)
        content_row = QHBoxLayout()
        content_row.addWidget(QLabel('Lore content'))
        content = QPlainTextEdit()
        content.setPlaceholderText('Information the model should know when this entry is activated…')
        content.setMinimumHeight(110)
        content.setPlainText(str(data.get('content') or ''))
        content_row.addWidget(content, 1)
        content_row.addWidget(button('Delete content', content.clear))
        block.addLayout(content_row)
        flags = QHBoxLayout()
        constant = QCheckBox('Always active (no keywords required)')
        constant.setChecked(bool(data.get('constant', False)))
        flags.addWidget(constant)
        flags.addStretch(1)
        flags.addWidget(button('Remove entry', lambda: self.remove_lorebook_entry(group)))
        block.addLayout(flags)
        self.lorebook_holder.addWidget(group)
        self.lorebook_rows.append({'widget': group, 'keys': keys, 'content': content, 'constant': constant})
        return group

    def remove_lorebook_entry(self, widget):
        self.lorebook_rows = [row for row in self.lorebook_rows if row['widget'] is not widget]
        self.lorebook_holder.removeWidget(widget)
        widget.setParent(None)
        widget.deleteLater()

    def set_lorebook_entries(self, entries):
        for row in list(self.lorebook_rows):
            self.remove_lorebook_entry(row['widget'])
        records = normalize_lorebook(entries)
        for record in records:
            self.add_lorebook_entry(record)
        if not records:
            self.add_lorebook_entry()

    def collect_lorebook_entries(self):
        entries = []
        for row in self.lorebook_rows:
            keywords = row['keys'].text().strip()
            content = row['content'].toPlainText().strip()
            constant = row['constant'].isChecked()
            if not keywords and not content and not constant:
                continue
            if not content:
                raise ValueError('A lorebook entry has keywords but no content.')
            if not keywords and not constant:
                raise ValueError('A lorebook entry needs keywords or the Always active option.')
            entries.append({'keys': keywords, 'content': content, 'constant': constant})
        return normalize_lorebook(entries)

    def import_character_lorebook(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Import lorebook JSON', str(Path.home()), 'JSON files (*.json)')
        if not filename:
            return
        try:
            incoming = import_lorebook_file(filename)
            # Don't silently discard or replace entries already being edited.
            existing = self.collect_lorebook_entries()
            merged = existing + [entry for entry in incoming if entry not in existing]
            self.set_lorebook_entries(merged)
            self.status(f'Imported {len(incoming)} lorebook entries (save character to keep changes).')
        except (OSError, ValueError) as exc:
            self.error(f'Lorebook import failed: {exc}')

    def toggle_generated_avatar(self, enabled):
        if enabled:
            self.generate_avatar_button.setText('✓ Generate portrait after saving')
            self.avatar_status_label.setText(
                'AI portrait selected. Saving will run Ollama → ComfyUI, attach the image, '
                'then open a new conversation.'
            )
        else:
            self.generate_avatar_button.setText('Use generated avatar (on save)')
            self.avatar_status_label.setText(
                'To generate a portrait: select Use generated avatar, then Save character.'
            )
        self._character_editor_preview()

    def cancel_avatar_generation(self):
        if self.current_avatar_worker is not None:
            self.current_avatar_worker.cancel_event.set()
            self.avatar_status_label.setText('Cancelling avatar generation…')

    def _avatar_generation_busy(self, is_busy):
        self.save_character_button.setEnabled(not is_busy)
        self.generate_avatar_button.setEnabled(not is_busy)
        self.cancel_avatar_button.setVisible(is_busy)

    def _start_character_avatar_generation(self, character_id, profile):
        if self.current_avatar_worker is not None:
            self.status('A character avatar is already being generated.')
            return
        # Snapshot selections before starting the asynchronous job. Never read Qt
        # widget values from the worker thread.
        ollama_base = self.ollama_url()
        model = self.current_model()
        comfy_base = self.comfy_url()
        preferred = self.checkpoint.currentText().strip() if hasattr(self, 'checkpoint') else ''
        options = self.llm_options()
        self._avatar_generation_busy(True)
        self.avatar_status_label.setText('Writing character portrait prompt with Ollama…')
        self.status(f'Creating AI portrait for {profile["name"]}…')

        def task(cancel, token_cb, status_cb):
            return generate_character_portrait(
                dict(profile), ollama_url=ollama_base, model=model, comfy_url=comfy_base,
                preferred_checkpoint=preferred, options=options,
                cancel=cancel, on_status=status_cb,
            )

        def done(result):
            self.current_avatar_worker = None
            self._avatar_generation_busy(False)
            path, _prompt, _checkpoint = result
            try:
                # The saved character may have been edited while generation ran.
                # Re-read it, then replace only its portrait field.
                latest = self.characters.get_character(character_id)
                if latest is None:
                    path.unlink(missing_ok=True)
                    self.avatar_status_label.setText('Character was deleted; portrait was not attached.')
                    return
                self.characters.update_character(character_id, {**latest, 'card_image': str(path)})
                if self.active_character == character_id:
                    self.edit_card_path = str(path)
                    self.generate_avatar_button.setChecked(False)
                    self._character_editor_preview()
                self.avatar_status_label.setText(f'Generated portrait attached: {path.name}')
                self.refresh_characters()
                self.refresh_chat_list()
                self.active_character = character_id
                self.status(f'Portrait generated for {latest["name"]}. Opening chat…')
                self.new_chat()
            except Exception as exc:
                self.error(f'The image was generated, but attaching it failed: {exc}')

        def fail(message):
            self.current_avatar_worker = None
            self._avatar_generation_busy(False)
            self.avatar_status_label.setText(
                'Portrait generation failed. Your character was saved; check Ollama and ComfyUI, then retry.'
            )
            self.error(f'Character saved, but avatar generation failed: {message}')

        job = self.run_job(
            task, done, on_status=lambda value: (
                self.status(value), self.avatar_status_label.setText(value)
            ), on_error=fail,
        )
        job.signals.cancelled.connect(self._avatar_cancelled)
        self.current_avatar_worker = job

    def _avatar_cancelled(self, reason):
        self.current_avatar_worker = None
        self._avatar_generation_busy(False)
        self.avatar_status_label.setText(
            'Avatar generation stopped. The character is saved; select the option and save again to retry.'
        )
        self.status(reason)

    def open_lightbox(self, pixmap):
        if pixmap is None or pixmap.isNull():
            return
        dialog = LightboxDialog(pixmap, self)
        dialog.setGeometry(self.rect())
        dialog.exec()

    def _fit_portrait_label(self, label, pixmap, *, max_width=None, min_box=(150, 150), max_height=None, padding=16):
        """Fit a portrait preview box to the pixmap while preserving aspect ratio."""
        if max_width is None:
            max_width = label.parentWidget().width() if label.parentWidget() else label.width()
        max_width = max(120, int(max_width) - padding)
        min_w, min_h = min_box
        if pixmap is None or pixmap.isNull():
            label.setPixmap(QPixmap())
            label.setFixedSize(max(min_w, min(max_width, 210)), min_h)
            if hasattr(label, 'set_image_state'):
                label.set_image_state(False)
            return
        source_w = max(1, pixmap.width())
        source_h = max(1, pixmap.height())
        target_w = min(max_width, source_w)
        target_h = int(round(source_h * (target_w / source_w)))
        if max_height and target_h > max_height:
            scale = max_height / source_h
            target_h = int(round(source_h * scale))
            target_w = int(round(source_w * scale))
        target_w = max(min_w, target_w)
        target_h = max(min_h, target_h)
        if max_height:
            target_h = min(max_height, target_h)
        scaled = pixmap.scaled(target_w, target_h,
                               Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation)
        label.setPixmap(scaled)
        if hasattr(label, 'set_image_state'):
            label.set_image_state(True)
        box_w = scaled.width() + padding
        box_h = scaled.height() + padding
        if max_width:
            box_w = min(max_width + padding, box_w)
        if max_height:
            box_h = min(max_height + padding, box_h)
        label.setFixedSize(box_w, box_h)

    def _refresh_chat_character_image(self):
        if not hasattr(self, 'chat_character_image'):
            return
        pix = getattr(self, '_chat_character_pixmap', QPixmap())
        if pix is None or pix.isNull():
            self.chat_character_image.setPixmap(QPixmap())
            self.chat_character_image.set_image_state(False)
            max_w = max(170, min(260, self.chat_character_tag_panel.width() if hasattr(self, 'chat_character_tag_panel') else 240))
            self.chat_character_image.setFixedSize(max_w, 150)
            return
        parent_width = self.chat_character_image.parentWidget().width() if self.chat_character_image.parentWidget() else 250
        self._fit_portrait_label(self.chat_character_image, pix, max_width=min(260, parent_width - 18), min_box=(140, 140), max_height=320, padding=18)

    def _character_editor_preview(self):
        if hasattr(self, 'generate_avatar_button') and self.generate_avatar_button.isChecked():
            self._editor_character_pixmap = QPixmap()
            self.character_editor_image.setPixmap(QPixmap())
            self.character_editor_image.setText('AI portrait will appear after you save the character.')
            self.character_editor_image.setFixedSize(210, 210)
            self.character_editor_image.set_image_state(False)
            self.card_path_label.setText('Generated avatar selected · waiting for Save character')
            return
        raw = self.edit_card_path
        file = None
        if raw:
            original = Path(raw)
            if original.is_file():
                file = original
            elif (CARD_DIR / original.name).is_file():
                file = CARD_DIR / original.name
        pix = QPixmap(str(file)) if file else QPixmap()
        if pix.isNull():
            self._editor_character_pixmap = QPixmap()
            self.character_editor_image.setPixmap(QPixmap())
            self.character_editor_image.setText('Save to generate a default avatar')
            self.character_editor_image.setFixedSize(210, 210)
            self.character_editor_image.set_image_state(False)
            self.card_path_label.setText('No uploaded portrait; IMGenius will create an avatar')
        else:
            self._editor_character_pixmap = pix
            self.character_editor_image.setText('')
            self._fit_portrait_label(self.character_editor_image, pix, max_width=260, min_box=(150, 150), max_height=320, padding=16)
            self.card_path_label.setText(f'Portrait: {file.name}')

    def remove_character_card(self):
        self.generate_avatar_button.setChecked(False)
        self.edit_card_path = None
        self._character_editor_preview()

    def edit_character(self):
        if self.active_character is None:
            self.error('Choose a character first.')
            return
        c = self.characters.get_character(self.active_character)
        if not c:
            self.error('Character no longer exists.')
            return
        for key, _ in FIELD_LABELS:
            w = self.character_fields[key]
            val = str(c.get(key) or '')
            if isinstance(w, QComboBox):
                w.setCurrentText(val.title() if val.lower() not in ('non-binary', 'futa') else ('Non-Binary' if val.lower() == 'non-binary' else 'Futa'))
                if w.currentText().casefold() != val.casefold():
                    w.setCurrentText('Other')
            elif isinstance(w, QLineEdit):
                w.setText(val)
            else:
                w.setPlainText(val)
        self.character_first_message.setPlainText(c.get('first_message') or default_first_message(c))
        self.character_system_prompt.setPlainText(c.get('system_prompt') or DEFAULT_SYSTEM_PROMPT)
        self.set_lorebook_entries(c.get('lorebook'))
        self._load_editor_tags(c.get('tags'))
        self.edit_card_path = c.get('card_image')
        self.generate_avatar_button.setChecked(False)
        self.editor_audience.setCurrentText(normalize_audience(c.get('audience')))
        self.editor_featured.setChecked(bool(c.get('featured')))
        self._character_editor_preview()
        self.navigate('editor')

    def _reset_character_editor(self):
        # Reset ALL visible state, not just the profile fields.  System Prompt
        # deliberately starts with the required template, not the previous card.
        self.active_character = None
        for w in self.character_fields.values():
            if isinstance(w, QComboBox):
                w.setCurrentText('Other')
            else:
                w.clear()
        self.character_first_message.clear()
        self.character_system_prompt.setPlainText(DEFAULT_SYSTEM_PROMPT)
        self.set_lorebook_entries([])
        self._load_editor_tags([])
        self.edit_card_path = None
        self.generate_avatar_button.setChecked(False)
        self.editor_audience.setCurrentText('Safe')
        self.editor_featured.setChecked(False)
        self._character_editor_preview()

    def new_character(self):
        self._reset_character_editor()
        self.navigate('editor')

    def import_character_card(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Import character card', str(Path.home()),
            'Character cards (*.png *.json);;Character Card PNG (*.png);;Character Card JSON (*.json)'
        )
        if not path:
            return
        # Parse and validate first. Invalid files must not clear an open draft.
        try:
            imported = load_character_card(path)
        except (OSError, ValueError) as exc:
            self.error(f'Could not import character card: {exc}')
            return
        self._apply_imported_card(imported)
        self.navigate('editor')

    def _apply_imported_card(self, imported):
        """Populate an unsaved editor draft from verified PNG/JSON character data."""
        self._reset_character_editor()
        for key, _ in FIELD_LABELS:
            field = self.character_fields[key]
            value = str(imported.get(key) or '')
            if isinstance(field, QComboBox):
                field.setCurrentText(value or 'Other')
            elif isinstance(field, QLineEdit):
                field.setText(value)
            else:
                field.setPlainText(value)
        # Bind the character-card profile fields explicitly by name. Never
        # transfer them by their visual row order; imported cards can contain
        # additional keys and their order is not meaningful.
        self.character_fields['short_description'].setPlainText(str(imported.get('short_description') or ''))
        self.character_fields['personality'].setPlainText(str(imported.get('personality') or ''))
        self.character_first_message.setPlainText(str(imported.get('first_message') or ''))
        self.character_system_prompt.setPlainText(str(imported.get('system_prompt') or DEFAULT_SYSTEM_PROMPT))
        self.set_lorebook_entries(imported.get('lorebook') or [])
        self._load_editor_tags(imported.get('tags') or [])
        self.editor_audience.setCurrentText(imported.get('audience') or 'Safe')
        self.editor_featured.setChecked(bool(imported.get('featured')))
        self.edit_card_path = imported.get('card_image') or None
        self._character_editor_preview()
        self.navigate('editor')
        self.status(f"Imported {imported['name']}; review and click Save character to add it.")

    def attach_character_card(self):
        file, _ = QFileDialog.getOpenFileName(self, 'Choose character portrait', str(Path.home()),
                                              'Images (*.png *.jpg *.jpeg *.webp)')
        if not file:
            return
        self.generate_avatar_button.setChecked(False)
        self.edit_card_path = file
        self._character_editor_preview()

    def save_character(self):
        if self.current_avatar_worker is not None:
            self.status('Wait for the current avatar generation to finish or cancel it.')
            return
        generate_avatar = self.generate_avatar_button.isChecked()
        old = self.characters.get_character(self.active_character) if self.active_character else None
        # Retain archived legacy fields instead of silently clearing them on edit.
        values = dict(old or {})
        for key, _ in FIELD_LABELS:
            w = self.character_fields[key]
            values[key] = (w.currentText() if isinstance(w, QComboBox) else
                           w.text() if isinstance(w, QLineEdit) else w.toPlainText()).strip()
        if not values['name']:
            self.error('A character name is required.')
            return
        try:
            values['lorebook'] = self.collect_lorebook_entries()
        except ValueError as exc:
            self.error(str(exc))
            return
        values['first_message'] = self.character_first_message.toPlainText().strip() or default_first_message(values)
        values['system_prompt'] = self.character_system_prompt.toPlainText().strip()
        values['tags'] = ', '.join(normalize_tags(self.editor_selected_tags))
        values['audience'] = self.editor_audience.currentText()
        values['featured'] = self.editor_featured.isChecked()
        values['favorite'] = int((old or {}).get('favorite') or 0)
        values['reaction'] = int((old or {}).get('reaction') or 0)
        if generate_avatar:
            # Keep an existing portrait until the new image has been generated
            # and attached successfully. A network error must never erase art.
            values['card_image'] = safe_text((old or {}).get('card_image'))
        elif self.edit_card_path:
            try:
                original = Path(self.edit_card_path)
                src = original if original.is_file() else CARD_DIR / original.name
                if not src.is_file():
                    raise FileNotFoundError(src)
                import uuid
                dest = CARD_DIR / f'portrait_{uuid.uuid4().hex[:16]}.png'
                if src.parent == CARD_DIR and src.suffix.lower() == '.png':
                    dest = src  # Keep existing character image without duplicating it.
                else:
                    with Image.open(src) as im:
                        im = im.convert('RGB')
                        im.thumbnail((1100, 1100))
                        im.save(dest, 'PNG', optimize=True)
                values['card_image'] = str(dest)
            except (OSError, ValueError) as exc:
                self.error(f'Unable to import character artwork: {exc}')
                return
        else:
            values['card_image'] = ''
        if self.active_character is None:
            self.active_character = self.characters.save_character(values)
        else:
            self.characters.update_character(self.active_character, values)
            if old is not None:
                # Only default titles follow a character rename. Preserve custom
                # chat titles and all previous messages verbatim.
                self.chats.rename_character_chats(
                    self.active_character, old.get('name'), values['name']
                )
        ensure_default_character_images()
        self.status(f'Saved character: {values["name"]}')
        self.refresh_characters()
        if generate_avatar:
            # Save first, then the worker generates and attaches the portrait.
            # A successful callback opens a new conversation for this character.
            self._start_character_avatar_generation(self.active_character, dict(values))
            return
        # Existing chats use the current character record for system prompts,
        # avatars and sender labels; refresh their visible details immediately.
        if self.current_chat_worker is None:
            self.refresh_chat_list()
        self.navigate('characters')

    def export_card(self):
        if self.active_character is None:
            self.error('Save the character before exporting its card.')
            return
        c = self.characters.get_character(self.active_character)
        target, _ = QFileDialog.getSaveFileName(self, 'Export character card',
                                                f'{c["name"].replace(" ", "_")}.png', 'PNG (*.png)')
        if not target: return
        try:
            source = export_character_card(c)
            if not source: raise RuntimeError('No card could be produced.')
            # Export PNG character metadata as well as artwork so a future
            # import can restore the profile, greeting, prompt and lorebook.
            export_character_card_png(c, source, target)
            self.status(f'Exported portable character card: {Path(target).name}')
        except Exception as exc: self.error(exc)

