"""Stories page: layout and handlers only."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import QFileDialog
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QListWidgetItem
from PySide6.QtWidgets import QMessageBox
from imgenius.images.comfy import ollama_chat
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import make_card
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import textedit
from pathlib import Path


class StoriesPageMixin:
    def _make_stories(self):
        outer, body = scroll_content()
        body.addWidget(section_label('Write, save, and continue local stories. Ollama is only needed for AI continuation.'))
        row = QHBoxLayout()
        row.addWidget(button('+ New story', self.new_story, True))
        row.addWidget(button('Edit selected', self.edit_story))
        row.addWidget(button('Delete selected', self.delete_story))
        row.addStretch(1)
        body.addLayout(row)
        self.story_list = QListWidget()
        self.story_list.itemSelectionChanged.connect(self.preview_story)
        body.addWidget(self.story_list, 1)
        self.story_preview = textedit(height=155)
        self.story_preview.setReadOnly(True)
        body.addWidget(self.story_preview)
        body.addStretch()
        self.register_page('stories', outer)

    def refresh_stories(self):
        self.story_list.blockSignals(True)
        previous = self.active_story
        self.story_list.clear()
        for story in self.stories.list_stories():
            entry = QListWidgetItem(f'{story["title"]}   ·   {story["genre"] or "No genre"}   ·   {len(story["content"]):,} characters')
            entry.setData(Qt.ItemDataRole.UserRole, story['id'])
            self.story_list.addItem(entry)
            if story['id'] == previous: self.story_list.setCurrentItem(entry)
        self.story_list.blockSignals(False)
        self.preview_story()

    def preview_story(self):
        entry = self.story_list.currentItem()
        if not entry: self.story_preview.clear(); return
        self.active_story = entry.data(Qt.ItemDataRole.UserRole)
        story = self.stories.get(self.active_story)
        if story:
            self.story_preview.setPlainText(f"Premise: {story['premise']}\n\n{story['content'][:1800]}")

    def _make_story_editor(self):
        outer, body = scroll_content()
        body.addWidget(section_label('Everything is saved to your own device; generation uses the configured Ollama model.'))
        panel = make_card('Story details',body)
        form = QFormLayout()
        self.story_title = QLineEdit()
        self.story_genre = QLineEdit()
        self.story_premise = textedit('What is this story about?',110)
        form.addRow('Title',self.story_title)
        form.addRow('Genre / style',self.story_genre)
        form.addRow('Premise / creative directions',self.story_premise)
        panel.addLayout(form)
        story_block = make_card('Story manuscript',body)
        self.story_content = textedit('Write your story here…',320)
        story_block.addWidget(self.story_content)
        actions = QHBoxLayout()
        actions.addWidget(button('Save',self.save_story,True))
        actions.addWidget(button('AI continue',self.generate_story))
        actions.addWidget(button('Stop',self.stop_story))
        actions.addWidget(button('Export .txt',self.export_story))
        actions.addStretch(1)
        body.addLayout(actions)
        self.story_job = None
        self.register_page('story_editor',outer)

    def new_story(self):
        self.active_story = None
        self.story_title.clear(); self.story_genre.clear(); self.story_premise.clear(); self.story_content.clear()
        self.navigate('story_editor')

    def edit_story(self):
        entry = self.story_list.currentItem()
        story_id = entry.data(Qt.ItemDataRole.UserRole) if entry else self.active_story
        if story_id is None: return
        story = self.stories.get(story_id)
        if not story: return
        self.active_story = story_id
        self.story_title.setText(story['title'])
        self.story_genre.setText(story['genre'])
        self.story_premise.setPlainText(story['premise'])
        self.story_content.setPlainText(story['content'])
        self.navigate('story_editor')

    def save_story(self):
        title = self.story_title.text().strip()
        if not title:
            self.error('A story title is required.')
            return
        self.active_story = self.stories.save(self.active_story, title,
                                              self.story_genre.text().strip(),
                                              self.story_premise.toPlainText().strip(),
                                              self.story_content.toPlainText())
        self.status(f'Saved {title}')

    def delete_story(self):
        entry = self.story_list.currentItem()
        if not entry: return
        if QMessageBox.question(self,'Delete story?', 'Permanently delete the selected story?') == QMessageBox.StandardButton.Yes:
            self.stories.delete(entry.data(Qt.ItemDataRole.UserRole))
            self.active_story = None
            self.refresh_stories()

    def export_story(self):
        title = self.story_title.text().strip() or 'Story'
        file, _ = QFileDialog.getSaveFileName(self,'Export story', f'{title}.txt', 'Text files (*.txt)')
        if file:
            try: Path(file).write_text(self.story_content.toPlainText(),encoding='utf-8'); self.status('Story exported')
            except OSError as exc: self.error(exc)

    def generate_story(self):
        if self.story_job:
            self.status('Story is still generating.')
            return
        model = self.current_model()
        if not model:
            self.error('Choose an Ollama model in Settings.')
            return
        prefix = self.story_content.toPlainText()
        title = self.story_title.text()
        premise = self.story_premise.toPlainText()
        genre = self.story_genre.text()
        base = self.ollama_url()
        options = self.llm_options()
        system = ('You are a creative writing assistant. Write the next portion of the story, preserving its setting, '
                  'characters, tone and chronology. Output story prose only, no commentary. '
                  f'Title: {title}\nGenre: {genre}\nPremise: {premise}')
        messages = [{'role':'user','content':f'Continue this story naturally (do not repeat the excerpt):\n{prefix[-12000:]}'}]
        if prefix and not prefix.endswith('\n'): self.story_content.insertPlainText('\n\n')
        part = ['']
        def handle_token(token):
            part[0] += token
            self.story_content.moveCursor(QTextCursor.MoveOperation.End)
            self.story_content.insertPlainText(token)
        def task(cancel,token,status):
            return ollama_chat(base,model,system,messages,options,on_token=token,cancel=cancel)
        def done(_):
            self.story_job = None
            self.status('Story continuation complete — save when ready.')
        def fail(message):
            self.story_job = None
            self.error(message)
        self.story_job = self.run_job(task,done,handle_token,on_error=fail)
        self.story_job.signals.cancelled.connect(lambda msg: self._story_stopped(msg))
        self.status('Writing story…')

    def _story_stopped(self, msg):
        self.story_job = None
        self.status(msg)

    def stop_story(self):
        if self.story_job: self.story_job.cancel_event.set()

