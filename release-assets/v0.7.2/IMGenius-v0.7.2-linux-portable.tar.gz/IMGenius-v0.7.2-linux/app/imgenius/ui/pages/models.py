"""Models page: layout and handlers only."""
from __future__ import annotations
from imgenius.shared.paths import default_comfy_root, normalize_comfy_root

from PySide6.QtCore import QSize
from PySide6.QtCore import QUrl
from PySide6.QtCore import Qt
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QCheckBox
from PySide6.QtWidgets import QFileDialog
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QListWidgetItem
from PySide6.QtWidgets import QMessageBox
from PySide6.QtWidgets import QTabWidget
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.domain import query_huggingface
from imgenius.images.comfy import ollama_models
from imgenius.models.creative_catalog import available_ggufs
from imgenius.models.creative_catalog import filter_creative_models
from imgenius.models.creative_catalog import ollama_hf_ref
from imgenius.models.creative_catalog import preferred_variant_index
from imgenius.models.civitai import search_weights, install_destination, download_weight
from imgenius.models.manager import OLLAMA_CATALOG
from imgenius.models.manager import download_hf_file
from imgenius.models.manager import import_gguf_ollama
from imgenius.models.manager import list_hf_files
from imgenius.models.manager import pull_ollama
from imgenius.models.manager import target_path
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import make_card
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import textedit
from pathlib import Path


class ModelsPageMixin:
    def _make_models(self):
        root = QWidget()
        page = QVBoxLayout(root)
        page.setContentsMargins(24, 18, 24, 22)
        page.setSpacing(16)
        page.addWidget(section_label('Install and manage local language models and image-generation weights.'))
        self.model_tabs = QTabWidget()
        self.model_tabs.setObjectName('WorkspaceTabs')
        self.model_tabs.setDocumentMode(True)
        page.addWidget(self.model_tabs, 1)

        def tab_body(label, description):
            scroll, contents = scroll_content()
            contents.setContentsMargins(17, 20, 17, 24)
            contents.addWidget(section_label(description))
            self.model_tabs.addTab(scroll, label)
            return contents

        ollama_body = tab_body('Ollama', 'Your installed models and quick-install options.')
        creative_body = tab_body('Creative / Roleplay', 'Curated character and storytelling models from Hugging Face.')
        hf_body = tab_body('Hugging Face', 'Search repositories, inspect files, and download compatible weights.')
        civitai_body = tab_body('Civitai · SDXL / Illustrious', 'Only SDXL 1.0 or Illustrious checkpoints and LoRAs; validated per model version.')
        comfy_body = tab_body('ComfyUI', 'Check local checkpoints and installed image-model availability.')

        llm = make_card('Ollama — installed and available models', ollama_body)
        self.model_ollama_status = textedit(height=106)
        self.model_ollama_status.setReadOnly(True)
        self.model_ollama_status.setMaximumHeight(142)
        self.model_ollama_status.setPlaceholderText('Refresh to see models installed in Ollama.')
        llm.addWidget(self.model_ollama_status)
        llm.addWidget(button('Refresh installed Ollama models', self.refresh_ollama))
        llm.addWidget(section_label('Suggested model variants (offline starter catalog; use a custom name for others):'))
        self.ollama_filter = QLineEdit()
        self.ollama_filter.setPlaceholderText('Filter models, e.g. qwen, 4b, llama…')
        self.ollama_filter.textChanged.connect(self.filter_ollama_catalog)
        llm.addWidget(self.ollama_filter)
        self.ollama_catalog = QListWidget()
        self.ollama_catalog.setMinimumHeight(255)
        self.ollama_catalog.itemSelectionChanged.connect(self.select_ollama_catalog)
        llm.addWidget(self.ollama_catalog)
        row = QHBoxLayout()
        self.model_to_install = QLineEdit()
        self.model_to_install.setPlaceholderText('Ollama name or variant (e.g. qwen3:4b)')
        row.addWidget(self.model_to_install, 1)
        row.addWidget(button('Install model', self.pull_ollama, True))
        llm.addLayout(row)
        self.ollama_transfer = section_label('Install status: idle')
        self.ollama_transfer.setWordWrap(True)
        llm.addWidget(self.ollama_transfer)
        self.ollama_cancel = button('Cancel Ollama download', self.cancel_model_transfer)
        self.ollama_cancel.setEnabled(False)
        llm.addWidget(self.ollama_cancel)
        self.filter_ollama_catalog('')

        creative = make_card('Creative writing & roleplay — curated Hugging Face models', creative_body)
        intro = section_label('Real GGUF repositories · Select a model, load its available variants, then install through Ollama.')
        intro.setWordWrap(True)
        creative.addWidget(intro)
        self.creative_search = QLineEdit()
        self.creative_search.setPlaceholderText('Search creative models, e.g. Stheno, Mistral, 8B, roleplay…')
        self.creative_search.textChanged.connect(self.filter_creative_catalog)
        creative.addWidget(self.creative_search)
        self.creative_list = QListWidget()
        self.creative_list.setMinimumHeight(260)
        self.creative_list.setWordWrap(True)
        self.creative_list.itemSelectionChanged.connect(self.select_creative_model)
        creative.addWidget(self.creative_list)
        self.creative_details = section_label('Select a model to see its Hugging Face source and details.')
        self.creative_details.setWordWrap(True)
        creative.addWidget(self.creative_details)
        repo_actions = QHBoxLayout()
        self.creative_browse = button('Load GGUF variants', self.load_creative_variants)
        self.creative_open = button('Open Hugging Face page', self.open_creative_repository)
        repo_actions.addWidget(self.creative_browse)
        repo_actions.addWidget(self.creative_open)
        repo_actions.addStretch()
        creative.addLayout(repo_actions)
        variant_row = QHBoxLayout()
        variant_row.addWidget(QLabel('Quantization'))
        self.creative_variants = NoWheelComboBox()
        self.creative_variants.setEnabled(False)
        self.creative_variants.currentIndexChanged.connect(self.update_creative_install_controls)
        variant_row.addWidget(self.creative_variants, 1)
        creative.addLayout(variant_row)
        self.creative_warning = section_label(
            '8GB GPU note: 8B Q4 models are generally the lighter options. '
            '11–13B models may need partial CPU offload, especially at long context lengths.')
        self.creative_warning.setWordWrap(True)
        creative.addWidget(self.creative_warning)
        self.creative_transfer = section_label('Choose a model, then load its available quantizations.')
        self.creative_transfer.setWordWrap(True)
        creative.addWidget(self.creative_transfer)
        transfer_buttons = QHBoxLayout()
        self.creative_install = button('Install selected variant into Ollama', self.install_creative_model, True)
        self.creative_cancel = button('Cancel installation', self.cancel_model_transfer)
        transfer_buttons.addWidget(self.creative_install, 1)
        transfer_buttons.addWidget(self.creative_cancel)
        creative.addLayout(transfer_buttons)
        self.creative_cancel.setEnabled(False)
        self.creative_install.setEnabled(False)
        self._creative_loading_repo = None
        self.filter_creative_catalog('')

        hf = make_card('Hugging Face — find and download model files', hf_body)
        search = QHBoxLayout()
        self.hf_query = QLineEdit()
        self.hf_query.setPlaceholderText('Search repositories, e.g. Illustrious XL or SDXL LoRA')
        self.hf_query.returnPressed.connect(self.search_huggingface)
        search.addWidget(self.hf_query, 1)
        search.addWidget(button('Search', self.search_huggingface))
        hf.addLayout(search)
        results_row = QHBoxLayout()
        results_row.setSpacing(14)
        repo_panel = QVBoxLayout()
        repo_panel.addWidget(section_label('1 · Repositories'))
        self.hf_repos = QListWidget()
        self.hf_repos.setMinimumHeight(240)
        self.hf_repos.itemSelectionChanged.connect(self.clear_hf_files)
        repo_panel.addWidget(self.hf_repos, 1)
        repo_panel.addWidget(button('Browse selected repository', self.browse_hf_files))
        results_row.addLayout(repo_panel, 1)
        file_panel = QVBoxLayout()
        file_panel.addWidget(section_label('2 · Available model files'))
        self.hf_files = QListWidget()
        self.hf_files.setMinimumHeight(240)
        self.hf_files.itemSelectionChanged.connect(self.update_hf_controls)
        file_panel.addWidget(self.hf_files, 1)
        results_row.addLayout(file_panel, 1)
        hf.addLayout(results_row)
        dest_row = QFormLayout()
        self.hf_destination = NoWheelComboBox()
        for label, key in [
            ('ComfyUI · SDXL/IL checkpoints', 'checkpoint'),
            ('ComfyUI · LoRAs', 'lora'),
            ('ComfyUI · VAE', 'vae'),
            ('ComfyUI · ControlNet', 'controlnet'),
            ('ComfyUI · Embeddings', 'embedding'),
            ('ComfyUI · Upscalers', 'upscale'),
            ('Ollama · GGUF model', 'ollama'),
        ]:
            self.hf_destination.addItem(label, key)
        self.hf_destination.currentIndexChanged.connect(self.update_hf_controls)
        dest_row.addRow('Install as', self.hf_destination)
        hf.addLayout(dest_row)
        root_row = QHBoxLayout()
        self.comfy_root_field = QLineEdit(str(default_comfy_root()))
        root_row.addWidget(QLabel('ComfyUI folder'))
        root_row.addWidget(self.comfy_root_field, 1)
        root_row.addWidget(button('Browse…', self.pick_comfy_root))
        hf.addLayout(root_row)
        self.hf_import_ollama = QCheckBox('Import downloaded GGUF into local Ollama')
        self.hf_import_ollama.setChecked(True)
        hf.addWidget(self.hf_import_ollama)
        name_row = QHBoxLayout()
        self.hf_ollama_name_label = QLabel('Ollama model name')
        name_row.addWidget(self.hf_ollama_name_label)
        self.hf_ollama_name = QLineEdit()
        self.hf_ollama_name.setPlaceholderText('e.g. my-model')
        name_row.addWidget(self.hf_ollama_name, 1)
        hf.addLayout(name_row)
        hf.addWidget(section_label('Select a single .safetensors or .gguf file. Check architecture, license, size and any dependencies on Hugging Face before installing.'))
        self.hf_download = button('Download selected file', self.install_huggingface, True)
        self.hf_download.setEnabled(False)
        hf.addWidget(self.hf_download)
        self.hf_transfer = section_label('Download status: idle')
        self.hf_transfer.setWordWrap(True)
        hf.addWidget(self.hf_transfer)
        self.hf_cancel = button('Cancel Hugging Face download', self.cancel_model_transfer)
        self.hf_cancel.setEnabled(False)
        hf.addWidget(self.hf_cancel)
        self.model_transfer_job = None
        self.update_hf_controls()

        civitai = make_card('Civitai.red — SDXL 1.0 & Illustrious models', civitai_body)
        civitai.addWidget(section_label(
            'Search Civitai’s public catalog. Only compatible SDXL 1.0 and Illustrious '
            'versions of checkpoints and LoRAs appear. Pony, Flux, SD 1.5 and unknown architectures are excluded.'))
        civitai_search = QHBoxLayout()
        self.civitai_query = QLineEdit()
        self.civitai_query.setPlaceholderText('Search SDXL / Illustrious checkpoints and LoRAs…')
        self.civitai_query.returnPressed.connect(self.search_civitai)
        civitai_search.addWidget(self.civitai_query, 1)
        civitai_search.addWidget(button('Search Civitai', self.search_civitai))
        civitai.addLayout(civitai_search)
        civitai_filters = QHBoxLayout()
        civitai_filters.addWidget(QLabel('Architecture'))
        self.civitai_base = NoWheelComboBox()
        self.civitai_base.addItem('SDXL + Illustrious', 'both')
        self.civitai_base.addItem('SDXL 1.0', 'SDXL 1.0')
        self.civitai_base.addItem('Illustrious', 'Illustrious')
        civitai_filters.addWidget(self.civitai_base)
        civitai_filters.addWidget(QLabel('Type'))
        self.civitai_category = NoWheelComboBox()
        self.civitai_category.addItem('Checkpoints + LoRAs', 'both')
        self.civitai_category.addItem('Checkpoints only', 'checkpoint')
        self.civitai_category.addItem('LoRAs only', 'lora')
        civitai_filters.addWidget(self.civitai_category)
        civitai.addLayout(civitai_filters)
        self.civitai_base.currentIndexChanged.connect(self.clear_civitai_results)
        self.civitai_category.currentIndexChanged.connect(self.clear_civitai_results)
        self.civitai_results = QListWidget()
        self.civitai_results.setMinimumHeight(320)
        self.civitai_results.setWordWrap(True)
        self.civitai_results.itemSelectionChanged.connect(self.update_civitai_controls)
        civitai.addWidget(self.civitai_results)
        browse_buttons = QHBoxLayout()
        self.civitai_more = button('Load more', self.load_more_civitai)
        self.civitai_more.setEnabled(False)
        self.civitai_open = button('Open on civitai.red', self.open_civitai_page)
        browse_buttons.addWidget(self.civitai_more)
        browse_buttons.addWidget(self.civitai_open)
        browse_buttons.addStretch(1)
        civitai.addLayout(browse_buttons)
        civitai.addWidget(section_label('Install destination: the ComfyUI models/checkpoints or models/loras folder selected under Hugging Face.'))
        self.civitai_download = button('Download selected .safetensors', self.install_civitai, True)
        civitai.addWidget(self.civitai_download)
        self.civitai_transfer = section_label('Search for SDXL 1.0 or Illustrious model weights to get started.')
        self.civitai_transfer.setWordWrap(True)
        civitai.addWidget(self.civitai_transfer)
        self.civitai_cancel = button('Cancel Civitai download', self.cancel_model_transfer)
        self.civitai_cancel.setEnabled(False)
        civitai.addWidget(self.civitai_cancel)
        self._civitai_cursor = None
        self._civitai_loading = False
        self._civitai_search_key = None
        self._civitai_search_pending = False
        self.update_civitai_controls()

        comfy = make_card('Installed ComfyUI checkpoints', comfy_body)
        self.model_comfy_status = textedit(height=130)
        self.model_comfy_status.setReadOnly(True)
        self.model_comfy_status.setMaximumHeight(200)
        self.model_comfy_status.setPlaceholderText('Refresh to list installed checkpoints.')
        comfy.addWidget(self.model_comfy_status)
        comfy.addWidget(button('Refresh ComfyUI models', self.refresh_comfy_models))
        for tab_layout in (ollama_body, creative_body, hf_body, civitai_body, comfy_body):
            tab_layout.addStretch(1)
        self.register_page('models', root)

    def selected_civitai_weight(self):
        item = self.civitai_results.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def clear_civitai_results(self, *_):
        self._civitai_cursor = None
        self._civitai_search_key = None
        self.civitai_results.clear()
        self.civitai_more.setEnabled(False)
        self.update_civitai_controls()

    def update_civitai_controls(self, *_):
        if not hasattr(self, 'civitai_download'):
            return
        selected = self.selected_civitai_weight()
        busy = getattr(self, 'model_transfer_job', None) is not None
        self.civitai_download.setEnabled(selected is not None and not busy)
        self.civitai_open.setEnabled(selected is not None)

    def search_civitai(self):
        self.clear_civitai_results()
        if self._civitai_loading:
            self._civitai_search_pending = True
        else:
            self._request_civitai_page(None)

    def load_more_civitai(self):
        if self._civitai_cursor:
            self._request_civitai_page(self._civitai_cursor)

    def _request_civitai_page(self, cursor):
        if self._civitai_loading:
            return
        query = self.civitai_query.text().strip()
        category = self.civitai_category.currentData()
        base = self.civitai_base.currentData()
        key = (query, category, base)
        self._civitai_search_key = key
        self._civitai_loading = True
        self.civitai_more.setEnabled(False)
        self.civitai_transfer.setText('Searching Civitai’s SDXL / Illustrious catalog…')
        def task(cancel, token, status):
            return search_weights(query, category=category, base=base, cursor=cursor)
        def done(result):
            self._civitai_loading = False
            if self._civitai_search_pending:
                self._civitai_search_pending = False
                self._request_civitai_page(None)
                return
            if self._civitai_search_key != key:
                return
            found, next_cursor = result
            for model in found:
                size = f'{model.size_bytes / (1024**3):.2f} GiB' if model.size_bytes else 'size unknown'
                label = (f'{model.model_name}  ·  {model.version_name}\n'
                         f'{model.base_model} · {model.category.upper()} · {size}  ·  {model.filename}')
                item = QListWidgetItem(label)
                item.setData(Qt.ItemDataRole.UserRole, model)
                item.setToolTip(model.page_url)
                item.setSizeHint(QSize(300, 55))
                self.civitai_results.addItem(item)
            self._civitai_cursor = next_cursor
            self.civitai_more.setEnabled(bool(next_cursor))
            self.civitai_transfer.setText(
                f'{self.civitai_results.count()} compatible versions found.'
                if self.civitai_results.count() else
                'No compatible weights on this page. Try another search or Load more.')
            self.update_civitai_controls()
        def failed(message):
            self._civitai_loading = False
            if self._civitai_search_pending:
                self._civitai_search_pending = False
                self._request_civitai_page(None)
                return
            if self._civitai_search_key == key:
                self.civitai_transfer.setText(f'Civitai search failed: {message}')
                self.civitai_more.setEnabled(bool(self._civitai_cursor))
        self.run_job(task, done, on_error=failed)

    def open_civitai_page(self):
        selected = self.selected_civitai_weight()
        if selected:
            QDesktopServices.openUrl(QUrl(selected.page_url))

    def install_civitai(self):
        selected = self.selected_civitai_weight()
        if selected is None or self.model_transfer_job is not None:
            return
        try:
            target = install_destination(selected, self.comfy_root_field.text())
            if target.exists():
                raise FileExistsError(f'{target.name} is already installed.')
        except (ValueError, FileExistsError) as exc:
            self.error(str(exc))
            return
        size = f'{selected.size_bytes / (1024**3):.2f} GiB' if selected.size_bytes else 'unknown size'
        notice = (f'Download {selected.model_name} · {selected.version_name}?\n'
                  f'Architecture: {selected.base_model}\nType: {selected.category}\n'
                  f'File: {selected.filename} ({size})\n\nSave to:\n{target}\n\n'
                  'Only a single .safetensors file will be installed. Confirm model licensing separately.')
        if QMessageBox.question(self, 'Confirm Civitai model download', notice,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self.civitai_transfer.setText('Downloading selected compatible model…')
        def task(cancel, token, status):
            def progress(completed, total):
                if total:
                    status(f'{completed / 1048576:.1f} / {total / 1048576:.1f} MiB · '
                           f'{100 * completed // total}%')
                else:
                    status(f'{completed / 1048576:.1f} MiB downloaded')
            return download_weight(selected, target, cancel=cancel, on_progress=progress)
        def done(saved):
            self.civitai_transfer.setText(f'Downloaded {saved.name}. Restart ComfyUI if it is not visible.')
            self.status(f'Downloaded Civitai model: {saved.name}')
            self.refresh_comfy_models()
        self._start_model_transfer(task, done, on_status=self.civitai_transfer.setText, source='civitai')

    def filter_ollama_catalog(self, value):
        self.ollama_catalog.clear()
        query = value.strip().lower()
        for family, variants in OLLAMA_CATALOG:
            for variant in variants:
                if query in family.lower() or query in variant.lower():
                    item = QListWidgetItem(f'{family}   ·   {variant}')
                    item.setData(Qt.ItemDataRole.UserRole, variant)
                    self.ollama_catalog.addItem(item)

    def select_ollama_catalog(self):
        item = self.ollama_catalog.currentItem()
        if item:
            self.model_to_install.setText(item.data(Qt.ItemDataRole.UserRole))

    def filter_creative_catalog(self, query):
        current = self.selected_creative_model()
        old_repo = current.repo_id if current else None
        self.creative_list.blockSignals(True)
        self.creative_list.clear()
        for model in filter_creative_models(query):
            label = f'{model.title}    ·    {model.params}    ·    {model.category}\n{model.description}\n{model.repo_id}'
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, model)
            item.setToolTip(model.url)
            item.setSizeHint(QSize(300, 80))
            self.creative_list.addItem(item)
            if model.repo_id == old_repo:
                self.creative_list.setCurrentItem(item)
        if self.creative_list.currentRow() < 0 and self.creative_list.count():
            self.creative_list.setCurrentRow(0)
        self.creative_list.blockSignals(False)
        self.select_creative_model()

    def selected_creative_model(self):
        item = self.creative_list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def select_creative_model(self):
        model = self.selected_creative_model()
        self._creative_loading_repo = None
        self.creative_variants.clear()
        self.creative_variants.setEnabled(False)
        self.creative_browse.setEnabled(bool(model))
        self.creative_open.setEnabled(bool(model))
        if model:
            self.creative_details.setText(
                f'{model.title} · {model.params} · {model.category}\n'
                f'{model.description}\nSource: {model.repo_id}')
            self.creative_transfer.setText('Load variants to check the actual GGUF files and sizes.')
        else:
            self.creative_details.setText('No matches. Try another search.')
            self.creative_transfer.setText('Select a model first.')
        self.update_creative_install_controls()

    def open_creative_repository(self):
        model = self.selected_creative_model()
        if model:
            QDesktopServices.openUrl(QUrl(model.url))

    def load_creative_variants(self):
        model = self.selected_creative_model()
        if not model or self._creative_loading_repo is not None:
            return
        self._creative_loading_repo = model.repo_id
        self.creative_browse.setEnabled(False)
        self.creative_transfer.setText(f'Checking Hugging Face: {model.repo_id}…')
        def task(cancel, token, status):
            return available_ggufs(list_hf_files(model.repo_id))
        def done(variants):
            if self.selected_creative_model() != model:
                return
            self._creative_loading_repo = None
            self.creative_browse.setEnabled(True)
            self.creative_variants.blockSignals(True)
            self.creative_variants.clear()
            for variant in variants:
                size = variant['size']
                display_size = f'{size / (1024**3):.2f} GiB' if size is not None else 'size unknown'
                self.creative_variants.addItem(
                    f'{variant["quant"]}  ·  {display_size}  ·  {Path(variant["name"]).name}', variant)
            selected = preferred_variant_index(variants, model.recommended_quant)
            if selected >= 0:
                self.creative_variants.setCurrentIndex(selected)
            self.creative_variants.blockSignals(False)
            self.creative_variants.setEnabled(bool(variants))
            self.creative_transfer.setText(
                f'{len(variants)} single-file GGUF variants available. Select one to install.'
                if variants else 'No directly pullable single-file GGUF quantizations found. Open the source page for details.')
            self.update_creative_install_controls()
        def fail(message):
            if self.selected_creative_model() == model:
                self.creative_transfer.setText(f'Unable to load variants: {message}')
                self._creative_loading_repo = None
                self.creative_browse.setEnabled(True)
                self.update_creative_install_controls()
        self.run_job(task, done, on_error=fail)

    def update_creative_install_controls(self, *_):
        if not hasattr(self, 'creative_install'):
            return
        transfer = getattr(self, 'model_transfer_job', None)
        self.creative_install.setEnabled(
            self.selected_creative_model() is not None and
            self.creative_variants.currentData() is not None and
            self._creative_loading_repo is None and transfer is None)
        self.creative_cancel.setEnabled(transfer is not None)

    def install_creative_model(self):
        model = self.selected_creative_model()
        variant = self.creative_variants.currentData()
        if not model or not variant or self.model_transfer_job is not None:
            return
        try:
            name = ollama_hf_ref(model.repo_id, variant['name'])
        except ValueError as exc:
            self.error(str(exc))
            return
        size = variant['size']
        size_text = f'{size / (1024 ** 3):.2f} GiB' if size is not None else 'size unknown'
        question = (f'Install {model.title} ({variant["quant"]}) into your configured Ollama server?\n\n'
                    f'Hugging Face: {model.repo_id}\n'
                    f'Model file: {variant["name"]}\n'
                    f'Download size: {size_text}\n\n'
                    'Your available RAM/VRAM and chosen context size affect performance. '
                    'On an 8GB GPU, larger models may run partly on the CPU.')
        if QMessageBox.question(self, 'Confirm model installation', question,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        base = self.ollama_url()
        self.creative_transfer.setText(f'Installing {name}…')
        def task(cancel, token, status):
            def progress(message, completed, total):
                if total:
                    status(f'{message}  ·  {completed / (1024**2):.0f}/{total / (1024**2):.0f} MiB '
                           f'({100 * completed // total}%)')
                else:
                    status(message)
            return pull_ollama(base, name, cancel=cancel, on_progress=progress)
        def progress(text):
            self.creative_transfer.setText(text)
            self.ollama_transfer.setText(text)
        def done(installed):
            self.creative_transfer.setText(f'Installed in Ollama: {installed} · Available in chat model selection.')
            self.ollama_transfer.setText(f'Installed {installed}.')
            if hasattr(self, 'chat_model_field'):
                self.chat_model_field.setCurrentText(installed)
            if hasattr(self, 'chat_side_model'):
                self.chat_side_model.setCurrentText(installed)
            self.refresh_ollama()
        self._start_model_transfer(task, done, ollama=True, on_status=progress)

    def cancel_model_transfer(self):
        if self.model_transfer_job:
            self.model_transfer_job.cancel_event.set()
            self.status('Requesting transfer cancellation…')

    def _start_model_transfer(self, task, done, *, ollama=False, on_status=None, source='hf'):
        if self.model_transfer_job is not None:
            self.error('A model transfer is already running. Cancel or finish it first.')
            return
        self.ollama_cancel.setEnabled(ollama)
        self.hf_cancel.setEnabled(not ollama and source != 'civitai')
        self.civitai_cancel.setEnabled(source == 'civitai')
        self.hf_download.setEnabled(False)
        self.creative_install.setEnabled(False)
        self.creative_cancel.setEnabled(True)
        def finished(result):
            self.model_transfer_job = None
            self.ollama_cancel.setEnabled(False)
            self.hf_cancel.setEnabled(False)
            self.civitai_cancel.setEnabled(False)
            self.update_civitai_controls()
            self.update_hf_controls()
            self.update_creative_install_controls()
            done(result)
        def failed(message):
            self.model_transfer_job = None
            self.ollama_cancel.setEnabled(False)
            self.hf_cancel.setEnabled(False)
            self.civitai_cancel.setEnabled(False)
            self.update_civitai_controls()
            self.update_hf_controls()
            self.update_creative_install_controls()
            if source == 'civitai':
                self.civitai_transfer.setText(f'Installation failed: {message}')
            else:
                self.creative_transfer.setText(f'Installation failed: {message}')
            self.error(message)
        self.model_transfer_job = self.run_job(task, finished, on_error=failed,
                                               on_status=on_status or (self.ollama_transfer.setText if ollama else self.hf_transfer.setText))
        def cancelled(message):
            self.model_transfer_job = None
            self.ollama_cancel.setEnabled(False)
            self.hf_cancel.setEnabled(False)
            self.civitai_cancel.setEnabled(False)
            self.update_civitai_controls()
            self.update_hf_controls()
            self.update_creative_install_controls()
            if ollama:
                self.ollama_transfer.setText(message)
            elif source == 'civitai':
                self.civitai_transfer.setText(message)
            else:
                self.hf_transfer.setText(message)
        self.model_transfer_job.signals.cancelled.connect(cancelled)
        self.update_creative_install_controls()
        self.update_civitai_controls()

    def refresh_ollama(self):
        base = self.ollama_url()
        self.status('Querying local Ollama…')
        def task(cancel, token, status):
            return ollama_models(base)
        def done(models):
            names = [m.get('name', '') for m in models if m.get('name')]
            existing = self.chat_model_field.currentText()
            self.chat_model_field.clear()
            self.chat_model_field.addItems(names)
            if existing in names:
                self.chat_model_field.setCurrentText(existing)
            elif names:
                self.chat_model_field.setCurrentIndex(0)
            elif existing:
                self.chat_model_field.setCurrentText(existing)
            if hasattr(self, 'chat_side_model'):
                current = self.chat_side_model.currentText()
                self.chat_side_model.clear()
                self.chat_side_model.addItems(names)
                if current in names:
                    self.chat_side_model.setCurrentText(current)
                elif names:
                    self.chat_side_model.setCurrentIndex(0)
                elif current:
                    self.chat_side_model.setCurrentText(current)
            self.model_ollama_status.setPlainText('\n'.join(names) if names else 'No installed models. Choose a suggested model below and install it.')
            self.status(f'Ollama: {len(names)} installed models')
        self.run_job(task, done)

    def pull_ollama(self):
        name = self.model_to_install.text().strip()
        if not name:
            self.error('Select a suggested model or type an Ollama model name.')
            return
        base = self.ollama_url()
        self.ollama_transfer.setText(f'Starting download for {name}…')
        def task(cancel, token, status):
            def progress(message, done, total):
                if total:
                    status(f'{name}: {message}  ·  {done / 1048576:.0f}/{total / 1048576:.0f} MiB ({done * 100 // total}%)')
                else:
                    status(f'{name}: {message}')
            return pull_ollama(base, name, cancel=cancel, on_progress=progress)
        def done(value):
            self.ollama_transfer.setText(f'Installed {value} successfully.')
            self.refresh_ollama()
        self._start_model_transfer(task, done, ollama=True)

    def search_huggingface(self):
        query = self.hf_query.text().strip()
        self.hf_repos.clear()
        self.hf_files.clear()
        self.hf_download.setEnabled(False)
        self.status('Searching Hugging Face…')
        def task(cancel, token, status):
            return query_huggingface(query)
        def done(items):
            for repo in items:
                identifier = repo.get('id')
                if not identifier:
                    continue
                item = QListWidgetItem(f'{identifier}   ·   {repo.get("downloads", 0):,} downloads')
                item.setData(Qt.ItemDataRole.UserRole, identifier)
                self.hf_repos.addItem(item)
            self.status(f'{self.hf_repos.count()} Hugging Face repositories')
        self.run_job(task, done)

    def clear_hf_files(self):
        self.hf_files.clear()
        self.update_hf_controls()

    def browse_hf_files(self):
        repo = self.hf_repos.currentItem()
        if not repo:
            self.error('Select a Hugging Face repository first.')
            return
        repo_id = repo.data(Qt.ItemDataRole.UserRole)
        self.status(f'Reading files in {repo_id}…')
        def task(cancel, token, status):
            return list_hf_files(repo_id)
        def done(files):
            current = self.hf_repos.currentItem()
            if not current or current.data(Qt.ItemDataRole.UserRole) != repo_id:
                return  # The user switched to another repository during the request.
            self.hf_files.clear()
            for f in files:
                size = f'{f["size"] / (1024**3):.2f} GiB' if f['size'] is not None else 'size unknown'
                item = QListWidgetItem(f'{f["name"]}    ({size})')
                item.setData(Qt.ItemDataRole.UserRole, f)
                self.hf_files.addItem(item)
            self.hf_transfer.setText(f'{len(files)} supported weight files found.' if files else
                                     'No .gguf or .safetensors weights found in this repository.')
            self.status(f'{len(files)} available weight files')
        self.run_job(task, done)

    def pick_comfy_root(self):
        path = QFileDialog.getExistingDirectory(self, 'Select local ComfyUI directory', self.comfy_root_field.text())
        if path:
            self.comfy_root_field.setText(str(normalize_comfy_root(path)))
            self.settings.setValue('comfy_root', str(normalize_comfy_root(path)))

    def update_hf_controls(self):
        # Invoked only after _make_models has initialized all widgets.
        is_ollama = self.hf_destination.currentData() == 'ollama'
        self.hf_import_ollama.setVisible(is_ollama)
        self.hf_ollama_name.setVisible(is_ollama)
        self.hf_ollama_name_label.setVisible(is_ollama)
        self.comfy_root_field.setEnabled(not is_ollama)
        selected = self.hf_files.currentItem()
        if selected and is_ollama and not self.hf_ollama_name.text().strip():
            repo = self.hf_repos.currentItem()
            if repo:
                suggested = repo.data(Qt.ItemDataRole.UserRole).split('/')[-1].lower()
                suggested = ''.join(c if c.isalnum() or c in '._-' else '-' for c in suggested).strip('-')
                self.hf_ollama_name.setPlaceholderText(suggested[:90] or 'my-model')
        compatible = False
        if selected is not None:
            filename = selected.data(Qt.ItemDataRole.UserRole)['name'].lower()
            compatible = filename.endswith('.gguf') if is_ollama else filename.endswith('.safetensors')
        self.hf_download.setEnabled(compatible and self.model_transfer_job is None)

    def install_huggingface(self):
        repo = self.hf_repos.currentItem()
        file_item = self.hf_files.currentItem()
        if not repo or not file_item:
            self.error('Select a Hugging Face repository and one of its files first.')
            return
        repo_id = repo.data(Qt.ItemDataRole.UserRole)
        file_data = file_item.data(Qt.ItemDataRole.UserRole)
        filename = file_data['name']
        destination = self.hf_destination.currentData()
        try:
            target = target_path(repo_id, filename, destination,
                                 comfy_root=self.comfy_root_field.text().strip())
            if destination != 'ollama':
                folder = Path(self.comfy_root_field.text()).expanduser()
                if not (folder / 'models').is_dir():
                    raise ValueError('That directory has no models/ folder. Choose your real local ComfyUI root.')
            if target.exists():
                raise FileExistsError(f'{target.name} is already installed; no files were replaced.')
        except (ValueError, FileExistsError) as exc:
            self.error(str(exc))
            return
        import_ollama = destination == 'ollama' and self.hf_import_ollama.isChecked()
        model_name = self.hf_ollama_name.text().strip().lower()
        if import_ollama and not model_name:
            self.error('Enter a local Ollama name for the GGUF model, or uncheck import.')
            return
        size = file_data['size']
        size_text = f'{size / (1024 ** 3):.2f} GiB' if size is not None else 'unknown size'
        message = (f'Download {filename} ({size_text}) from {repo_id}?\n\n'
                   f'Install location:\n{target}\n\n'
                   'This may consume considerable disk space. File architecture and compatibility are not automatically verified.')
        if QMessageBox.question(self, 'Confirm model download', message,
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        self.hf_transfer.setText('Preparing download…')
        def task(cancel, token, status):
            def progress(done, total):
                if total:
                    status(f'{done / 1048576:.1f} / {total / 1048576:.1f} MiB  ·  {done * 100 // total}%')
                else:
                    status(f'{done / 1048576:.1f} MiB downloaded (size unknown)')
            saved = download_hf_file(repo_id, filename, target, cancel=cancel, on_progress=progress)
            if import_ollama:
                status('Downloaded. Importing into local Ollama…')
                imported_name = import_gguf_ollama(saved, model_name, cancel=cancel, on_status=status)
                return saved, imported_name
            return saved, None
        def done(result):
            saved, imported = result
            self.hf_transfer.setText(f'Installed at {saved}' + (f'  ·  Ollama model: {imported}' if imported else ''))
            self.status(f'Downloaded {saved.name}; restart ComfyUI if the new model is missing.')
            if imported:
                self.refresh_ollama()
            elif destination != 'ollama':
                self.refresh_comfy_models()
        self._start_model_transfer(task, done)

