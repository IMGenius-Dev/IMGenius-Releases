"""Characters page: layout and handlers only."""
from __future__ import annotations

import json

from PySide6.QtCore import Qt
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import QGridLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QMessageBox
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QWidget
from PySide6.QtWidgets import QVBoxLayout
from collections import Counter
from imgenius.characters.grid_layout import character_grid_metrics
from imgenius.data.cleanup import protected_character_ids
from imgenius.data.character_deletion import delete_character_with_chats
from imgenius.shared.paths import CARD_DIR
from imgenius.characters.library import TAG_ICONS
from imgenius.characters.library import filter_characters
from imgenius.characters.library import normalize_tags
from imgenius.characters.library import visible_discovery_tags
from imgenius.characters.pagination import PAGE_SIZE
from imgenius.characters.pagination import clamp_page
from imgenius.characters.pagination import paginate
from imgenius.ui.widgets.characters import CharacterTile
from imgenius.ui.widgets.characters import FlowLayout
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label


class CharacterLibraryPageMixin:
    def _make_character_list(self):
        outer, page_body = scroll_content()
        self.characters_scroller = outer
        self.characters_scroller.viewport().installEventFilter(self)
        self.character_online_mode = False
        switch_row = QHBoxLayout()
        heading = QLabel('Character library')
        heading.setObjectName('LibrarySection')
        switch_row.addWidget(heading)
        switch_row.addStretch(1)
        self.character_local_toggle = button('My characters', lambda: self.set_character_source(False))
        self.character_online_toggle = button('Chub', lambda: self.set_character_source(True))
        for toggle in (self.character_local_toggle, self.character_online_toggle):
            toggle.setObjectName('TagChip')
            toggle.setCheckable(True)
            switch_row.addWidget(toggle)
        self.character_local_toggle.setChecked(True)
        page_body.addLayout(switch_row)
        self.character_local_panel = QWidget()
        body = QVBoxLayout(self.character_local_panel)
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(14)
        page_body.addWidget(self.character_local_panel)
        body.addWidget(section_label('Browse locally stored characters. Tags can be combined; all matches update instantly.'))
        search_row = QHBoxLayout()
        self.character_filter = QLineEdit()
        self.character_filter.setPlaceholderText('Search character names, descriptions, or scenarios…')
        self.character_filter.textChanged.connect(self.refresh_characters)
        search_row.addWidget(self.character_filter, 1)
        search_row.addWidget(button('+ New character', self.new_character, True))
        body.addLayout(search_row)

        controls = QHBoxLayout()
        local = button('💾 Local', self.reset_character_filters)
        local.setObjectName('ChipClear')
        local.setToolTip('Show all characters stored on this device')
        controls.addWidget(local)
        self.character_featured = QPushButton('🏆 Featured')
        self.character_featured.setObjectName('TagChip')
        self.character_featured.setCheckable(True)
        self.character_featured.toggled.connect(self.refresh_characters)
        controls.addWidget(self.character_featured)
        self.character_favorites = QPushButton('★ Favorites')
        self.character_favorites.setObjectName('TagChip')
        self.character_favorites.setCheckable(True)
        self.character_favorites.toggled.connect(self.refresh_characters)
        controls.addWidget(self.character_favorites)
        controls.addWidget(QLabel('Content'))
        self.character_audience_filter = NoWheelComboBox()
        self.character_audience_filter.addItems(['All', 'Safe', 'Mature'])
        self.character_audience_filter.currentIndexChanged.connect(self.refresh_characters)
        controls.addWidget(self.character_audience_filter)
        controls.addWidget(QLabel('Sort'))
        self.character_sort = NoWheelComboBox()
        self.character_sort.addItems(['Newest', 'Name A–Z', 'Name Z–A', 'Favorites first'])
        self.character_sort.currentIndexChanged.connect(self.refresh_characters)
        controls.addWidget(self.character_sort)
        controls.addStretch()
        body.addLayout(controls)

        tag_header = QHBoxLayout()
        tag_title = QLabel('Discover by tag')
        tag_title.setObjectName('LibrarySection')
        tag_header.addWidget(tag_title)
        tag_header.addWidget(section_label('Popular tags first · Combine tags to refine results'))
        tag_header.addStretch()
        self.character_tag_expand = button('Show all tags', self.toggle_library_tags)
        self.character_tag_expand.setObjectName('ChipClear')
        tag_header.addWidget(self.character_tag_expand)
        clear = button('Clear tags', self.clear_character_tag_filters)
        clear.setObjectName('ChipClear')
        tag_header.addWidget(clear)
        body.addLayout(tag_header)
        self.character_tag_search = QLineEdit()
        self.character_tag_search.setPlaceholderText('Find any tag (search reveals hidden tags)…')
        self.character_tag_search.textChanged.connect(self.refresh_characters)
        body.addWidget(self.character_tag_search)
        self.character_tags_panel = QWidget()
        self.character_tags_panel.setObjectName('TagPanel')
        self.character_tag_layout = FlowLayout(self.character_tags_panel, spacing=6)
        body.addWidget(self.character_tags_panel)
        self.character_active_filters = section_label('No selected tags')
        body.addWidget(self.character_active_filters)

        result_header = QHBoxLayout()
        self.character_count_label = QLabel('Characters')
        self.character_count_label.setObjectName('LibrarySection')
        result_header.addWidget(self.character_count_label)
        result_header.addStretch()
        self.character_bulk_favorite = button('★ Favorite selected', self.favorite_selected_characters)
        self.character_bulk_clear = button('Clear selection', self.clear_character_selection)
        result_header.addWidget(self.character_bulk_favorite)
        result_header.addWidget(self.character_bulk_clear)
        body.addLayout(result_header)

        pagination = QHBoxLayout()
        pagination.addStretch(1)
        self.character_page_back = button('←', lambda: self.shift_character_page(-1))
        self.character_page_back.setToolTip('Previous page')
        self.character_page_back.setFixedWidth(42)
        self.character_page_back.setObjectName('CharacterPageArrow')
        pagination.addWidget(self.character_page_back)
        pagination.addWidget(QLabel('Page'))
        self.character_page_input = QLineEdit('1')
        self.character_page_input.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.character_page_input.setFixedWidth(68)
        self.character_page_input.setToolTip('Enter a page number and press Enter to jump')
        self.character_page_input.setValidator(QIntValidator(1, 9999999, self.character_page_input))
        self.character_page_input.returnPressed.connect(self.jump_to_character_page)
        pagination.addWidget(self.character_page_input)
        self.character_page_total = QLabel('/ 1')
        self.character_page_total.setObjectName('Muted')
        pagination.addWidget(self.character_page_total)
        self.character_page_forward = button('→', lambda: self.shift_character_page(1))
        self.character_page_forward.setToolTip('Next page')
        self.character_page_forward.setFixedWidth(42)
        self.character_page_forward.setObjectName('CharacterPageArrow')
        pagination.addWidget(self.character_page_forward)
        self.character_page_range = section_label('Showing 0 characters')
        pagination.addWidget(self.character_page_range)
        pagination.addStretch(1)
        self.character_cards_container = QWidget()
        self.character_cards_container.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.character_grid = QGridLayout(self.character_cards_container)
        self.character_grid.setSpacing(14)
        self.character_grid.setContentsMargins(0, 0, 0, 0)
        self.character_grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        body.addWidget(self.character_cards_container)
        # Page navigation follows the results, so it is reached after the cards.
        body.addLayout(pagination)
        body.addStretch(1)
        self._build_telegai_panel(page_body)
        page_body.addStretch(1)
        self.register_page('characters', outer)

    def set_character_source(self, online):
        """Switch the existing Characters grid without opening a browser window."""
        online = bool(online)
        self.character_online_mode = online
        self.character_local_toggle.setChecked(not online)
        self.character_online_toggle.setChecked(online)
        self.character_local_panel.setVisible(not online)
        self.telegai_panel.setVisible(online)
        if online:
            if not self._telegai_loaded:
                self._telegai_fetch()
            else:
                self._telegai_reflow()
        else:
            self._schedule_character_grid_reflow()
        self.characters_scroller.verticalScrollBar().setValue(0)

    def browse_telegai_in_characters(self):
        self.navigate('characters')
        self.set_character_source(True)

    def _tag_tokens(self, value):
        return normalize_tags(value)

    def _make_library_tag_buttons(self, characters):
        while self.character_tag_layout.count():
            item = self.character_tag_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        query = self.character_tag_search.text().strip()
        shown, count = visible_discovery_tags(
            characters, selected_tags=self.active_tag_filters, search=query,
            expanded=self.character_tags_expanded, limit=12,
        )
        for label in shown:
            b = QPushButton((TAG_ICONS.get(label, '') + ' ' + label).strip())
            b.setObjectName('TagChip')
            b.setCheckable(True)
            b.setChecked(label.casefold() in self.active_tag_filters)
            b.toggled.connect(lambda checked, tag=label: self.toggle_character_tag(tag, checked))
            self.character_tag_layout.addWidget(b)
        if not query:
            self.character_tag_expand.setVisible(count > 12)
            self.character_tag_expand.setText('Show fewer tags' if self.character_tags_expanded else
                                              f'Show all tags (+{max(0, count - len(shown))})')
        else:
            self.character_tag_expand.setVisible(False)
        self.character_tags_panel.updateGeometry()
        self.character_tag_layout.invalidate()

    def toggle_library_tags(self):
        self.character_tags_expanded = not self.character_tags_expanded
        self.settings.setValue('character_tags_expanded', self.character_tags_expanded)
        self.refresh_characters(rebuild_tags=True)

    def toggle_character_tag(self, tag, checked):
        key = tag.casefold()
        if checked:
            self.active_tag_filters.add(key)
        else:
            self.active_tag_filters.discard(key)
        self.refresh_characters(rebuild_tags=False)

    def clear_character_tag_filters(self):
        self.active_tag_filters.clear()
        self.character_tag_search.clear()
        self.refresh_characters()

    def reset_character_filters(self):
        self.active_tag_filters.clear()
        for field in (self.character_filter, self.character_tag_search):
            field.blockSignals(True)
            field.clear()
            field.blockSignals(False)
        for control in (self.character_featured, self.character_favorites):
            control.blockSignals(True)
            control.setChecked(False)
            control.blockSignals(False)
        self.character_audience_filter.blockSignals(True)
        self.character_audience_filter.setCurrentIndex(0)
        self.character_audience_filter.blockSignals(False)
        self.refresh_characters()

    def _clear_character_grid(self):
        while self.character_grid.count():
            item = self.character_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.character_card_widgets = []

    def _reflow_character_grid(self):
        if getattr(self, 'character_online_mode', False):
            return
        if not hasattr(self, 'character_grid') or not hasattr(self, 'character_cards_container'):
            return
        viewport_width = self.characters_scroller.viewport().width()
        if viewport_width < 150:  # hidden/uninitialized pages are laid out on Show
            return
        tiles = self.character_card_widgets
        columns, card_width = character_grid_metrics(viewport_width, len(tiles))
        layout_key = (viewport_width, len(tiles), columns, card_width)
        if layout_key == self._character_grid_layout_key:
            return
        self._character_grid_layout_key = layout_key
        self._character_grid_columns = columns
        for item in tiles:
            self.character_grid.removeWidget(item)
        for index, tile in enumerate(tiles):
            if isinstance(tile, CharacterTile):
                tile.set_card_width(card_width)
                self.character_grid.addWidget(
                    tile, index // columns, index % columns,
                    Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
            else:
                self.character_grid.addWidget(tile, 0, 0, 1, columns)
        self.character_cards_container.updateGeometry()

    def shift_character_page(self, offset):
        self.character_page = clamp_page(
            self.character_page + offset, self._character_filtered_count, PAGE_SIZE
        )
        self.refresh_characters(rebuild_tags=False)
        self.characters_scroller.verticalScrollBar().setValue(0)

    def jump_to_character_page(self):
        # The editor does not apply input until Enter is pressed.
        self.character_page = clamp_page(
            self.character_page_input.text(), self._character_filtered_count, PAGE_SIZE
        )
        self.refresh_characters(rebuild_tags=False)
        self.characters_scroller.verticalScrollBar().setValue(0)

    def refresh_characters(self, *_, rebuild_tags=True):
        characters = self.characters.list_characters()
        self.selected_character_ids.intersection_update({c['id'] for c in characters})
        if rebuild_tags:
            self._make_library_tag_buttons(characters)
        signature = (
            self.character_filter.text(), self.character_tag_search.text(),
            tuple(sorted(self.active_tag_filters)), self.character_audience_filter.currentText(),
            self.character_featured.isChecked(), self.character_favorites.isChecked(),
            self.character_sort.currentText(),
        )
        if signature != self._character_filter_signature:
            self.character_page = 1
            self._character_filter_signature = signature
            self.characters_scroller.verticalScrollBar().setValue(0)
        found = filter_characters(
            characters, query=self.character_filter.text(), tag_query=self.character_tag_search.text(),
            selected_tags=self.active_tag_filters,
            audience=self.character_audience_filter.currentText(),
            featured_only=self.character_featured.isChecked(),
            favorites_only=self.character_favorites.isChecked(),
            sort=self.character_sort.currentText(),
        )
        self._character_filtered_count = len(found)
        visible, self.character_page, total_pages = paginate(found, self.character_page, PAGE_SIZE)
        self.character_page_input.setText(str(self.character_page))
        self.character_page_total.setText(f'/ {total_pages}')
        self.character_page_back.setEnabled(self.character_page > 1)
        self.character_page_forward.setEnabled(self.character_page < total_pages)
        begin = (self.character_page - 1) * PAGE_SIZE + 1 if found else 0
        end = begin + len(visible) - 1 if found else 0
        self.character_page_range.setText(f'Showing {begin}–{end} of {len(found)}')
        self.character_active_filters.setText(
            ('Selected: ' + ', '.join(sorted(self.active_tag_filters))) if self.active_tag_filters else 'No selected tags'
        )
        self.character_count_label.setText(f'{len(found)} character{"s" if len(found) != 1 else ""} found')
        self.character_bulk_favorite.setEnabled(bool(self.selected_character_ids))
        self.character_bulk_clear.setEnabled(bool(self.selected_character_ids))
        self._clear_character_grid()
        chat_counts = Counter(c['character_id'] for c in self.chats.list_chats())
        protected = protected_character_ids(self.characters)
        for character in visible:
            tile = CharacterTile(character, chat_counts.get(character['id'], 0),
                                 character['id'] in self.selected_character_ids, self,
                                 deletable=character['id'] not in protected)
            self.character_card_widgets.append(tile)
        if not found:
            blank = QLabel('No characters match these filters. Clear tags or change the content filter.')
            blank.setObjectName('Muted')
            self.character_card_widgets.append(blank)
        self._character_grid_columns = 0
        self._character_grid_layout_key = None
        self._reflow_character_grid()
        self._schedule_character_grid_reflow()
        self.on_character_selected()

    def select_character(self, character_id):
        self.active_character = character_id
        self.on_character_selected()

    def toggle_character_selection(self, character_id, checked):
        if checked:
            self.selected_character_ids.add(character_id)
        else:
            self.selected_character_ids.discard(character_id)
        self.active_character = character_id
        self.on_character_selected()
        self.character_bulk_favorite.setEnabled(bool(self.selected_character_ids))
        self.character_bulk_clear.setEnabled(bool(self.selected_character_ids))

    def clear_character_selection(self):
        self.selected_character_ids.clear()
        self.refresh_characters(rebuild_tags=False)

    def favorite_selected_characters(self):
        for character_id in self.selected_character_ids:
            self.characters.set_character_flags(character_id, favorite=1)
        self.status(f'Favorited {len(self.selected_character_ids)} selected character(s).')
        self.refresh_characters(rebuild_tags=False)

    def toggle_character_favorite(self, character_id):
        character = self.characters.get_character(character_id)
        if character:
            self.characters.set_character_flags(character_id, favorite=not character.get('favorite'))
            self.refresh_characters(rebuild_tags=False)

    def react_character(self, character_id, reaction):
        character = self.characters.get_character(character_id)
        if character:
            next_value = 0 if character.get('reaction') == reaction else reaction
            self.characters.set_character_flags(character_id, reaction=next_value)
            self.refresh_characters(rebuild_tags=False)

    def delete_character_by_id(self, character_id):
        """Delete a local user-added card and every linked conversation."""
        if not self._can_cleanup():
            return
        character = self.characters.get_character(character_id)
        if character is None:
            self.refresh_characters()
            return
        if character_id in protected_character_ids(self.characters):
            self.error('Bundled and catalog characters cannot be deleted here.')
            return
        chats = [chat for chat in self.chats.list_chats()
                 if chat['character_id'] == character_id]
        message_count = sum(chat['message_count'] for chat in chats)
        answer = QMessageBox.warning(
            self, 'Permanently delete character?',
            f'Delete "{character["name"]}" and all {len(chats)} linked conversations '
            f'({message_count} messages)?\n\n'
            'Character details and associated chat messages will be permanently removed. '
            'Generated gallery images and stories will be kept. This cannot be undone.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            result = delete_character_with_chats(
                self.characters, self.chats, character_id, CARD_DIR)
        except Exception as exc:
            self.error(f'Unable to delete character: {exc}')
            return
        if result['deleted']:
            if self.active_chat in result['chat_ids']:
                self.active_chat = None
            if self.active_character == character_id:
                self.active_character = None
                self._reset_character_editor()
            self.selected_character_ids.discard(character_id)
            for chat_id in result['chat_ids']:
                self.chat_context_notes.pop(str(chat_id), None)
                self.chat_context_notes.pop(chat_id, None)
            self.settings.setValue('chat_context_notes', json.dumps(self.chat_context_notes))
            self.settings.sync()
            self.refresh_characters()
            self.refresh_chat_list()
            self.refresh_cleanup_summary()
            self.status(f'Deleted character and {result["chats_deleted"]} linked conversation(s).')

    def edit_character_by_id(self, character_id):
        self.active_character = character_id
        self.edit_character()

    def start_chat_for_character(self, character_id):
        self.active_character = character_id
        self.new_chat()

    def export_character_by_id(self, character_id):
        self.active_character = character_id
        self.export_card()

    def on_character_selected(self):
        # Character cards own their chat/edit controls; no redundant detail pane.
        # Keep the selected ID valid for navigation and card actions.
        if self.active_character is not None and not self.characters.get_character(self.active_character):
            self.active_character = None

