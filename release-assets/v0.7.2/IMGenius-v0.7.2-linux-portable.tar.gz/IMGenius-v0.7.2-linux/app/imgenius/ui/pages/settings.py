"""Settings page: layout and handlers only."""
from __future__ import annotations
from imgenius.shared.paths import default_comfy_root, normalize_comfy_root

from PySide6.QtCore import QUrl
from PySide6.QtGui import QColor
from PySide6.QtGui import QDesktopServices
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QApplication
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QInputDialog
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QMessageBox
from imgenius.data.cleanup import clear_all_chats
from imgenius.data.cleanup import custom_character_summary
from imgenius.data.cleanup import delete_custom_characters
from imgenius.domain import CARD_DIR
from imgenius.domain import DATA_DIR
from imgenius.ui.styles import STYLE
from imgenius.ui.themes import THEMES
from imgenius.ui.themes import build_theme_stylesheet
from imgenius.ui.themes import theme_palette
from imgenius.ui.widgets.controls import NoWheelComboBox
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import make_card
from imgenius.ui.widgets.controls import scroll_content
from imgenius.ui.widgets.controls import section_label
from pathlib import Path
import json


class SettingsPageMixin:
    def _make_settings(self):
        outer, body = scroll_content()
        body.addWidget(section_label('Personalize IMGenius, manage local data, and configure your AI engines.'))

        appearance = make_card('Appearance', body)
        appearance_form = QFormLayout()
        self.theme_selector = NoWheelComboBox()
        self.theme_selector.addItems(THEMES)
        self.theme_selector.setToolTip('Themes apply immediately and are remembered for future sessions.')
        appearance_form.addRow('Application theme', self.theme_selector)
        appearance.addLayout(appearance_form)
        self.theme_description = section_label('Choose a theme to preview it throughout IMGenius.')
        self.theme_description.setWordWrap(True)
        appearance.addWidget(self.theme_description)
        self.theme_selector.currentTextChanged.connect(self.on_theme_changed)

        connections = make_card('Local AI engines', body)
        grid = QFormLayout()
        self.ollama_url_field = QLineEdit('http://127.0.0.1:11434')
        self.comfy_url_field = QLineEdit('http://127.0.0.1:8188')
        self.chat_model_field = NoWheelComboBox()
        self.chat_model_field.setEditable(True)
        self.chat_model_field.addItem('qwen3:4b')
        grid.addRow('Ollama URL', self.ollama_url_field)
        grid.addRow('ComfyUI URL', self.comfy_url_field)
        grid.addRow('Chat / story model', self.chat_model_field)
        connections.addLayout(grid)
        rows = QHBoxLayout()
        rows.addWidget(button('Test Ollama', self.refresh_ollama))
        rows.addWidget(button('Test ComfyUI', self.refresh_comfy_models))
        rows.addStretch()
        connections.addLayout(rows)
        connections.addWidget(section_label('Chat generation settings are now managed on the Chats page.'))

        info = make_card('Local storage', body)
        self.data_path = section_label(
            f'Characters, chats, stories, artwork and generated images are stored at:\n{DATA_DIR}'
        )
        self.data_path.setWordWrap(True)
        info.addWidget(self.data_path)
        info.addWidget(section_label('Your saved models and generated images are not affected by chat/character cleanup.'))
        info.addWidget(button('Open data directory',
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(DATA_DIR.resolve())))))

        danger = make_card('Data cleanup', body)
        warning = section_label('These actions permanently remove local IMGenius data. Both require confirmation.')
        warning.setWordWrap(True)
        danger.addWidget(warning)
        self.cleanup_chat_info = section_label('Checking saved conversations…')
        self.cleanup_chat_info.setWordWrap(True)
        danger.addWidget(self.cleanup_chat_info)
        danger.addWidget(button('Clear all chats and messages', self.clear_all_chats_clicked))
        self.cleanup_character_info = section_label('Checking custom characters…')
        self.cleanup_character_info.setWordWrap(True)
        danger.addWidget(self.cleanup_character_info)
        danger.addWidget(button('Delete all custom and imported characters', self.delete_custom_characters_clicked))
        danger.addWidget(section_label('Keeps Nova, Atlas and the 200 original catalog characters. Existing chats are not deleted when characters are removed.'))
        body.addWidget(button('Save settings', self.save_settings, True))
        body.addStretch()
        self.register_page('settings', outer)
        self.refresh_cleanup_summary()

    def apply_theme(self, name, persist=True):
        if name not in THEMES:
            name = 'Dark'
        app = QApplication.instance()
        if app is None:
            return
        scheme = theme_palette(name)
        pal = QPalette(app.palette())
        colors = {
            QPalette.ColorRole.Window: scheme['background'],
            QPalette.ColorRole.WindowText: scheme['text'],
            QPalette.ColorRole.Base: scheme['field'],
            QPalette.ColorRole.AlternateBase: scheme['panel'],
            QPalette.ColorRole.Text: scheme['text'],
            QPalette.ColorRole.Button: scheme['button'],
            QPalette.ColorRole.ButtonText: scheme['text'],
            QPalette.ColorRole.Highlight: scheme['selected'],
            QPalette.ColorRole.HighlightedText: scheme['text'],
            QPalette.ColorRole.ToolTipBase: scheme['panel'],
            QPalette.ColorRole.ToolTipText: scheme['text'],
        }
        for role, value in colors.items():
            pal.setColor(role, QColor(value))
        app.setPalette(pal)
        app.setStyleSheet(build_theme_stylesheet(STYLE, name, app.font().family()))
        # A few widgets use local stylesheets, which override the application QSS.
        if hasattr(self, 'chat_heading'):
            self.chat_heading.setStyleSheet(f"font-size:18px;font-weight:700;color:{scheme['text']};background:transparent;")
        if hasattr(self, 'chat_character_image'):
            self.chat_character_image.setStyleSheet(
                f"background:{scheme['field']};border:1px solid {scheme['border']};border-radius:10px;")
        if hasattr(self, 'image_preview'):
            self.image_preview.setStyleSheet(
                f"background:{scheme['field']};border:1px solid {scheme['border']};border-radius:12px;padding:0px;")
        if hasattr(self, 'theme_description'):
            labels = {
                'Breeze': 'KDE Breeze-inspired light colors and familiar blue accents.',
                'Dark': 'The original IMGenius navy and cyan appearance.',
                'Black': 'Near-black surfaces with bright, readable text.',
                'Light': 'A clean neutral light interface.',
                'Ocean': 'Deep blue-green surfaces and teal accents.',
                'Plum': 'Deep violet surfaces and soft purple accents.',
            }
            self.theme_description.setText(labels[name])
        if persist:
            self.settings.setValue('theme', name)
            self.settings.sync()
        self.current_theme = name

    def on_theme_changed(self, name):
        if name:
            self.apply_theme(name)
            self.status(f'Appearance: {name}')

    def refresh_cleanup_summary(self):
        if not hasattr(self, 'cleanup_chat_info'):
            return
        chat_count = self.chats.conn.execute('SELECT COUNT(*) FROM chats').fetchone()[0]
        msg_count = self.chats.conn.execute('SELECT COUNT(*) FROM messages').fetchone()[0]
        self.cleanup_chat_info.setText(f'{chat_count} conversation(s), {msg_count} message(s) stored locally.')
        info = custom_character_summary(self.characters)
        self.cleanup_character_info.setText(
            f"{info['custom_count']} custom/imported character(s) · {info['base_count']} base character(s) protected."
        )

    def _confirm_data_deletion(self, title, description):
        decision = QMessageBox.warning(
            self, title, description + '\n\nThis operation cannot be undone.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if decision != QMessageBox.StandardButton.Yes:
            return False
        entered, accepted = QInputDialog.getText(
            self, title, 'Type DELETE to confirm:'
        )
        return bool(accepted and entered.strip() == 'DELETE')

    def _can_cleanup(self):
        if self.current_chat_worker is not None or self.current_image_worker is not None or self.jobs:
            self.error('Wait for active AI/model tasks to finish before deleting data.')
            return False
        return True

    def clear_all_chats_clicked(self):
        if not self._can_cleanup():
            return
        chats = self.chats.conn.execute('SELECT COUNT(*) FROM chats').fetchone()[0]
        if not chats:
            self.status('There are no saved chats to clear.')
            return
        if not self._confirm_data_deletion(
            'Delete ALL IMGenius conversations?',
            f'This deletes {chats} IMGenius conversations and every saved chat message. '
            'It does not remove characters, saved images, stories, or models.'
        ):
            return
        try:
            result = clear_all_chats(self.chats)
        except Exception as exc:
            self.error(f'Unable to clear conversations: {exc}')
            return
        self.active_chat = None
        self.chat_context_notes.clear()
        self.settings.setValue('chat_context_notes', '{}')
        self.settings.sync()
        self.chat_list.clear()
        self.refresh_chat_messages()
        self.refresh_chat_list()
        self.refresh_characters()
        self.refresh_cleanup_summary()
        self.status(f"Deleted {result['chats_deleted']} chats and {result['messages_deleted']} messages.")

    def delete_custom_characters_clicked(self):
        if not self._can_cleanup():
            return
        summary = custom_character_summary(self.characters)
        if not summary['custom_count']:
            self.status('There are no custom or imported characters to delete.')
            return
        if not self._confirm_data_deletion(
            'Delete custom and imported characters?',
            f"This permanently deletes {summary['custom_count']} custom/imported characters. "
            f"The {summary['base_count']} base characters stay. Chats with deleted characters "
            'remain in chat history but will no longer have a character persona.'
        ):
            return
        try:
            result = delete_custom_characters(self.characters, CARD_DIR)
        except Exception as exc:
            self.error(f'Unable to remove characters: {exc}')
            return
        self.active_character = None
        self.selected_character_ids.clear()
        self._reset_character_editor()
        self.refresh_characters()
        self.refresh_chat_list()
        self.refresh_chat_messages()
        self.refresh_cleanup_summary()
        self.status(f"Deleted {result['deleted']} custom/imported characters; kept {result['retained']} base characters.")

    def _load_settings(self):
        s = self.settings
        self.ollama_url_field.setText(str(s.value('ollama_url', 'http://127.0.0.1:11434')))
        self.comfy_url_field.setText(str(s.value('comfy_url', 'http://127.0.0.1:8188')))
        model = str(s.value('chat_model', 'qwen3:4b'))
        self.chat_model_field.setCurrentText(model)
        self.chat_side_model.setCurrentText(model)
        configured_comfy = str(normalize_comfy_root(s.value('comfy_root', str(default_comfy_root()))))
        if not (Path(configured_comfy).expanduser() / 'main.py').is_file():
            configured_comfy = str(default_comfy_root())
        self.comfy_root_field.setText(configured_comfy)
        for key, control in (
            ('temperature', self.chat_temperature), ('top_p', self.chat_top_p),
            ('repeat_penalty', self.chat_repeat_penalty), ('context', self.chat_context),
            ('tokens', self.chat_tokens),
        ):
            value = s.value(key, None)
            if value is not None:
                try:
                    control.setValue(float(value) if key in ('temperature', 'top_p', 'repeat_penalty') else int(value))
                except (TypeError, ValueError):
                    pass
        raw_notes = s.value('chat_context_notes', '{}')
        try:
            self.chat_context_notes = json.loads(raw_notes) if raw_notes else {}
        except (TypeError, ValueError, json.JSONDecodeError):
            self.chat_context_notes = {}
        self._load_chat_image_settings()
        self._connect_chat_image_settings()
        self.refresh_personas(str(s.value('persona_id', 'default-user')))
        theme_name = str(s.value('theme', 'Dark'))
        if theme_name not in THEMES:
            theme_name = 'Dark'
        self.theme_selector.blockSignals(True)
        self.theme_selector.setCurrentText(theme_name)
        self.theme_selector.blockSignals(False)
        self.apply_theme(theme_name, persist=False)

    def save_settings(self):
        if hasattr(self, 'image_prompt_library'):
            self._persist_image_prompts()
        s = self.settings
        s.setValue('ollama_url', self.ollama_url())
        s.setValue('comfy_url', self.comfy_url())
        s.setValue('chat_model', self.current_model())
        s.setValue('comfy_root', self.comfy_root_field.text().strip())
        for key, control in (
            ('temperature', self.chat_temperature), ('top_p', self.chat_top_p),
            ('repeat_penalty', self.chat_repeat_penalty), ('context', self.chat_context),
            ('tokens', self.chat_tokens),
        ):
            s.setValue(key, control.value())
        self._save_chat_image_settings()
        s.setValue('chat_context_notes', json.dumps(self.chat_context_notes))
        if hasattr(self, 'chat_persona'):
            s.setValue('persona_id', self.chat_persona.currentData() or 'default-user')
        if hasattr(self, 'theme_selector'):
            s.setValue('theme', self.theme_selector.currentText())
        s.sync()
        self.status('Settings saved')

