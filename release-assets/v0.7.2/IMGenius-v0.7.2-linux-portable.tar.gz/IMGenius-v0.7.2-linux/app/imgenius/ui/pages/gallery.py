"""Gallery page: layout and handlers only."""
from __future__ import annotations

from PySide6.QtCore import QSize
from PySide6.QtCore import QUrl
from PySide6.QtCore import Qt
from PySide6.QtGui import QDesktopServices
from PySide6.QtGui import QIcon
from PySide6.QtGui import QImageReader
from PySide6.QtGui import QPixmap
from PySide6.QtGui import QShortcut
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import QFileDialog
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QListView
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QListWidgetItem
from PySide6.QtWidgets import QMessageBox
from PySide6.QtWidgets import QMenu
from PySide6.QtWidgets import QSplitter
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.domain import DATA_DIR
from imgenius.images.gallery_storage import delete_managed_gallery_image
from imgenius.ui.layout import fit_image_size
from imgenius.ui.layout import image_files
from imgenius.ui.widgets.controls import button
from imgenius.ui.widgets.controls import section_label
from imgenius.ui.widgets.controls import section_panel
from imgenius.ui.widgets.visuals import AspectFitPreview
from pathlib import Path
import shutil


class GalleryPageMixin:
    def _make_gallery(self):
        root = QWidget()
        body = QVBoxLayout(root)
        body.setContentsMargins(24, 18, 24, 22)
        body.setSpacing(15)
        body.addWidget(section_label('Browse saved generations visually. Select a thumbnail to preview it without stretching.'))

        workspace = QSplitter(Qt.Orientation.Horizontal)
        workspace.setObjectName('GalleryWorkspace')
        workspace.setChildrenCollapsible(False)
        workspace.setHandleWidth(8)

        browser, browser_layout = section_panel('Image library')
        filter_row = QHBoxLayout()
        self.gallery_search = QLineEdit()
        self.gallery_search.setPlaceholderText('Search saved image filenames…')
        self.gallery_search.textChanged.connect(self.refresh_gallery)
        filter_row.addWidget(self.gallery_search, 1)
        filter_row.addWidget(button('Refresh', self.refresh_gallery))
        browser_layout.addLayout(filter_row)
        self.gallery_count = QLabel('Loading images…')
        self.gallery_count.setObjectName('GalleryCount')
        browser_layout.addWidget(self.gallery_count)
        self.gallery_list = QListWidget()
        self.gallery_list.setObjectName('GalleryTiles')
        self.gallery_list.setViewMode(QListView.ViewMode.IconMode)
        self.gallery_list.setResizeMode(QListView.ResizeMode.Adjust)
        self.gallery_list.setMovement(QListView.Movement.Static)
        self.gallery_list.setWrapping(True)
        self.gallery_list.setWordWrap(True)
        self.gallery_list.setSelectionMode(QListView.SelectionMode.ExtendedSelection)
        self.gallery_list.setIconSize(QSize(192, 152))
        self.gallery_list.setGridSize(QSize(220, 215))
        self.gallery_list.setSpacing(7)
        self.gallery_list.itemSelectionChanged.connect(self.gallery_preview)
        self.gallery_list.itemDoubleClicked.connect(self.open_gallery_image)
        self.gallery_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.gallery_list.customContextMenuRequested.connect(self.gallery_context_menu)
        self.gallery_delete_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Delete), self.gallery_list)
        self.gallery_delete_shortcut.setContext(Qt.ShortcutContext.WidgetShortcut)
        self.gallery_delete_shortcut.activated.connect(self.delete_selected_gallery_images)
        browser_layout.addWidget(self.gallery_list, 1)
        workspace.addWidget(browser)

        viewer, viewer_layout = section_panel('Image preview')
        self.gallery_picture = AspectFitPreview('Select a thumbnail to preview your image.')
        viewer_layout.addWidget(self.gallery_picture, 1)
        self.gallery_metadata = QLabel('Filename and dimensions will appear here.')
        self.gallery_metadata.setObjectName('GalleryMeta')
        self.gallery_metadata.setWordWrap(True)
        self.gallery_metadata.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        viewer_layout.addWidget(self.gallery_metadata)
        action_row = QHBoxLayout()
        action_row.addWidget(button('Open original', self.open_gallery_image, True))
        action_row.addWidget(button('Save a copy…', self.save_gallery_copy))
        self.gallery_delete_button = button('Delete permanently', self.delete_selected_gallery_images)
        self.gallery_delete_button.setToolTip('Remove selected original image files from this computer (not the Trash).')
        action_row.addWidget(self.gallery_delete_button)
        viewer_layout.addLayout(action_row)
        workspace.addWidget(viewer)
        workspace.setSizes([790, 500])
        body.addWidget(workspace, 1)
        self.register_page('gallery', root)

    def refresh_gallery(self, *_):
        folder = DATA_DIR / 'images'
        previous = self.gallery_file() if hasattr(self, 'gallery_list') else None
        search = self.gallery_search.text() if hasattr(self, 'gallery_search') else ''
        paths = image_files(folder, search)
        self.gallery_list.blockSignals(True)
        self.gallery_list.clear()
        selected_item = None
        for index, path in enumerate(paths):
            reader = QImageReader(str(path))
            reader.setAutoTransform(True)
            raw_size = reader.size()
            if raw_size.isValid():
                w, h = fit_image_size(raw_size.width(), raw_size.height(), 192, 152)
                reader.setScaledSize(QSize(w, h))
            image = reader.read()
            icon = QIcon(QPixmap.fromImage(image)) if not image.isNull() else QIcon()
            dimensions = (f'{raw_size.width()} × {raw_size.height()}'
                          if raw_size.isValid() else 'Unknown dimensions')
            item = QListWidgetItem(icon, f'Image {index + 1}\n{dimensions}')
            item.setData(Qt.ItemDataRole.UserRole, str(path))
            item.setToolTip(f'{path.name}\n{dimensions}')
            self.gallery_list.addItem(item)
            if previous is not None and path == previous:
                selected_item = item
        self.gallery_count.setText(f'{len(paths):,} image' + ('' if len(paths) == 1 else 's')
                                   + (' matching search' if search.strip() else ' saved locally'))
        if selected_item is not None:
            self.gallery_list.setCurrentItem(selected_item)
        elif self.gallery_list.count():
            self.gallery_list.setCurrentRow(0)
        self.gallery_list.blockSignals(False)
        self.gallery_preview()

    def gallery_file(self):
        item = self.gallery_list.currentItem()
        return Path(item.data(Qt.ItemDataRole.UserRole)) if item else None

    def gallery_preview(self):
        self.gallery_delete_button.setEnabled(bool(self.gallery_list.selectedItems()))
        selected = self.gallery_file()
        if not selected or not selected.is_file():
            self.gallery_picture.set_image(None)
            self.gallery_metadata.setText('Select an image from the library.')
            self.gallery_delete_button.setEnabled(bool(self.gallery_list.selectedItems()))
            return
        reader = QImageReader(str(selected))
        reader.setAutoTransform(True)
        natural = reader.size()
        if natural.isValid():
            w, h = fit_image_size(natural.width(), natural.height(), 2000, 2000)
            reader.setScaledSize(QSize(w, h))
        decoded = reader.read()
        self.gallery_picture.set_image(QPixmap.fromImage(decoded) if not decoded.isNull() else None)
        try:
            size_mb = selected.stat().st_size / (1024 * 1024)
            dimensions = (f'{natural.width()} × {natural.height()}'
                          if natural.isValid() else 'Size unknown')
            self.gallery_metadata.setText(f'{selected.name}\n{dimensions}  ·  {size_mb:.2f} MiB')
        except OSError:
            self.gallery_metadata.setText(selected.name)

    def open_gallery_image(self, *_):
        file = self.gallery_file()
        if file: QDesktopServices.openUrl(QUrl.fromLocalFile(str(file.resolve())))

    def save_gallery_copy(self):
        file = self.gallery_file()
        if not file: return
        target, _ = QFileDialog.getSaveFileName(self, 'Save image as', file.name, 'Images (*.png *.jpg *.webp)')
        if target:
            try: shutil.copy2(file, target); self.status('Image copied')
            except OSError as exc: self.error(exc)


    def gallery_context_menu(self, point):
        item = self.gallery_list.itemAt(point)
        if item is None:
            return
        if not item.isSelected():
            self.gallery_list.setCurrentItem(item)
        menu = QMenu(self.gallery_list)
        menu.addAction('Open original', self.open_gallery_image)
        menu.addAction('Save a copy…', self.save_gallery_copy)
        menu.addSeparator()
        menu.addAction('Delete permanently', self.delete_selected_gallery_images)
        menu.exec(self.gallery_list.viewport().mapToGlobal(point))

    def delete_selected_gallery_images(self):
        """Permanently remove selected managed files and linked chat image rows."""
        selected = self.gallery_list.selectedItems()
        if not selected:
            return
        files = list(dict.fromkeys(Path(item.data(Qt.ItemDataRole.UserRole)) for item in selected))
        amount = len(files)
        noun = 'image' if amount == 1 else 'images'
        answer = QMessageBox.warning(
            self, 'Permanently delete gallery images?',
            f'Permanently delete {amount} selected {noun} from this computer?\n\n'
            'The original IMGenius gallery files will be deleted (not moved to Trash). '
            'Their chat-image attachments will be removed too.\n\n'
            'This cannot be undone. Copies saved elsewhere are not affected.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        active_image_names = set()
        if self.active_chat is not None:
            active_image_names = {entry['filename'] for entry in self.chats.get_chat_images(self.active_chat)}
        deleted = []
        errors = []
        for image in files:
            try:
                delete_managed_gallery_image(image, DATA_DIR / 'images', self.chats)
                deleted.append(image)
            except (OSError, ValueError) as exc:
                errors.append(f'{image.name}: {exc}')
        if deleted:
            deleted_set = set(deleted)
            self.image_paths = [path for path in self.image_paths if Path(path) not in deleted_set]
            if self.current_preview_path and Path(self.current_preview_path) in deleted_set:
                self._show_preview(None)
            self.refresh_gallery()
            self.refresh_image_browser()
            if any(path.name in active_image_names for path in deleted):
                self.refresh_chat_messages()
            self.status(f'{len(deleted)} gallery {"image" if len(deleted)==1 else "images"} permanently deleted.')
        if errors:
            QMessageBox.warning(self, 'Some images could not be deleted', '\n'.join(errors))
