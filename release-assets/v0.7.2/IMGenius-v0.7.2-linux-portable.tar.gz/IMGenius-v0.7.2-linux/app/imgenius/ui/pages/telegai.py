"""Chub character cards embedded in IMGenius's Characters page.

This is a native Qt grid rather than a QWebEngine browser. No site HTML is
executed. Network access begins only after the user enables Chub view.
"""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QDesktopServices, QIntValidator, QPixmap
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QSizePolicy, QVBoxLayout, QWidget, QMessageBox,
)

from imgenius.characters.grid_layout import character_grid_metrics
from imgenius.characters.chub import (
    ChubImportError, character_from_url, pull_public_character, browse_chub_characters,
)
from imgenius.characters.telegai_feed import browse_telegai_feed
from imgenius.characters.catalog_service import CatalogClient, browse_catalog_characters
from imgenius.ui.widgets.characters import CharacterCover
from imgenius.ui.widgets.controls import NoWheelComboBox, button, section_label


class OnlineCharacterCard(QFrame):
    """Same cover proportions as a saved Character Library tile."""

    def __init__(self, record, import_callback, parent=None):
        super().__init__(parent)
        self.record = record
        self.setObjectName('CharacterTile')
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)
        name = QLabel(record['name'])
        name.setObjectName('CharacterTitle')
        name.setTextFormat(Qt.TextFormat.PlainText)
        name.setWordWrap(True)
        layout.addWidget(name)
        avatar = QPixmap()
        data = record.get('image_bytes')
        if data and isinstance(data, bytes):
            avatar.loadFromData(data)
        self.cover = CharacterCover(avatar, record.get('description') or 'Online character', self)
        self.cover.clicked.connect(lambda: import_callback(record['source_url']))
        layout.addWidget(self.cover)
        rating = record.get('content_rating', 'Unrated')
        meta = QLabel('Chub  ·  ' + rating + '  ·  ' + (', '.join(record.get('tags', [])[:2]) or 'Character'))
        meta.setObjectName('CharacterCaption')
        meta.setTextFormat(Qt.TextFormat.PlainText)
        meta.setWordWrap(True)
        layout.addWidget(meta)
        # Wide global button padding cannot fit both labels within the narrow
        # discovery cards. Full-width rows remain readable at every card width.
        actions = QVBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.setSpacing(6)
        import_button = button('Import card', lambda: import_callback(record['source_url']), True)
        visit_button = button('View on Chub ↗', lambda: QDesktopServices.openUrl(QUrl(record['source_url'])))
        for action in (import_button, visit_button):
            action.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            actions.addWidget(action)
        layout.addLayout(actions)

    def set_card_width(self, width):
        width = max(190, int(width))
        self.setFixedWidth(width)
        self.cover.set_card_width(width - 20)
        self.updateGeometry()


class TelegAIDiscoveryMixin:
    """Online discovery is a toggle-controlled subpanel of Characters."""

    def _build_telegai_panel(self, parent_layout):
        self.telegai_panel = QWidget()
        content = QVBoxLayout(self.telegai_panel)
        content.setContentsMargins(0, 10, 0, 0)
        content.setSpacing(13)
        content.addWidget(section_label(
            'Browse Chub character cards. Import to edit; nothing is saved automatically.'
        ))
        # Site-wide search is separate from the finite recommendations feed.
        source_row = QHBoxLayout()
        source_row.addWidget(QLabel('Browse'))
        self.telegai_source = NoWheelComboBox()
        self.telegai_source.addItems(['Full catalog', 'For you feed'])
        self.telegai_source.setToolTip(
            'Full catalog uses 80-card batches from the public catalog. For You shows recommendations.'
        )
        self.telegai_source.currentIndexChanged.connect(self._telegai_change_source)
        source_row.addWidget(self.telegai_source)
        source_row.addWidget(QLabel('Sort'))
        self.telegai_sort = NoWheelComboBox()
        self.telegai_sort.addItems(['Newest', 'Popular', 'Recently updated'])
        self.telegai_sort.currentIndexChanged.connect(self._telegai_search)
        source_row.addWidget(self.telegai_sort)
        self.telegai_mature = button('Include mature: Off', self._telegai_toggle_mature)
        self.telegai_mature.setCheckable(True)
        self.telegai_mature.setObjectName('ContentFilter')
        self.telegai_mature.setToolTip('Request mature-inclusive listings where available')
        source_row.addWidget(self.telegai_mature)
        source_row.addStretch(1)
        site_button = button('Chub site ↗', lambda: QDesktopServices.openUrl(QUrl('https://chub.ai/')))
        site_button.setToolTip('Open Chub to browse character listings and content settings')
        source_row.addWidget(site_button)
        content.addLayout(source_row)

        toolbar = QHBoxLayout()
        self.telegai_search = QLineEdit()
        self.telegai_search.setPlaceholderText('Search Chub by name or description (indexed search)…')
        self.telegai_search.returnPressed.connect(self._telegai_search)
        self.telegai_search.textChanged.connect(self._telegai_update_filter_availability)
        self.telegai_search.setToolTip('Full-text searches use Chub’s search index; empty text browses the public catalog feed')
        toolbar.addWidget(self.telegai_search, 2)
        self.telegai_tags = QLineEdit()
        self.telegai_tags.setPlaceholderText('Search tags (e.g. Fantasy, Elf)…')
        self.telegai_tags.setToolTip('Filter the public catalog by tags; separate multiple tags with commas')
        self.telegai_tags.returnPressed.connect(self._telegai_search)
        toolbar.addWidget(self.telegai_tags, 1)
        toolbar.addWidget(button('Search catalog', self._telegai_search, True))
        toolbar.addWidget(button('Clear', self._telegai_clear_filters))
        toolbar.addWidget(button('Refresh', self._telegai_refresh))
        content.addLayout(toolbar)
        advanced = QHBoxLayout()
        advanced.addWidget(QLabel('Exclude tags'))
        self.telegai_exclude_tags = QLineEdit()
        self.telegai_exclude_tags.setPlaceholderText('Tags to exclude (comma separated)…')
        self.telegai_exclude_tags.returnPressed.connect(self._telegai_search)
        advanced.addWidget(self.telegai_exclude_tags, 2)
        advanced.addWidget(QLabel('Match tags'))
        self.telegai_tag_match = NoWheelComboBox()
        self.telegai_tag_match.addItems(['Any', 'All'])
        self.telegai_tag_match.currentIndexChanged.connect(self._telegai_search)
        advanced.addWidget(self.telegai_tag_match)
        advanced.addStretch(1)
        content.addLayout(advanced)
        self.telegai_source_info = QLabel(
            'Full catalog: 80-card server batches, 12 cards per page, and filters sent to '
            'the catalog service. Text search uses the separate Chub search index. '
            'For You: limited recommendations.'
        )
        self.telegai_source_info.setObjectName('HelperText')
        self.telegai_source_info.setWordWrap(True)
        content.addWidget(self.telegai_source_info)

        url_row = QHBoxLayout()
        self.telegai_url = QLineEdit()
        self.telegai_url.setPlaceholderText('Paste a Chub character URL for direct import…')
        self.telegai_url.returnPressed.connect(self._telegai_import_url)
        url_row.addWidget(self.telegai_url, 1)
        url_row.addWidget(button('Import URL', self._telegai_import_url))
        content.addLayout(url_row)

        self.telegai_message = QLabel('Switch to Chub to load public character cards.')
        self.telegai_message.setObjectName('HelperText')
        self.telegai_message.setWordWrap(True)
        content.addWidget(self.telegai_message)

        self.telegai_grid_host = QWidget()
        self.telegai_grid = QGridLayout(self.telegai_grid_host)
        self.telegai_grid.setSpacing(14)
        self.telegai_grid.setContentsMargins(0, 0, 0, 0)
        self.telegai_grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        content.addWidget(self.telegai_grid_host)

        pagination = QHBoxLayout()
        pagination.addStretch(1)
        self.telegai_prev = button('←', lambda: self._telegai_change_page(-1))
        pagination.addWidget(self.telegai_prev)
        pagination.addWidget(QLabel('Page'))
        self.telegai_page_number = QLineEdit('1')
        self.telegai_page_number.setFixedWidth(64)
        self.telegai_page_number.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.telegai_page_number.setValidator(QIntValidator(1, 10000, self.telegai_page_number))
        self.telegai_page_number.returnPressed.connect(self._telegai_jump_page)
        pagination.addWidget(self.telegai_page_number)
        self.telegai_next = button('→', lambda: self._telegai_change_page(1))
        pagination.addWidget(self.telegai_next)
        pagination.addStretch(1)
        content.addLayout(pagination)
        content.addStretch(1)
        self.telegai_panel.setVisible(False)
        parent_layout.addWidget(self.telegai_panel)
        self._catalog_client = CatalogClient()
        self._telegai_page = 1
        self._telegai_has_next = False
        self._telegai_records = []
        self._telegai_tiles = []
        self._telegai_layout_key = None
        self._telegai_busy = False
        self._telegai_generation = 0
        self._telegai_loaded = False
        self._telegai_age_confirmed = False  # session-only local consent; not a TelegAI login
        self._telegai_update_pagination()

    def _telegai_update_filter_availability(self, *_):
        catalog = self.telegai_source.currentIndex() == 0
        indexed_text_search = bool(self.telegai_search.text().strip())
        self.telegai_search.setEnabled(catalog)
        self.telegai_tags.setEnabled(catalog)
        self.telegai_exclude_tags.setEnabled(catalog and not indexed_text_search)
        self.telegai_tag_match.setEnabled(catalog and not indexed_text_search)
        self.telegai_sort.setEnabled(catalog)
        hint = ('Exclude tags and Any/All matching require an empty text search; '
                'indexed Chub text search does not expose these filters.')
        self.telegai_exclude_tags.setToolTip(hint)
        self.telegai_tag_match.setToolTip(hint)

    def _telegai_change_source(self, *_):
        catalog = self.telegai_source.currentIndex() == 0
        self._telegai_update_filter_availability()
        self.telegai_source_info.setText(
            'Full catalog: Chub cards served in batches of 80; the page controls show '
            '12 at a time and cache neighboring pages. Tag and exclude-tag filters '
            'go to the catalog service. Text search uses the separate Chub index '
            '(whose mature coverage may differ).' if catalog else
            'For You: recommended characters from a limited feed. '
            'Switch to Full catalog for deeper paginated browsing and tag filters.'
        )
        self._telegai_search()

    def _telegai_refresh(self):
        # Intentionally bypass the five-minute catalog cache on demand.
        self._catalog_client.clear()
        self._telegai_fetch()

    def _telegai_clear_filters(self):
        self.telegai_search.clear()
        self.telegai_tags.clear()
        self.telegai_exclude_tags.clear()
        self.telegai_tag_match.setCurrentIndex(0)
        if self.telegai_source.currentIndex() != 0:
            self.telegai_source.setCurrentIndex(0)  # triggers the search
        else:
            self._telegai_search()

    def _telegai_toggle_mature(self, checked):
        enabled = self.telegai_mature.isChecked()
        if enabled and not self._telegai_age_confirmed:
            dialog = QMessageBox(self.telegai_panel)
            dialog.setWindowTitle('Chub mature content')
            dialog.setIcon(QMessageBox.Icon.Question)
            dialog.setText('Are you 18 years of age or older?')
            dialog.setInformativeText(
                'Mature content is optional. Confirming here only enables IMGenius to request '
                'mature-tagged Chub cards. The hosting service may separately require website '
                'verification or restrict access; this does not override its rules.'
            )
            confirm = dialog.addButton('I am 18 or older', QMessageBox.ButtonRole.AcceptRole)
            dialog.addButton('Cancel', QMessageBox.ButtonRole.RejectRole)
            dialog.exec()
            if dialog.clickedButton() != confirm:
                self.telegai_mature.setChecked(False)
                self.telegai_message.setText('Mature browsing stays off. Public SFW-filtered results only.')
                return
            self._telegai_age_confirmed = True
        self.telegai_mature.setText('Include mature: On' if enabled else 'Include mature: Off')
        self.telegai_mature.setToolTip('Request mature-inclusive Chub listings' if enabled else 'Request the general Chub catalog')
        self._telegai_search()

    def _telegai_search(self, *_):
        self._telegai_page = 1
        self._telegai_fetch()

    def _telegai_change_page(self, delta):
        page = max(1, self._telegai_page + delta)
        if delta > 0 and not self._telegai_has_next:
            return
        if page != self._telegai_page:
            self._telegai_page = page
            self._telegai_fetch()

    def _telegai_jump_page(self):
        try:
            requested = max(1, min(10000, int(self.telegai_page_number.text())))
        except ValueError:
            requested = self._telegai_page
        if requested != self._telegai_page:
            self._telegai_page = requested
            self._telegai_fetch()

    def _telegai_update_pagination(self):
        self.telegai_page_number.setText(str(self._telegai_page))
        self.telegai_prev.setEnabled(not self._telegai_busy and self._telegai_page > 1)
        self.telegai_next.setEnabled(not self._telegai_busy and self._telegai_has_next)

    def _telegai_fetch(self):
        if not self.character_online_mode:
            return
        if self._telegai_busy:
            # Invalidate stale results and finish the current job first.
            self._telegai_generation += 1
            self._telegai_message_pending = True
            return
        self._telegai_busy = True
        self._telegai_message_pending = False
        self._telegai_generation += 1
        generation = self._telegai_generation
        catalog = self.telegai_source.currentIndex() == 0
        query = self.telegai_search.text().strip() if catalog else ''
        tags = self.telegai_tags.text().strip() if catalog else ''
        exclude_tags = self.telegai_exclude_tags.text().strip() if catalog else ''
        tag_match = self.telegai_tag_match.currentText() if catalog else 'Any'
        page = self._telegai_page
        sort = self.telegai_sort.currentText()
        mature = self.telegai_mature.isChecked()
        area = ('Chub indexed text search' if query else 'Chub catalog') if catalog else 'Chub recommendations'
        self.telegai_message.setText(f'Loading {area} (page {page})…')
        self._telegai_update_pagination()

        def task(cancel, token, status):
            if catalog and query:
                # The observed catalog service has no verified text-search key.
                # Retain site-wide text queries via Chub's search index rather
                # than pretending to filter an 80-card batch globally.
                return browse_chub_characters(query=query, tags=tags, page=page,
                                              sort=sort, mature=mature, cancelled=cancel)
            if catalog:
                return browse_catalog_characters(page=page, tags=tags,
                    exclude_tags=exclude_tags, tag_match=tag_match, sort=sort,
                    mature=mature, client=self._catalog_client, cancelled=cancel)
            return browse_telegai_feed(query='', page=page, sort='For you',
                                       mature=mature, cancelled=cancel)
        def complete(entries):
            self._telegai_busy = False
            if self._telegai_message_pending:
                self._telegai_fetch()
                return
            if generation != self._telegai_generation or not self.character_online_mode:
                return
            records, has_next = entries
            self._telegai_records = records
            self._telegai_has_next = has_next
            self._telegai_loaded = True
            self._telegai_draw_cards()
            rated = sum(bool(record.get('mature')) for record in records)
            feed_type = 'NSFW-inclusive' if mature else 'SFW'
            source_label = ('indexed text search' if query else 'catalog') if catalog else 'recommendation feed'
            if not records:
                summary = (f'No Chub {feed_type} {source_label} matches on page {page}. '
                           'Try removing filters or visiting an earlier page.'
                           if catalog else
                           f'No Chub recommendations on page {page}. '
                           'This limited feed may have reached its end.')
            else:
                summary = (f'{len(records)} Chub {source_label} cards on page {page} '
                           f'({rated} tagged Mature). '
                           'Click a portrait or Import card to edit its full Chub card.')
            if catalog and query:
                summary += (' Text search uses Chub’s index, not the 80-card catalog feed. '
                            'The exclude-tag and Any/All controls apply only to catalog browsing '
                            'with an empty text-search field.')
            elif catalog and records:
                summary += ' Navigate Next to browse the next 12 cards; 80-card batches are cached.'
            if mature and records and not rated:
                summary += ' No Mature-tagged cards were returned by this request.'
            self.telegai_message.setText(summary)
            self._telegai_update_pagination()
        def fail(message):
            self._telegai_busy = False
            if self._telegai_message_pending:
                self._telegai_fetch()
                return
            if not self.character_online_mode:
                return
            self.telegai_message.setText('Unable to load public characters: ' + message + (' The hosting service may require website verification; the IMGenius prompt is not account authentication.' if mature else ''))
            self._telegai_update_pagination()
        self.run_job(task, on_done=complete, on_error=fail)

    def _telegai_draw_cards(self):
        while self.telegai_grid.count():
            item = self.telegai_grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._telegai_tiles = [OnlineCharacterCard(item, self._telegai_import_card, self.telegai_grid_host)
                               for item in self._telegai_records]
        self._telegai_layout_key = None
        self._telegai_reflow()

    def _telegai_reflow(self):
        if not self.character_online_mode or not self._telegai_tiles:
            return
        width = self.characters_scroller.viewport().width()
        if width < 200:
            return
        cols, tile_width = character_grid_metrics(width, len(self._telegai_tiles))
        key = (width, len(self._telegai_tiles), cols, tile_width)
        if key == self._telegai_layout_key:
            return
        self._telegai_layout_key = key
        for tile in self._telegai_tiles:
            self.telegai_grid.removeWidget(tile)
        for i, tile in enumerate(self._telegai_tiles):
            tile.set_card_width(tile_width)
            self.telegai_grid.addWidget(tile, i // cols, i % cols,
                                        Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)
        self.telegai_grid_host.updateGeometry()

    def _telegai_import_url(self):
        self._telegai_import_card(self.telegai_url.text().strip())

    def _telegai_import_card(self, url):
        try:
            character_from_url(url)
        except ChubImportError as exc:
            self.error(str(exc))
            return
        self.telegai_message.setText('Downloading full public character card…')
        def task(cancel, token, status):
            return pull_public_character(url, cancelled=cancel, status=status)
        def complete(card):
            self._apply_imported_card(card)  # opens Character Editor unsaved
            self.status(f"Imported {card['name']} as an unsaved draft.")
        def fail(message):
            self.telegai_message.setText('Import unavailable: ' + message)
        self.run_job(task, on_done=complete, on_status=self.telegai_message.setText, on_error=fail)
