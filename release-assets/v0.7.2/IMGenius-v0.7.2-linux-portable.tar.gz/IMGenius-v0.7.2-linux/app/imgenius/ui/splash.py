"""A lightweight, animated startup splash built with the app's existing Qt dependency."""
from __future__ import annotations

from math import cos, sin, pi

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen, QPixmap, QRadialGradient
from PySide6.QtWidgets import QWidget

from imgenius.ui.brand_assets import app_icon_path


class StartupSplash(QWidget):
    """Nonblocking startup feedback; animation is timer-driven, not an artificial delay."""

    def __init__(self):
        super().__init__(None, Qt.WindowType.SplashScreen | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(510, 305)
        self._phase = 0.0
        self._status = 'Starting IMGenius...'
        self._icon = QPixmap(str(app_icon_path()))
        self._timer = QTimer(self)
        self._timer.setInterval(32)
        self._timer.timeout.connect(self._tick)
        self._fade = None

    def show_animated(self):
        self.setWindowOpacity(1.0)
        self.show()
        self._timer.start()

    def set_status(self, status):
        self._status = str(status)
        self.update()

    def _tick(self):
        self._phase = (self._phase + 0.045) % (2 * pi)
        self.update()

    def finish(self):
        """Reveal the already-visible main window without holding up launch."""
        self._timer.stop()
        self._fade = QPropertyAnimation(self, b'windowOpacity', self)
        self._fade.setDuration(220)
        self._fade.setStartValue(self.windowOpacity())
        self._fade.setEndValue(0.0)
        self._fade.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade.finished.connect(self.close)
        self._fade.start()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        card = QRectF(5, 5, 500, 295)
        bg = QLinearGradient(0, 0, 510, 305)
        bg.setColorAt(0, QColor('#171d33'))
        bg.setColorAt(0.55, QColor('#11182a'))
        bg.setColorAt(1, QColor('#211536'))
        p.setPen(QPen(QColor(118, 105, 205, 145), 1.5))
        p.setBrush(bg)
        p.drawRoundedRect(card, 24, 24)

        halo = QRadialGradient(255, 65, 145)
        halo.setColorAt(0.0, QColor(122, 84, 246, 45))
        halo.setColorAt(1.0, QColor(122, 84, 246, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(halo)
        p.drawRoundedRect(card.adjusted(2, 2, -2, -2), 22, 22)

        if not self._icon.isNull():
            icon = self._icon.scaled(76, 76, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(int((510 - icon.width()) / 2), 30, icon)

        title = QFont(self.font())
        title.setPixelSize(31)
        title.setWeight(QFont.Weight.DemiBold)
        p.setFont(title)
        p.setPen(QColor('#f4f2ff'))
        p.drawText(QRectF(0, 112, 510, 46), Qt.AlignmentFlag.AlignCenter, 'IMGenius')

        subtitle = QFont(self.font())
        subtitle.setPixelSize(11)
        subtitle.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 3)
        p.setFont(subtitle)
        p.setPen(QColor('#aaaac7'))
        p.drawText(QRectF(0, 156, 510, 20), Qt.AlignmentFlag.AlignCenter, 'LOCAL AI STUDIO')

        # Orbiting highlights show progress even when startup has no countable tasks.
        cx, cy, radius = 255.0, 211.0, 13.0
        for i in range(8):
            angle = self._phase - 2 * pi * i / 8
            intensity = 225 - 20 * i
            color = QColor(92 + 8 * i, 192 - 8 * i, 255, intensity)
            p.setBrush(color)
            x = cx + radius * cos(angle)
            y = cy + radius * sin(angle)
            size = 2.8 if i < 3 else 2.2
            p.drawEllipse(QRectF(x - size, y - size, size * 2, size * 2))

        status_font = QFont(self.font())
        status_font.setPixelSize(12)
        p.setFont(status_font)
        p.setPen(QColor('#c4c9df'))
        p.drawText(QRectF(24, 239, 462, 28), Qt.AlignmentFlag.AlignCenter, self._status)

        # Indeterminate progress: sweep a narrow luminous segment over a quiet track.
        track = QRectF(67, 279, 376, 4)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor('#303752'))
        p.drawRoundedRect(track, 2, 2)
        sweep = (sin(self._phase * 0.75) + 1) / 2
        x = 67 + 316 * sweep
        band = QLinearGradient(x, 279, x + 60, 279)
        band.setColorAt(0, QColor('#956cff'))
        band.setColorAt(1, QColor('#49d9f6'))
        p.setBrush(band)
        p.drawRoundedRect(QRectF(x, 279, 60, 4), 2, 2)
        p.end()
