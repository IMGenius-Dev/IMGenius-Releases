"""IMGenius native Qt window and navigation controller.

Feature page implementations live in ui/pages; reusable controls in ui/widgets.
"""
from __future__ import annotations

from PySide6.QtCore import QEvent
from PySide6.QtCore import QSettings
from PySide6.QtCore import QSize
from PySide6.QtCore import QThreadPool
from PySide6.QtCore import QTimer
from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QApplication
from PySide6.QtWidgets import QMainWindow
from PySide6.QtWidgets import QFrame
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QMessageBox
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QStackedWidget
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius import __version__
from imgenius.domain import CharacterStore
from imgenius.domain import ChatStore
from imgenius.domain import PersonaStore
from imgenius.domain import StoryStore
from imgenius.ui.brand_assets import app_icon_path
from imgenius.ui.brand_assets import sidebar_icon_path
from imgenius.ui.widgets.workers import Worker

from imgenius.ui.pages.characters import CharacterLibraryPageMixin
from imgenius.ui.pages.editor import CharacterEditorPageMixin
from imgenius.ui.pages.telegai import TelegAIDiscoveryMixin
from imgenius.ui.pages.chats import ChatsPageMixin
from imgenius.ui.pages.images import ImageStudioPageMixin
from imgenius.ui.pages.gallery import GalleryPageMixin
from imgenius.ui.pages.stories import StoriesPageMixin
from imgenius.ui.pages.models import ModelsPageMixin
from imgenius.ui.pages.settings import SettingsPageMixin

class MainWindow(TelegAIDiscoveryMixin, CharacterLibraryPageMixin, CharacterEditorPageMixin, ChatsPageMixin, ImageStudioPageMixin, GalleryPageMixin, StoriesPageMixin, ModelsPageMixin, SettingsPageMixin, QMainWindow):
    NAV = [
        ('CHARACTERS', None), ('Characters', 'characters'),
        ('Chats', 'chats'), ('IMAGES', None), ('Create image', 'images'),
        ('My images', 'gallery'), ('STORIES', None), ('My stories', 'stories'),
        ('Write story', 'story_editor'), ('SYSTEM', None), ('Models', 'models'),
        ('Settings', 'settings')
    ]
    def __init__(self):
        super().__init__()
        self.setWindowTitle('IMGenius')
        self.setWindowIcon(QIcon(str(app_icon_path())))
        self.resize(1320, 850)
        self.setMinimumSize(920, 620)
        self.settings = QSettings('IMGenius', 'IMGenius')
        self.characters = CharacterStore()
        self.chats = ChatStore()
        self.stories = StoryStore()
        self.personas = PersonaStore()
        self.pool = QThreadPool.globalInstance()
        self.jobs = []
        self.active_character = None
        self.active_chat = None
        self.active_story = None
        self.current_chat_worker = None
        self.current_chat_image_worker = None
        self.current_image_worker = None
        self.current_avatar_worker = None
        self.image_paths = []
        self.lora_rows = []
        self.comfy_info = {}
        self.character_page = 1
        self._character_filter_signature = None
        self._character_filtered_count = 0
        self.pages = {}
        self.chat_context_notes = {}
        self.nav_buttons = {}
        self.selected_character_ids = set()
        self.active_tag_filters = set()
        self.character_tags_expanded = str(self.settings.value('character_tags_expanded', 'false')).lower() in ('1', 'true', 'yes')
        self.character_card_widgets = []
        self._character_grid_columns = 0
        self._character_grid_layout_key = None
        self._character_grid_reflow_scheduled = False
        self._make_shell()
        self._make_character_list()
        self._make_character_editor()
        self._make_chats()
        self._make_images()
        self._make_gallery()
        self._make_stories()
        self._make_story_editor()
        self._make_models()
        self._make_settings()
        self._load_settings()
        self.refresh_characters()
        self.refresh_chat_list()
        self.refresh_stories()
        self.refresh_gallery()
        self.navigate('characters')

    def _make_shell(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setSpacing(0)
        root.setContentsMargins(0,0,0,0)
        sidebar = QFrame()
        sidebar.setObjectName('SideBar')
        sidebar.setFixedWidth(248)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 22, 16, 18)
        side.setSpacing(6)

        brand_row = QHBoxLayout()
        brand_row.setSpacing(10)
        self.brand_symbol = QLabel()
        self.brand_symbol.setObjectName('BrandSymbol')
        self.brand_symbol.setFixedSize(47, 47)
        pix = QPixmap(str(app_icon_path()))
        if not pix.isNull():
            self.brand_symbol.setPixmap(pix.scaled(47, 47, Qt.AspectRatioMode.KeepAspectRatio,
                                                   Qt.TransformationMode.SmoothTransformation))
        brand_row.addWidget(self.brand_symbol)
        brand_copy = QVBoxLayout()
        brand_copy.setContentsMargins(0, 0, 0, 0)
        brand_copy.setSpacing(1)
        brand = QLabel('IMGenius')
        brand.setObjectName('Brand')
        brand_copy.addWidget(brand)
        eyebrow = QLabel('LOCAL AI STUDIO')
        eyebrow.setObjectName('BrandEyebrow')
        brand_copy.addWidget(eyebrow)
        brand_row.addLayout(brand_copy, 1)
        side.addLayout(brand_row)
        side.addSpacing(22)
        for label, page in self.NAV:
            if page is None:
                group = QLabel(label)
                group.setObjectName('NavGroup')
                side.addSpacing(13)
                side.addWidget(group)
            else:
                nav = QPushButton(label)
                nav.setObjectName('Nav')
                nav.setProperty('active', False)
                icon_file = sidebar_icon_path(page)
                if icon_file.is_file():
                    nav.setIcon(QIcon(str(icon_file)))
                    nav.setIconSize(QSize(20, 20))
                nav.setMinimumHeight(42)
                nav.clicked.connect(lambda checked=False, p=page: self.navigate(p))
                self.nav_buttons[page] = nav
                side.addWidget(nav)
        side.addStretch(1)
        footer = QLabel(f'●  LOCAL STUDIO   ·   v{__version__}')
        footer.setObjectName('NavFooter')
        footer.setWordWrap(True)
        side.addWidget(footer)
        root.addWidget(sidebar)
        main = QWidget()
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(0,0,0,0)
        main_layout.setSpacing(0)
        top = QFrame()
        top.setObjectName('PageHeader')
        header = QHBoxLayout(top)
        header.setContentsMargins(28, 16, 28, 16)
        header.setSpacing(18)
        heading = QVBoxLayout()
        heading.setSpacing(3)
        self.header_eyebrow = QLabel('WORKSPACE  /  HOME')
        self.header_eyebrow.setObjectName('HeaderEyebrow')
        heading.addWidget(self.header_eyebrow)
        self.header_title = QLabel()
        self.header_title.setObjectName('PageTitle')
        heading.addWidget(self.header_title)
        self.header_description = QLabel('')
        self.header_description.setObjectName('HeaderDescription')
        self.header_description.setWordWrap(True)
        heading.addWidget(self.header_description)
        header.addLayout(heading, 1)
        self.status_label = QLabel('Ready')
        self.status_label.setObjectName('Status')
        self.status_label.setMaximumWidth(300)
        header.addWidget(self.status_label, 0, Qt.AlignmentFlag.AlignTop)
        main_layout.addWidget(top)
        self.stack = QStackedWidget()
        main_layout.addWidget(self.stack, 1)
        root.addWidget(main,1)

    def register_page(self, name, widget):
        self.pages[name] = widget
        self.stack.addWidget(widget)

    def navigate(self, page):
        if page not in self.pages:
            return
        self.stack.setCurrentWidget(self.pages[page])
        titles = {'characters':'Characters', 'editor':'Character editor', 'chats':'Chats',
                  'telegai':'Browse Chub', 'images':'Create image', 'gallery':'My images', 'stories':'My stories',
                  'story_editor':'Write story', 'models':'Models', 'settings':'Settings'}
        self.header_title.setText(titles[page])
        self.header_eyebrow.setText(f'IMGenius  /  {titles[page].upper()}')
        descriptions = {
            'characters': 'Browse characters and find your next conversation.',
            'editor': 'Shape a character, its first message, and its lore.',
            'telegai': 'Discover public cards and import them for local use.',
            'chats': 'Conversations with your favorite local characters.',
            'images': 'Generate, refine, and revisit your images.',
            'gallery': 'All your saved generations in one place.',
            'stories': 'Continue worlds and stories with local models.',
            'story_editor': 'A quiet workspace for your next chapter.',
            'models': 'Manage the models behind your local studio.',
            'settings': 'Personalize IMGenius and manage your local data.',
        }
        self.header_description.setText(descriptions.get(page, ''))
        for key, nav in self.nav_buttons.items():
            nav.setProperty('active', key == page or (page == 'editor' and key == 'characters') or (page == 'telegai' and key == 'characters'))
            nav.style().unpolish(nav)
            nav.style().polish(nav)
        if page == 'characters':
            if self.character_online_mode:
                self._telegai_reflow()
            else:
                self._schedule_character_grid_reflow()
        if page == 'gallery': self.refresh_gallery()
        if page == 'stories': self.refresh_stories()
        if page == 'chats' and not getattr(self, '_chat_checkpoint_requested', False):
            self._chat_checkpoint_requested = True
            # Populate the chat's scene-image checkpoint dropdown on first visit.
            # The manual Refresh button remains available after model changes.
            self.refresh_comfy_models()
        if page == 'images':
            self.refresh_comfy_models()
            self.refresh_image_browser()

    def status(self, text):
        self.status_label.setText(str(text)[:85])

    def error(self, message):
        self.status('Error')
        QMessageBox.warning(self, 'IMGenius', str(message))

    def run_job(self, func, on_done=None, on_token=None, on_status=None, on_error=None):
        job = Worker(func)
        self.jobs.append(job)
        def cleanup(*_):
            if job in self.jobs: self.jobs.remove(job)
        job.signals.finished.connect(lambda result: on_done(result) if on_done else None)
        job.signals.error.connect(on_error or self.error)
        job.signals.cancelled.connect(lambda msg: self.status(msg))
        job.signals.token.connect(on_token or (lambda _: None))
        job.signals.status.connect(on_status or self.status)
        job.signals.finished.connect(cleanup)
        job.signals.error.connect(cleanup)
        job.signals.cancelled.connect(cleanup)
        self.pool.start(job)
        return job

    def ollama_url(self):
        return self.ollama_url_field.text().strip().rstrip('/')

    def comfy_url(self):
        return self.comfy_url_field.text().strip().rstrip('/')

    def current_model(self):
        if hasattr(self, 'chat_side_model'):
            return self.chat_side_model.currentText().strip()
        return self.chat_model_field.currentText().strip()

    def llm_options(self):
        # These controls live only in the chat sidebar; Settings no longer has
        # a second copy that can silently drift out of sync.
        return {'temperature': self.chat_temperature.value(), 'top_p': self.chat_top_p.value(),
                'repeat_penalty': self.chat_repeat_penalty.value(), 'num_ctx': self.chat_context.value(),
                'num_predict': self.chat_tokens.value()}

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'chat_history'):
            self.resize_chat_bubbles()
        if hasattr(self, 'character_grid'):
            self._reflow_character_grid()
        if hasattr(self, 'image_preview'):
            self._schedule_image_preview_reflow()
        if hasattr(self, 'chat_character_image'):
            self._refresh_chat_character_image()
        if hasattr(self, 'character_editor_image'):
            self._character_editor_preview()

    def eventFilter(self, watched, event):
        # QScrollArea's viewport resizes independently of MainWindow when
        # switching pages, showing scrollbars, and changing splitter geometry.
        if (hasattr(self, 'characters_scroller') and
                watched is self.characters_scroller.viewport() and
                event.type() in (QEvent.Type.Resize, QEvent.Type.Show)):
            if self.character_online_mode:
                self._telegai_reflow()
            else:
                self._schedule_character_grid_reflow()
        if (hasattr(self, 'image_preview_panel') and
                watched is self.image_preview_panel and
                event.type() in (QEvent.Type.Resize, QEvent.Type.Show)):
            self._schedule_image_preview_reflow()
        return super().eventFilter(watched, event)

    def _schedule_character_grid_reflow(self):
        if getattr(self, '_character_grid_reflow_scheduled', False):
            return
        self._character_grid_reflow_scheduled = True
        QTimer.singleShot(0, self._deferred_character_grid_reflow)

    def _deferred_character_grid_reflow(self):
        self._character_grid_reflow_scheduled = False
        self._reflow_character_grid()

    def closeEvent(self, event):
        for job in list(self.jobs): job.cancel_event.set()
        if hasattr(self, 'image_prompt_library'):
            self._persist_image_prompts()
        self.save_settings()
        # Closing the main X owns shutdown even if another Qt preview window remains.
        controller = getattr(QApplication.instance(), '_startup', None)
        if controller is not None:
            controller.comfy_service.stop()
        super().closeEvent(event)

