"""Small, Qt-independent layout and image-browser helpers for IMGenius."""
from pathlib import Path

IMAGE_EXTENSIONS = frozenset({'.png', '.jpg', '.jpeg', '.webp'})


def fit_image_size(width, height, max_width, max_height, upscale=False):
    """Return an integer (width, height) that preserves aspect ratio."""
    width, height = int(width), int(height)
    max_width, max_height = int(max_width), int(max_height)
    if min(width, height, max_width, max_height) <= 0:
        return 0, 0
    scale = min(max_width / width, max_height / height)
    if not upscale:
        scale = min(1.0, scale)
    return max(1, round(width * scale)), max(1, round(height * scale))


def image_files(folder, query=''):
    """Return locally generated image paths, newest first; no recursive reads."""
    folder = Path(folder)
    if not folder.is_dir():
        return []
    query = str(query).casefold().strip()
    paths = (p for p in folder.iterdir()
             if p.is_file() and p.suffix.casefold() in IMAGE_EXTENSIONS
             and query in p.name.casefold())
    return sorted(paths, key=lambda path: (path.stat().st_mtime, path.name), reverse=True)
