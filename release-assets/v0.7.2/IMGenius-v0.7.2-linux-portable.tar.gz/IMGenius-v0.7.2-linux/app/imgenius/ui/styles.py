"""Shared base Qt styles for all desktop themes."""

STYLE = '''
* {font-family: "__IMG_FAMILY__"; font-size: 15px;}
/* Layout-only QWidget wrappers must not paint the global canvas color.
   They need to show the actual theme surface of their parent panel. */
QWidget { color: #e5e9f5; }
QWidget#CharacterBadges, QWidget#TagPanel, QWidget#ChatTagsPanel,
QWidget#CharacterTagsPanel, QWidget#ComposerEntryRow,
QWidget#MessageActions, QCheckBox {
    background:transparent;
    border:none;
}
QMainWindow { background:#111421; }
QLabel {background:transparent; border:none;}
QFrame#SideBar {
    background:#151929;
    border-right:1px solid #30384e;
}
QLabel#Brand { font-size:25px; font-weight:800; color:#f3f4ff; }
QLabel#BrandEyebrow { font-size:14px; font-weight:700; letter-spacing:1.2px; color:#98a3c7; }
QLabel#BrandSymbol { background:transparent; }
QLabel#NavGroup {
    font-size:14px; font-weight:700; letter-spacing:1.2px;
    color:#98a3c7; padding:10px 12px 6px 10px;
}
QLabel#NavFooter {
    font-size:14px; color:#8adfd8;
    background:#1a2031; border:1px solid #30384e;
    border-radius:12px; padding:12px 10px;
}
QPushButton {
    background:#2a3045; color:#eef2ff;
    padding:10px 14px;
    border:1px solid #46506e;
    border-radius:12px;
    text-align:center;
}
QPushButton:hover { background:#363f5d; border-color:#78bff1; }
QPushButton:pressed { background:#424b70; }
QPushButton:disabled { color:#72798c; background:#242735; border-color:#34384a; }
QPushButton#Primary {
    background:#27779a; color:white; font-weight:700; border-color:#45add9;
}
QPushButton#Primary:hover { background:#338faf; }
QPushButton#ContentFilter:checked { background:#25547a; border-color:#69c4ff; font-weight:700; }
QPushButton#UseGeneratedAvatar:checked { background:#25547a; border:1px solid #69c4ff; font-weight:700; }
QPushButton#Nav {
    background:transparent; text-align:left; border:1px solid transparent;
    border-radius:14px; padding:12px 14px; font-size:14px; font-weight:600;
}
QPushButton#Nav:hover { background:#29314a; border-color:#36415c; }
QPushButton#Nav[active="true"] {
    background:#2c3456; border:1px solid #47516c; color:#eef2ff; font-weight:750;
}
QFrame#PageHeader {
    background:#151929;
    border-bottom:1px solid #30384e;
}
QLabel#HeaderEyebrow {
    font-size:14px; letter-spacing:1px; color:#a6adc3; font-weight:700;
}
QLabel#PageTitle { font-size:24px; font-weight:750; color:#f3f4ff; }
QLabel#HeaderDescription { font-size:14px; color:#a6adc3; }
QLabel#Status {
    color:#8adfd8; font-size:14px;
    padding:6px 10px;
    background:#1a2031; border:1px solid #35405a; border-radius:9px;
}
QScrollArea#PageScroll, QScrollArea#ChatControlScroll {
    background:#111421; border:0;
}
QWidget#PageBody { background:#111421; }
QGroupBox, QFrame#Card, QFrame#SectionPanel {
    background:#1a2031;
    border:1px solid #30384e;
    border-radius:17px;
}
QGroupBox { margin-top:0px; padding:10px; }
QGroupBox::title { background:transparent; border:none; padding:0; }
QLabel#SectionHeading {
    color:#f3f4ff;
    font-size:17px;
    font-weight:750;
    background:transparent;
    border:none;
    padding:1px 0 5px 0;
}
QFrame#SectionDivider {
    background:#35405a;
    border:none;
    min-height:1px;
    max-height:1px;
}
QLabel#Muted, QLabel#HelperText {
    color:#a6adc3;
    font-size:14px;
}
QLabel#Hint {
    color:#98a3c7;
    font-size:14px;
}
QLabel#LibrarySection {
    font-size:16px; font-weight:700; color:#edf2ff;
}
QLabel#FieldLabel {
    color:#d5e3fa;
    font-size:14px;
    font-weight:700;
}
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QListWidget {
    background:#111625;
    color:#ebedff;
    border:1px solid #3c4761;
    border-radius:13px;
    padding:9px 10px;
    selection-background-color:#415b97;
}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus,
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {
    border-color:#68bce8;
}
QComboBox::drop-down, QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
    background:transparent; border:none; width:22px;
}
QListWidget#ConversationList, QListWidget#ChatHistory {
    background:transparent; border:none; outline:none; padding:2px;
}
QListWidget#ConversationList::item, QListWidget#ChatHistory::item {
    padding:0px; background:transparent; border:none;
}
QListWidget::item { border-radius:8px; }
QListWidget::item:selected { background:#33476b; }
QScrollBar:vertical {
    background:#151929; width:12px; margin:4px 0 4px 0; border-radius:6px;
}
QScrollBar::handle:vertical {
    background:#464f6a; border-radius:6px; min-height:24px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical,
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {
    background:none; border:none;
}
QScrollBar:horizontal {
    background:#151929; height:12px; margin:0 4px 0 4px; border-radius:6px;
}
QScrollBar::handle:horizontal {
    background:#464f6a; border-radius:6px; min-width:24px;
}
QToolTip {
    color:white; background:#1a2031; border:1px solid #30384e;
}
QFrame#ConversationRow {
    background:transparent; border:1px solid transparent; border-radius:14px;
}
QFrame#ConversationRow[active="true"] {
    background:#202b43; border:1px solid #47516c;
}
QFrame#ConversationRow:hover {
    background:#25334c; border:1px solid #36415c;
}
QLabel#ConversationAvatar { background:transparent; border:0; }
QLabel#ConversationName { font-size:14px; font-weight:700; color:#f2f6ff; }
QLabel#ConversationPreview { font-size:14px; color:#b1bfda; }
QLabel#ConversationMeta { font-size:14px; color:#99aac8; }
QPushButton#ChatRowDelete {
    background:transparent; border:1px solid transparent; border-radius:8px; padding:0; color:#b7cbe8;
}
QPushButton#ChatRowDelete:hover {
    background:#344664; border-color:#566b8f; color:#f1f8ff;
}
QFrame#ChatBubbleUser {
    background:#2d4f80; border:1px solid #4f76a7; border-radius:18px;
}
QFrame#ChatBubbleAssistant {
    background:#1d2435; border:1px solid #35405a; border-radius:18px;
}
QLabel#ChatMeta {color:#bac5e6; font-size:14px; font-weight:600;}
QLabel#ChatText {color:#eef2ff; font-size:15px; line-height:125%;}
QWidget#MessageActions { background:transparent; border:none; }
QPushButton#MessageAction {
    background:transparent; color:#b7cbe8;
    border:1px solid transparent; border-radius:8px;
    padding:2px 6px; font-size:16px;
}
QPushButton#MessageAction:hover {
    background:#344664; border-color:#566b8f; color:#f1f8ff;
}
QPushButton#MessageAction:disabled {
    background:transparent; border-color:transparent; color:#647087;
}
QFrame#ComposerCard {
    background:#161b2a; border:1px solid #30384e; border-radius:18px;
}
QWidget#ComposerEntryRow { background:transparent; }
QPushButton#SendIcon {
    background:#287fa6; border:1px solid #56b3e2; border-radius:15px; padding:0;
}
QPushButton#SendIcon:hover { background:#3693be; }
QPushButton#SendIcon:disabled { background:#27394c; border-color:#3b4e64; }
QFrame#CharacterTile {
    background:#1b2030; border:1px solid #323b52; border-radius:18px;
}
QFrame#CharacterTile[selected="true"] {
    border:2px solid #7ecfff; background:#202b43;
}
QLabel#CharacterTitle { color:#f0f5ff; font-size:16px; font-weight:700; }
QLabel#CharacterCaption { color:#b5bfd5; font-size:14px; }
QLabel#CharacterAvatar { background:#111625; border:0; border-radius:12px; }
QLabel#CharacterTag, QLabel#ChatTag {
    color:#d5e3fa; background:#252d40; border:1px solid #47516c;
    border-radius:9px; padding:5px 8px; font-size:14px;
}
QPushButton#TagChip {
    background:#1b2232; border:1px solid #3c465e; border-radius:15px;
    padding:7px 11px; font-size:14px;
}
QPushButton#TagChip:checked {
    background:#25547a; border:1px solid #69c4ff; color:#eef2ff; font-weight:700;
}
QPushButton#ChipClear {
    background:#23293a; border:1px solid #56657a; border-radius:11px; padding:7px 11px;
}
QPushButton#CardAction {
    padding:4px 2px; font-size:13px; background:#283249; border-radius:9px;
}
QPushButton#CharacterPageArrow {
    min-width:42px; font-size:16px; font-weight:700;
}
QSlider { background:transparent; border:none; }
QSlider::groove:horizontal {
    height:6px; background:#36435c; border-radius:3px;
}
QSlider::sub-page:horizontal {
    background:#4798c4; border-radius:3px;
}
QSlider::handle:horizontal {
    width:16px; margin:-5px 0; border-radius:8px;
    background:#bcddfa; border:1px solid #5ba7d8;
}
QLabel#SliderValue {
    min-width:46px; color:#b8e1ff; font-size: 14px; font-weight:700;
}
QSplitter::handle { background:#151929; }
QSplitter::handle:horizontal { width:6px; }
QSplitter::handle:vertical { height:6px; }

/* Unified navigation and section hierarchy across every workspace. */
QTabWidget#WorkspaceTabs::pane {
    border:1px solid #35405a; background:#151929;
    border-radius:14px; top:-1px;
}
QTabBar::tab {
    background:#1a2031; color:#bac5e6;
    border:1px solid #35405a; border-radius:11px;
    padding:12px 20px; margin-right:8px; min-width:112px;
    font-size:14px; font-weight:650;
}
QTabBar::tab:selected {
    color:#eef2ff; border:1px solid #68bce8;
    background:#2c3456;
}
QTabBar::tab:hover:!selected { background:#29314a; color:#eef2ff; }
QLabel#GalleryMeta, QLabel#ModelHint {
    color:#bac5e6; font-size:14px;
    background:transparent;
}
QLabel#GalleryCount { color:#a1ddff; font-size:14px; font-weight:700; }
QListWidget#GalleryTiles {
    background:transparent; border:none; padding:4px;
}
QListWidget#GalleryTiles::item {
    border:1px solid #30384e; border-radius:12px;
    background:#1b2030; padding:9px; margin:3px;
    color:#eef2ff; font-size:14px;
}
QListWidget#GalleryTiles::item:selected {
    background:#2c3456; border:1px solid #68bce8;
}
QListWidget#GalleryTiles::item:hover { background:#29314a; }
QLabel#GalleryPreview {
    background:#111625; border:1px solid #35405a;
    border-radius:13px; padding:10px;
}
QLabel#Hint { color:#bac5e6; font-size:14px; }
QLabel#BrandEyebrow, QLabel#NavGroup, QLabel#HeaderEyebrow { font-size:12px; }
QLabel#ConversationPreview, QLabel#ConversationMeta { font-size:14px; }
QLabel#CharacterCaption, QLabel#CharacterTag, QLabel#ChatTag { font-size:13px; }

/* Character image covers: the caption sits ON the portrait, not in a separate
   opaque rectangle below it. The translucent backdrop keeps all themes readable. */
QWidget#CharacterCover { background:transparent; border:none; }
QLabel#CharacterImageCaption {
    background-color:rgba(8, 13, 28, 202);
    color:white;
    border:none;
    border-top-left-radius:0px;
    border-top-right-radius:0px;
    border-bottom-left-radius:12px;
    border-bottom-right-radius:12px;
    padding:10px 12px;
    font-size:14px;
    font-weight:500;
}
'''

