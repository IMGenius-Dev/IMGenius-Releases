"""Characters widgets and helpers for the desktop UI."""
from __future__ import annotations

from PySide6.QtCore import QEasingCurve
from PySide6.QtCore import QPoint
from PySide6.QtCore import QPropertyAnimation
from PySide6.QtCore import QRect
from PySide6.QtCore import QRectF
from PySide6.QtCore import QSize
from PySide6.QtCore import Qt
from PySide6.QtCore import Signal
from PySide6.QtGui import QColor
from PySide6.QtGui import QPainter
from PySide6.QtGui import QPainterPath
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QCheckBox
from PySide6.QtWidgets import QFrame
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLayout
from PySide6.QtWidgets import QMenu
from PySide6.QtWidgets import QToolButton
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from imgenius.characters.grid_layout import character_cover_height
from imgenius.characters.grid_layout import shorten_character_description
from imgenius.characters.library import TAG_ICONS
from imgenius.characters.library import normalize_audience
from imgenius.characters.library import normalize_tags
from imgenius.domain import resolve_character_image
from imgenius.ui.widgets.controls import button

FIELD_LABELS = [
    ('name', 'Name'), ('gender', 'Gender'), ('age', 'Age'),
    ('short_description', 'Description'), ('personality', 'Personality'),
    ('scenario', 'Scenario'), ('example_dialogue', 'Example dialogue'),
]

class FlowLayout(QLayout):
    """Wraps tag buttons to the available panel width."""
    def __init__(self, parent=None, margin=0, spacing=7):
        super().__init__(parent)
        self._items = []
        self.setContentsMargins(margin, margin, margin, margin)
        self.setSpacing(spacing)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index):
        return self._items.pop(index) if 0 <= index < len(self._items) else None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rectangle):
        super().setGeometry(rectangle)
        self._do_layout(rectangle, test_only=False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(), margins.top() + margins.bottom())
        return size

    def _do_layout(self, rect, test_only):
        margins = self.contentsMargins()
        left, top, right, bottom = margins.left(), margins.top(), margins.right(), margins.bottom()
        working = rect.adjusted(left, top, -right, -bottom)
        x, y = working.x(), working.y()
        line_height = 0
        for item in self._items:
            # QWidgetItem remains in the layout while a chip is hidden; skip it
            # so collapsed tag palettes do not reserve empty rows.
            if item.widget() is not None and item.widget().isHidden():
                continue
            hint = item.sizeHint()
            next_x = x + hint.width() + self.spacing()
            if next_x - self.spacing() > working.right() + 1 and line_height > 0:
                x = working.x()
                y += line_height + self.spacing()
                next_x = x + hint.width() + self.spacing()
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y() + bottom

class CharacterCover(QWidget):
    """A consistent portrait-sized, clickable cover with a sliding description.

    Every tile gets the same cover height at a given card width, independently
    of source image dimensions. A centered aspect-fill crop avoids stretching.
    Hover animation affects only the caption child, never the card layout.
    """
    clicked = Signal()

    def __init__(self, pixmap, description, parent=None):
        super().__init__(parent)
        self.setObjectName('CharacterCover')
        self._source = pixmap if isinstance(pixmap, QPixmap) else QPixmap()
        self._full_description = ' '.join((description or 'Local character').split())
        self._hovered = False
        self._collapsed_height = 66
        self._collapsed_text = ''
        self._expanded_text = self._full_description
        self.setMinimumHeight(205)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setToolTip('Click to start a chat; hover to read more')

        self._caption = QLabel('', self)
        self._caption.setObjectName('CharacterImageCaption')
        self._caption.setWordWrap(True)
        self._caption.setTextFormat(Qt.TextFormat.PlainText)
        self._caption.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self._caption.setToolTip(self._full_description)
        self._caption.setMinimumHeight(44)
        # Otherwise the caption intercepts clicks instead of opening a chat.
        self._caption.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

        self._slide = QPropertyAnimation(self._caption, b'geometry', self)
        self._slide.setDuration(230)
        self._slide.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._slide.finished.connect(self._animation_finished)
        self._fit_caption(240)
        self._apply_caption_state()

    def _text_height(self, text, text_width):
        metrics = self._caption.fontMetrics()
        bounds = metrics.boundingRect(
            QRect(0, 0, max(60, int(text_width) - 24), 10000),
            Qt.TextFlag.TextWordWrap, text)
        return bounds.height()

    def _fit_caption(self, width):
        """Fit the collapsed excerpt and a longer hover excerpt to their bounds."""
        width = max(100, int(width))
        metrics = self._caption.fontMetrics()
        budget = 86
        while True:
            preview = shorten_character_description(self._full_description, budget)
            bounds = metrics.boundingRect(
                QRect(0, 0, max(60, width - 24), 10000),
                Qt.TextFlag.TextWordWrap, preview)
            if bounds.height() <= metrics.lineSpacing() * 3 + 2 or budget <= 12:
                break
            budget -= 4
        self._collapsed_text = preview
        self._collapsed_height = min(self.height(), max(44, bounds.height() + 28))

        # Prefer the entire description on hover; only elide when necessary
        # to keep the *last visible line* inside the portrait rather than cut it.
        space = max(36, self.height() - 30)
        if self._text_height(self._full_description, width) <= space:
            self._expanded_text = self._full_description
        else:
            low, high = 8, len(self._full_description)
            best = shorten_character_description(self._full_description, low)
            while low <= high:
                mid = (low + high) // 2
                candidate = shorten_character_description(self._full_description, mid)
                if self._text_height(candidate, width) <= space:
                    best = candidate
                    low = mid + 1
                else:
                    high = mid - 1
            self._expanded_text = best

    def _caption_rectangle(self, expanded):
        if expanded:
            return QRect(0, 0, self.width(), self.height())
        return QRect(0, self.height() - self._collapsed_height,
                     self.width(), self._collapsed_height)

    def _apply_caption_state(self):
        self._slide.stop()
        self._caption.setText(self._expanded_text if self._hovered else self._collapsed_text)
        self._caption.setGeometry(self._caption_rectangle(self._hovered))

    def _animate_caption(self, expanded):
        self._slide.stop()
        start = self._caption.geometry()
        self._hovered = expanded
        if expanded:
            self._caption.setText(self._expanded_text)
        self._slide.setStartValue(start)
        self._slide.setEndValue(self._caption_rectangle(expanded))
        self._slide.start()

    def _animation_finished(self):
        if not self._hovered:
            self._caption.setText(self._collapsed_text)

    def enterEvent(self, event):
        super().enterEvent(event)
        self._animate_caption(True)

    def leaveEvent(self, event):
        super().leaveEvent(event)
        self._animate_caption(False)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Space):
            self.clicked.emit()
            event.accept()
            return
        super().keyPressEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not hasattr(self, '_slide'):
            return
        self._fit_caption(self.width())
        self._apply_caption_state()

    def set_card_width(self, card_width):
        h = character_cover_height(self._source.width(), self._source.height(), card_width)
        self.setFixedSize(int(card_width), h)
        self._fit_caption(card_width)
        self._apply_caption_state()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        shape = QPainterPath()
        shape.addRoundedRect(QRectF(self.rect()), 12.0, 12.0)
        painter.setClipPath(shape)
        painter.fillRect(self.rect(), QColor('#212a3c'))
        if not self._source.isNull():
            # Fill the whole common-size portrait area by cropping, not warping.
            image = self._source.scaled(
                self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation)
            painter.drawPixmap((self.width() - image.width()) // 2,
                               (self.height() - image.height()) // 2, image)
        else:
            painter.setPen(QColor('#becae3'))
            painter.drawText(self.rect().adjusted(12, 12, -12, -12),
                             Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
                             'No portrait')
        painter.end()

class CharacterTile(QFrame):
    """Locally stored character thumbnail and actionable card."""
    def __init__(self, character, chat_count, selected, controller, parent=None, deletable=False):
        super().__init__(parent)
        self.character_id = character['id']
        self.setObjectName('CharacterTile')
        self.setProperty('selected', bool(selected))
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)
        outer.setSpacing(8)

        head = QHBoxLayout()
        name = QLabel(character.get('name') or 'Unnamed')
        name.setObjectName('CharacterTitle')
        name.setWordWrap(True)
        head.addWidget(name, 1)
        self.checkbox = QCheckBox()
        self.checkbox.setToolTip('Select character for bulk actions')
        self.checkbox.setChecked(bool(selected))
        self.checkbox.toggled.connect(self._set_selected_style)
        self.checkbox.toggled.connect(lambda checked: controller.toggle_character_selection(self.character_id, checked))
        head.addWidget(self.checkbox)
        if deletable:
            menu_button = QToolButton(self)
            menu_button.setText('⋮')
            menu_button.setToolTip('Character actions')
            menu_button.setAccessibleName('Character actions')
            menu_button.setObjectName('CardAction')
            menu_button.setFixedWidth(26)
            menu_button.setMinimumHeight(30)
            menu_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            menu = QMenu(menu_button)
            delete_action = menu.addAction('Delete character…')
            delete_action.triggered.connect(lambda: controller.delete_character_by_id(self.character_id))
            menu_button.setMenu(menu)
            head.addWidget(menu_button)
        outer.addLayout(head)

        image_file = resolve_character_image(character)
        pix = QPixmap(str(image_file)) if image_file else QPixmap()
        description = ' '.join((character.get('short_description') or
                                character.get('personality') or 'Local character').split())
        self.cover = CharacterCover(pix, description, self)
        self.cover.clicked.connect(lambda: controller.start_chat_for_character(self.character_id))
        outer.addWidget(self.cover)
        badges = QWidget()
        badges.setObjectName('CharacterBadges')
        badges.setMinimumHeight(70)
        badge_layout = FlowLayout(badges, spacing=4)
        tags = normalize_tags(character.get('tags'))
        # Safety label is first and always visible; show a few descriptive tags.
        for label in [normalize_audience(character.get('audience'))] + tags[:3]:
            chip = QLabel((TAG_ICONS.get(label, '') + ' ' + label).strip())
            chip.setObjectName('CharacterTag')
            badge_layout.addWidget(chip)
        outer.addWidget(badges)

        caption = QLabel(f"{int(chat_count)} local chat{'s' if chat_count != 1 else ''}  ·  " +
                         ('Featured' if character.get('featured') else 'Local'))
        caption.setObjectName('CharacterCaption')
        outer.addWidget(caption)
        reactions = QHBoxLayout()
        reactions.setSpacing(3)
        edit_button = button('Edit', lambda: controller.edit_character_by_id(self.character_id))
        edit_button.setObjectName('CardAction')
        edit_button.setFixedWidth(48)
        edit_button.setMinimumHeight(34)
        reactions.addWidget(edit_button)
        reactions.addStretch(1)
        actions = [
            ('♥' if character.get('reaction') == 1 else '♡', 'Like', 1),
            ('👎' if character.get('reaction') == -1 else '↓', 'Dislike', -1),
        ]
        for caption, tooltip, value in actions:
            b = button(caption, lambda checked=False, reaction=value: controller.react_character(self.character_id, reaction))
            b.setObjectName('CardAction')
            b.setFixedWidth(26)
            b.setMinimumHeight(34)
            b.setToolTip(f'{tooltip} (stored on this device)')
            reactions.addWidget(b)
        fav = button('★' if character.get('favorite') else '☆', lambda: controller.toggle_character_favorite(self.character_id))
        fav.setObjectName('CardAction')
        fav.setFixedWidth(26)
        fav.setMinimumHeight(34)
        fav.setToolTip('Remove from favorites' if character.get('favorite') else 'Add to favorites')
        reactions.addWidget(fav)
        export = button('⇩', lambda: controller.export_character_by_id(self.character_id))
        export.setObjectName('CardAction')
        export.setFixedWidth(26)
        export.setMinimumHeight(34)
        export.setToolTip('Export character card PNG')
        reactions.addWidget(export)
        outer.addLayout(reactions)

    def set_card_width(self, width):
        width = max(170, int(width))
        self.setFixedWidth(width)
        self.cover.set_card_width(width - 20)  # account for card margins
        self.updateGeometry()

    def _set_selected_style(self, checked):
        self.setProperty('selected', bool(checked))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def mousePressEvent(self, event):
        # Clicking the blank card surface makes this the active character.
        if event.button() == Qt.MouseButton.LeftButton:
            owner = self.parent()
            while owner is not None and not hasattr(owner, 'select_character'):
                owner = owner.parent()
            if owner is not None:
                owner.select_character(self.character_id)
        super().mousePressEvent(event)

