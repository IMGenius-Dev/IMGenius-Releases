"""Widgets components for IMGenius."""
