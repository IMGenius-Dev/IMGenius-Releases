"""Controls widgets and helpers for the desktop UI."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QComboBox
from PySide6.QtWidgets import QDoubleSpinBox
from PySide6.QtWidgets import QFrame
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QPlainTextEdit
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QScrollArea
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QSlider
from PySide6.QtWidgets import QSpinBox
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget

class NoWheelComboBox(QComboBox):
    """A dropdown that only changes with intentional click/keyboard input.

    Ignoring wheel events allows an enclosing scroll area to scroll instead.
    """

    def wheelEvent(self, event):
        event.ignore()

class NoWheelSpinBox(QSpinBox):
    """Keep wheel scrolling from changing integer values."""

    def wheelEvent(self, event):
        event.ignore()

class NoWheelDoubleSpinBox(QDoubleSpinBox):
    """Keep wheel scrolling from changing decimal values."""

    def wheelEvent(self, event):
        event.ignore()

class NoWheelSlider(QSlider):
    """Allow drag/click/keyboard adjustment, but never mouse-wheel adjustment."""

    def wheelEvent(self, event):
        event.ignore()

class SettingSlider(QWidget):
    """Compact slider with readable value; public value()/setValue() API."""
    def __init__(self, value, minimum, maximum, step, decimals=2, parent=None):
        super().__init__(parent)
        self._scale = 10 ** decimals
        self._decimals = decimals
        self._step = float(step)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(9)
        self.slider = NoWheelSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(round(minimum * self._scale), round(maximum * self._scale))
        self.slider.setSingleStep(max(1, round(step * self._scale)))
        self.slider.setPageStep(max(1, round(step * self._scale * 5)))
        self.slider.setTracking(True)
        row.addWidget(self.slider, 1)
        self.readout = QLabel()
        self.readout.setObjectName('SliderValue')
        self.readout.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        row.addWidget(self.readout)
        self.slider.valueChanged.connect(self._show_value)
        self.setValue(value)

    def _show_value(self, *_):
        number = self.value()
        if self._decimals == 0:
            self.readout.setText(f'{number:,}')
        else:
            self.readout.setText(f'{number:.{self._decimals}f}')

    def value(self):
        result = self.slider.value() / self._scale
        return int(result) if self._decimals == 0 else round(result, self._decimals)

    def setValue(self, value):
        try:
            number = float(value)
        except (TypeError, ValueError):
            return
        unit = max(1, round(self._step * self._scale))
        raw = round(number * self._scale / unit) * unit
        self.slider.setValue(max(self.slider.minimum(), min(raw, self.slider.maximum())))
        self._show_value()

class ContextSizeCombo(NoWheelComboBox):
    VALUES = (512, 1024, 1536, 2048, 3072, 4096, 6144, 8192, 12288,
              16384, 24576, 32768, 49152, 65536, 98304, 131072)

    def __init__(self, default=4096, parent=None):
        super().__init__(parent)
        for size in self.VALUES:
            self.addItem(f'{size:,} tokens', size)
        self.setValue(default)
        self.setToolTip('Larger context requires more RAM/VRAM; model limits vary.')

    def value(self):
        return int(self.currentData() or 4096)

    def setValue(self, requested):
        try:
            requested = int(requested)
        except (TypeError, ValueError):
            return
        idx = self.findData(requested)
        if idx < 0:
            # Keep uncommon existing settings instead of silently changing them.
            if 256 <= requested <= 131072:
                self.addItem(f'{requested:,} tokens (custom)', requested)
                idx = self.count() - 1
            else:
                idx = self.findData(4096)
        self.setCurrentIndex(idx)

def button(label, callback=None, primary=False):
    b = QPushButton(label)
    b.setMinimumHeight(38)
    if primary:
        b.setObjectName('Primary')
    if callback:
        b.clicked.connect(callback)
    return b

def section_label(text):
    label = QLabel(text)
    label.setObjectName('HelperText')
    label.setWordWrap(True)
    return label

def textedit(placeholder='', height=90):
    w = QPlainTextEdit()
    w.setPlaceholderText(placeholder)
    w.setMinimumHeight(height)
    w.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.MinimumExpanding)
    return w

def spin(value, low, high, step=1):
    w = NoWheelSpinBox()
    w.setRange(low, high)
    w.setSingleStep(step)
    w.setValue(value)
    return w

def dspin(value, low, high, step=.1, decimals=2):
    w = NoWheelDoubleSpinBox()
    w.setRange(low, high)
    w.setSingleStep(step)
    w.setDecimals(decimals)
    w.setValue(value)
    return w

def section_panel(title, layout_type=QVBoxLayout):
    """Stable panel heading within the layout, never overlapping its content."""
    panel = QFrame()
    panel.setObjectName('SectionPanel')
    root = QVBoxLayout(panel)
    root.setContentsMargins(17, 16, 17, 17)
    root.setSpacing(12)
    heading = QLabel(title)
    heading.setObjectName('SectionHeading')
    heading.setWordWrap(True)
    root.addWidget(heading)
    divider = QFrame()
    divider.setObjectName('SectionDivider')
    divider.setFixedHeight(1)
    root.addWidget(divider)
    content = layout_type()
    content.setSpacing(11)
    root.addLayout(content)
    return panel, content

def make_card(title, parent_layout, vertical=True):
    # Keep the existing builder API used throughout the application.
    panel, content = section_panel(title, QVBoxLayout if vertical else QHBoxLayout)
    parent_layout.addWidget(panel)
    return content

def scroll_content():
    outer = QScrollArea()
    outer.setObjectName('PageScroll')
    outer.setWidgetResizable(True)
    outer.setFrameShape(QFrame.Shape.NoFrame)
    inner = QWidget()
    inner.setObjectName('PageBody')
    layout = QVBoxLayout(inner)
    layout.setContentsMargins(24, 18, 24, 28)
    layout.setSpacing(16)
    outer.setWidget(inner)
    return outer, layout

