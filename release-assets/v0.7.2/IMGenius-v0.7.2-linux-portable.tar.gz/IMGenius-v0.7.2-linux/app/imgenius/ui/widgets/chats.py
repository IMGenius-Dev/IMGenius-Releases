"""Chats widgets and helpers for the desktop UI."""
from __future__ import annotations

from PySide6.QtCore import QEvent
from PySide6.QtCore import QPointF
from PySide6.QtCore import QSize
from PySide6.QtCore import Qt
from PySide6.QtCore import Signal
from PySide6.QtGui import QColor
from PySide6.QtGui import QIcon
from PySide6.QtGui import QPainter
from PySide6.QtGui import QPainterPath
from PySide6.QtGui import QPen
from PySide6.QtGui import QPixmap
from PySide6.QtGui import QTextDocument
from PySide6.QtWidgets import QDialog
from PySide6.QtWidgets import QFormLayout
from PySide6.QtWidgets import QFrame
from PySide6.QtWidgets import QHBoxLayout
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QLineEdit
from PySide6.QtWidgets import QDialogButtonBox
from PySide6.QtWidgets import QLabel
from imgenius.ui.widgets.visuals import ClickableImageLabel
from PySide6.QtWidgets import QListWidget
from PySide6.QtWidgets import QPlainTextEdit
from PySide6.QtWidgets import QPushButton
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QVBoxLayout
from PySide6.QtWidgets import QWidget
from datetime import datetime
from imgenius.chats.formatting import format_chat_html
from imgenius.domain import resolve_character_image
from imgenius.domain import safe_text
from imgenius.ui.brand_assets import app_icon_path
from imgenius.ui.widgets.controls import button
import math

class MessageEditDialog(QDialog):
    """Wide, wrapped message editor; no horizontal scrolling."""
    def __init__(self, message, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Edit message')
        self.resize(650, 360)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('Message:'))
        self.editor = QPlainTextEdit(self)
        self.editor.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.editor.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.editor.setPlainText(message)
        layout.addWidget(self.editor)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def text(self):
        return self.editor.toPlainText()


class ChatImageWidget(QWidget):
    """A persisted, clickable ComfyUI image in a conversation."""
    def __init__(self, path, prompt, on_open=None, parent=None):
        super().__init__(parent)
        self.original = QPixmap(str(path))
        self.prompt = prompt
        self.on_open = on_open
        body = QVBoxLayout(self)
        body.setContentsMargins(8, 5, 8, 8)
        label = QLabel('Generated scene image  ·  Click to enlarge')
        label.setObjectName('ChatMeta')
        body.addWidget(label)
        self.image = ClickableImageLabel('Image unavailable')
        self.image.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.image.setToolTip(prompt[:1500])
        self.image.clicked.connect(lambda: self.on_open(self.original) if self.on_open else None)
        body.addWidget(self.image)
        self.resize_for_width(600)

    def resize_for_width(self, width):
        available = max(160, min(430, int(width) - 26))
        if not self.original.isNull():
            pix = self.original.scaled(available, 310, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            self.image.setPixmap(pix)
            self.image.set_image_state(True)
            self.image.setFixedSize(pix.size())
        else:
            self.image.setText('Generated image could not be loaded')
            self.image.set_image_state(False)
            self.image.setFixedSize(available, 60)
        height = self.image.height() + 49
        self.setFixedHeight(height)
        return QSize(max(220, int(width)), height)


class ChatHistoryList(QListWidget):
    """Pixel-scrollable conversation with an explicit user-scroll signal.

    A long opening message may be taller than the viewport. Item-based scrolling
    skips its middle; ScrollPerPixel allows the whole message to be read.
    """
    userScrollStarted = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setVerticalScrollMode(QListWidget.ScrollMode.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setWordWrap(False)  # Individual rich-text widgets wrap themselves.
        self.verticalScrollBar().setSingleStep(22)

    def wheelEvent(self, event):
        self.userScrollStarted.emit()
        super().wheelEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Up, Qt.Key.Key_Down, Qt.Key.Key_PageUp,
                           Qt.Key.Key_PageDown, Qt.Key.Key_Home, Qt.Key.Key_End,
                           Qt.Key.Key_Space):
            self.userScrollStarted.emit()
        super().keyPressEvent(event)


class SendTextEdit(QPlainTextEdit):
    sendRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not (event.modifiers() & Qt.KeyboardModifier.ShiftModifier):
            if not event.isAutoRepeat():
                self.sendRequested.emit()
            event.accept()
            return
        super().keyPressEvent(event)

def format_chat_timestamp(value):
    if not value:
        return ''
    try:
        stamp = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        return stamp.strftime('%H:%M')
    except Exception:
        return ''

def send_button_icon():
    """Draw a scalable paper-plane icon using Qt (no external icon files)."""
    pixmap = QPixmap(36, 36)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QPen(QColor('#f6faff'), 2.2, Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    path = QPainterPath()
    path.moveTo(QPointF(5, 17))
    path.lineTo(QPointF(31, 5))
    path.lineTo(QPointF(23, 31))
    path.lineTo(QPointF(17, 21))
    path.lineTo(QPointF(5, 17))
    path.moveTo(QPointF(17, 21))
    path.lineTo(QPointF(31, 5))
    painter.drawPath(path)
    painter.end()
    return QIcon(pixmap)

class ChatBubbleWidget(QWidget):
    """Message bubble with its own action controls and stable text measurement."""
    ICONS = {
        'regenerate': '↻', 'continue': '➜', 'stop': '■',
        'edit': '✎', 'delete': '×',
    }
    LABELS = {
        'regenerate': 'Regenerate this reply',
        'continue': 'Continue this reply',
        'stop': 'Stop this response',
        'edit': 'Edit message',
        'delete': 'Delete message',
    }

    def __init__(self, role, content, created_at='', sender_name=None,
                 message_id=None, action_callback=None, pending=False, parent=None):
        super().__init__(parent)
        self.role = role
        self.message_id = message_id
        self.is_pending = bool(pending)
        self.action_buttons = {}
        self._content = ''
        self._available_width = 680
        self.installEventFilter(self)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(7, 5, 7, 5)
        outer.setSpacing(0)
        self.bubble = QFrame()
        self.bubble.setObjectName('ChatBubbleUser' if role == 'user' else 'ChatBubbleAssistant')
        inner = QVBoxLayout(self.bubble)
        inner.setContentsMargins(15, 11, 15, 11)
        inner.setSpacing(7)

        # One compact header: sender/time on the left, message actions at top-right.
        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(4)
        self.meta = QLabel()
        self.meta.setObjectName('ChatMeta')
        who = 'You' if role == 'user' else (sender_name or 'Assistant')
        stamp = format_chat_timestamp(created_at)
        self.meta.setText(who + (f'  •  {stamp}' if stamp else ''))
        self.meta.setWordWrap(False)
        self.meta.installEventFilter(self)
        header.addWidget(self.meta)
        header.addStretch(1)

        self.action_bar = QWidget()
        self.action_bar.setObjectName('MessageActions')
        bar_layout = QHBoxLayout(self.action_bar)
        bar_layout.setContentsMargins(0, 0, 0, 0)
        bar_layout.setSpacing(4)
        if pending:
            choices = ('stop',)
        elif message_id is not None:
            choices = ('regenerate', 'continue', 'edit', 'delete') if role == 'assistant' else ('edit', 'delete')
        else:
            choices = ()
        for action in choices:
            action_button = QPushButton(self.ICONS[action])
            action_button.setObjectName('MessageAction')
            action_button.setToolTip(self.LABELS[action])
            action_button.setAccessibleName(self.LABELS[action])
            action_button.setFixedSize(28, 26)
            action_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            action_button.setEnabled(False)
            if action_callback:
                action_button.clicked.connect(
                    lambda checked=False, name=action: action_callback(name, self.message_id)
                )
            bar_layout.addWidget(action_button)
            self.action_buttons[action] = action_button
        if choices:
            header.addWidget(self.action_bar, 0, Qt.AlignmentFlag.AlignRight)
        else:
            self.action_bar.hide()
        inner.addLayout(header)

        self.content_label = QLabel()
        self.content_label.setObjectName('ChatText')
        self.content_label.setWordWrap(True)
        self.content_label.setTextFormat(Qt.TextFormat.RichText)
        self.content_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.content_label.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.content_label.setMargin(0)
        self.content_label.setIndent(0)
        self.content_label.installEventFilter(self)
        self.bubble.installEventFilter(self)
        inner.addWidget(self.content_label)

        if role == 'user':
            outer.addStretch(1)
            outer.addWidget(self.bubble)
        else:
            outer.addWidget(self.bubble)
            outer.addStretch(1)
        self.set_content(content)

    def set_content(self, content):
        self._content = str(content or '')
        self.content_label.setText(format_chat_html(self._content, self.role) if self._content.strip() else '<i>Thinking…</i>')
        self.resize_for_width(self._available_width)

    def resize_for_width(self, viewport_width):
        """Compute the full row geometry deterministically from text and font.

        This deliberately ignores the previous fixed height. Width accounts for
        the header action buttons, and vertical padding covers QLabel rendering
        differences, preventing the last line being clipped on resize or DPI changes.
        """
        self._available_width = max(240, int(viewport_width))
        max_width = min(920, int(self._available_width * .90))
        max_width = max(195, min(max_width, self._available_width - 16))
        text = self._content or 'Thinking…'
        metrics = self.content_label.fontMetrics()
        natural_text_width = max(
            (metrics.horizontalAdvance(line) for line in text.split('\n')),
            default=0,
        )
        buttons = len(getattr(self, 'action_buttons', {}))
        action_width = buttons * 28 + max(0, buttons - 1) * 4
        header_width = (self.meta.fontMetrics().horizontalAdvance(self.meta.text())
                        + action_width + (9 if buttons else 0))
        # 30px inner horizontal margins, plus 2px border/safety margin.
        width = min(max_width, max(165, natural_text_width + 36, header_width + 36))
        text_width = max(130, width - 36)

        measured = QTextDocument()
        measured.setDefaultFont(self.content_label.font())
        measured.setDocumentMargin(0)
        measured.setHtml(self.content_label.text())
        measured.setTextWidth(text_width)
        # Qt's QLabel and QTextDocument may differ slightly in their rich-text
        # line spacing, especially for large imported opening messages containing
        # paragraphs, HTML and roleplay markup. Leave a proportional safety
        # allowance so the last lines can never be clipped by the fixed row.
        document_height = math.ceil(measured.size().height())
        content_height = max(metrics.height() + 12,
                             document_height + max(18, math.ceil(document_height * .08)))
        meta_height = self.meta.fontMetrics().height() + 5
        header_height = max(meta_height, 28 if buttons else meta_height)
        bubble_height = 22 + header_height + 7 + content_height + 4
        row_height = bubble_height + 10

        self.bubble.setFixedWidth(width)
        self.content_label.setFixedWidth(text_width)
        self.content_label.setFixedHeight(content_height)
        self.bubble.setFixedHeight(bubble_height)
        self.setFixedHeight(row_height)
        self.updateGeometry()
        return QSize(self._available_width, row_height)

    def eventFilter(self, watched, event):
        if event.type() == QEvent.Type.MouseButtonPress:
            list_widget = self.parentWidget()
            while list_widget is not None and not isinstance(list_widget, QListWidget):
                list_widget = list_widget.parentWidget()
            if list_widget is not None:
                point = list_widget.viewport().mapFromGlobal(event.globalPosition().toPoint())
                selected = list_widget.itemAt(point)
                if selected is not None:
                    list_widget.setCurrentItem(selected)
        return super().eventFilter(watched, event)

class ConversationRow(QFrame):
    """Instant-messenger row with select and delete controls."""
    clicked = Signal(int)
    deleteRequested = Signal(int)

    def __init__(self, chat, character, preview, parent=None):
        super().__init__(parent)
        self.setObjectName('ConversationRow')
        self.chat_id = chat['id']
        self.setProperty('active', False)
        self.setMinimumHeight(84)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(9, 9, 8, 9)
        layout.setSpacing(10)
        avatar = QLabel()
        avatar.setObjectName('ConversationAvatar')
        avatar.setFixedSize(54, 54)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        portrait = resolve_character_image(character)
        pix = QPixmap(str(portrait)) if portrait else QPixmap()
        if pix.isNull():
            fallback = QPixmap(str(app_icon_path()))
            if not fallback.isNull():
                avatar.setPixmap(fallback.scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatio,
                                                 Qt.TransformationMode.SmoothTransformation))
            else:
                avatar.setText((safe_text((character or {}).get('name')) or '?')[:1].upper())
                avatar.setStyleSheet('background:#30405a;border-radius:26px;font-size:23px;')
        else:
            avatar.setPixmap(pix.scaled(54, 54, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                        Qt.TransformationMode.SmoothTransformation))
        layout.addWidget(avatar)
        right = QVBoxLayout()
        right.setSpacing(4)
        header = QHBoxLayout()
        title = QLabel(safe_text((character or {}).get('name')) or safe_text(chat.get('title')) or 'Unknown character')
        title.setObjectName('ConversationName')
        header.addWidget(title, 1)
        meta = QLabel(format_chat_timestamp(chat.get('updated_at')))
        meta.setObjectName('ConversationMeta')
        header.addWidget(meta)
        delete_button = QPushButton('×')
        delete_button.setObjectName('ChatRowDelete')
        delete_button.setToolTip('Delete this conversation')
        delete_button.setAccessibleName('Delete conversation')
        delete_button.setFixedSize(24, 24)
        delete_button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        delete_button.clicked.connect(
            lambda checked=False: self.deleteRequested.emit(self.chat_id)
        )
        header.addWidget(delete_button)
        self.delete_button = delete_button
        right.addLayout(header)
        self.preview = QLabel(preview or 'Start a conversation…')
        self.preview.setObjectName('ConversationPreview')
        self.preview.setToolTip(preview or '')
        self.preview.setWordWrap(False)
        self.preview.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self._full_preview = preview or 'Start a conversation…'
        right.addWidget(self.preview)
        count = int(chat.get('message_count') or 0)
        detail = QLabel(f"{count} message{'s' if count != 1 else ''}  ·  {safe_text(chat.get('title'))}")
        detail.setObjectName('ConversationMeta')
        right.addWidget(detail)
        layout.addLayout(right, 1)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        width = max(55, self.preview.width())
        self.preview.setText(self.preview.fontMetrics().elidedText(
            self._full_preview, Qt.TextElideMode.ElideRight, width))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.chat_id)
            event.accept()
            return
        super().mousePressEvent(event)

    def set_active(self, active):
        self.setProperty('active', bool(active))
        self.style().unpolish(self)
        self.style().polish(self)

class PersonaEditorDialog(QDialog):
    def __init__(self, persona=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Persona editor')
        self.resize(420, 320)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.name = QLineEdit(safe_text((persona or {}).get('name')))
        self.user_name = QLineEdit(safe_text((persona or {}).get('user_name'), 'User'))
        self.description = QPlainTextEdit()
        self.description.setPlainText(safe_text((persona or {}).get('description')))
        self.description.setMinimumHeight(70)
        self.prompt = QPlainTextEdit()
        self.prompt.setPlainText(safe_text((persona or {}).get('prompt')))
        self.prompt.setMinimumHeight(90)
        form.addRow('Persona name', self.name)
        form.addRow('User name', self.user_name)
        form.addRow('Description', self.description)
        form.addRow('Prompt / notes', self.prompt)
        layout.addLayout(form)
        buttons = QHBoxLayout()
        ok = button('Save', self.accept, True)
        cancel = button('Cancel', self.reject)
        buttons.addStretch(1)
        buttons.addWidget(ok)
        buttons.addWidget(cancel)
        layout.addLayout(buttons)
        self.persona_id = safe_text((persona or {}).get('id'))

    def value(self):
        return {
            'id': self.persona_id,
            'name': self.name.text().strip(),
            'user_name': self.user_name.text().strip() or 'User',
            'description': self.description.toPlainText().strip(),
            'prompt': self.prompt.toPlainText().strip(),
        }

