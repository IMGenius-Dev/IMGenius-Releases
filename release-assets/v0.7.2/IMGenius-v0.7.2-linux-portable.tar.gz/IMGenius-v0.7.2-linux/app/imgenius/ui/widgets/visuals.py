"""Visuals widgets and helpers for the desktop UI."""
from __future__ import annotations

from PySide6.QtCore import QSize
from PySide6.QtCore import Qt
from PySide6.QtCore import Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog
from PySide6.QtWidgets import QLabel
from PySide6.QtWidgets import QSizePolicy
from PySide6.QtWidgets import QVBoxLayout

class AspectFitPreview(QLabel):
    """Scale from original pixels on each resize; do not stretch or grow layouts."""
    def __init__(self, placeholder='Select an image', parent=None):
        super().__init__(placeholder, parent)
        self._source = QPixmap()
        self._placeholder = placeholder
        self.setObjectName('GalleryPreview')
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(380)

    def set_image(self, image):
        self._source = image if isinstance(image, QPixmap) else QPixmap()
        self._rescale()

    def _rescale(self):
        if self._source.isNull():
            self.clear()
            self.setText(self._placeholder)
            return
        target = self.contentsRect().size() - QSize(24, 24)
        if target.width() < 60 or target.height() < 60:
            return
        self.setText('')
        self.setPixmap(self._source.scaled(target,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._rescale()

class LightboxDialog(QDialog):
    def __init__(self, pixmap, parent=None):
        super().__init__(parent)
        self._source = pixmap if isinstance(pixmap, QPixmap) else QPixmap()
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setObjectName('ImageLightbox')
        self.setStyleSheet('QDialog#ImageLightbox { background: rgba(5, 8, 16, 210); }')

        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 28, 28, 28)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet('background:#101523;border:1px solid #55627f;border-radius:14px;padding:14px;')
        self.image_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        outer.addWidget(self.image_label, 0, Qt.AlignmentFlag.AlignCenter)

        self.hint = QLabel('Click outside the image or press Esc to close')
        self.hint.setObjectName('Hint')
        self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        outer.addWidget(self.hint, 0, Qt.AlignmentFlag.AlignHCenter)

    def showEvent(self, event):
        super().showEvent(event)
        self._rescale()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._rescale()

    def _rescale(self):
        if self._source.isNull():
            self.image_label.clear()
            self.image_label.setText('No image')
            self.image_label.setFixedSize(240, 180)
            return
        target = self.size() - QSize(120, 140)
        target.setWidth(max(240, target.width()))
        target.setHeight(max(240, target.height()))
        scaled = self._source.scaled(target, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.image_label.setPixmap(scaled)
        self.image_label.setFixedSize(scaled.width() + 28, scaled.height() + 28)

    def mousePressEvent(self, event):
        if not self.image_label.geometry().contains(event.position().toPoint()):
            self.reject()
            event.accept()
            return
        super().mousePressEvent(event)

class ClickableImageLabel(QLabel):
    clicked = Signal()

    def __init__(self, text='', parent=None):
        super().__init__(text, parent)
        self._has_image = False

    def set_image_state(self, has_image):
        self._has_image = bool(has_image)
        self.setCursor(Qt.CursorShape.PointingHandCursor if self._has_image else Qt.CursorShape.ArrowCursor)

    def mousePressEvent(self, event):
        if self._has_image and event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
            event.accept()
            return
        super().mousePressEvent(event)

