"""Workers widgets and helpers for the desktop UI."""
from __future__ import annotations

from PySide6.QtCore import QObject
from PySide6.QtCore import QRunnable
from PySide6.QtCore import Signal
from imgenius.images.comfy import Cancelled
import threading

class WorkerSignals(QObject):
    finished = Signal(object)
    error = Signal(str)
    status = Signal(str)
    token = Signal(str)
    cancelled = Signal(str)

class Worker(QRunnable):
    def __init__(self, function):
        super().__init__()
        self.function = function
        self.signals = WorkerSignals()
        self.cancel_event = threading.Event()

    def run(self):
        try:
            result = self.function(self.cancel_event, self.signals.token.emit, self.signals.status.emit)
        except Cancelled as exc:
            self.signals.cancelled.emit(str(exc))
        except Exception as exc:
            self.signals.error.emit(f'{type(exc).__name__}: {exc}')
        else:
            self.signals.finished.emit(result)

