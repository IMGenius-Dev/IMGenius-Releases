"""SQLite story repository."""
import sqlite3
from datetime import datetime, timezone
from imgenius.shared.paths import DATA_DIR

class StoryStore:
    def __init__(self, db_path=None):
        self.db_path = str(db_path or DATA_DIR / 'stories.db')
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.execute('''CREATE TABLE IF NOT EXISTS stories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL, genre TEXT NOT NULL DEFAULT '',
            premise TEXT NOT NULL DEFAULT '', content TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL)''')
        self.conn.commit()

    def list_stories(self):
        self.conn.row_factory = sqlite3.Row
        return [dict(row) for row in self.conn.execute('SELECT * FROM stories ORDER BY updated_at DESC')]

    def get(self, story_id):
        self.conn.row_factory = sqlite3.Row
        row = self.conn.execute('SELECT * FROM stories WHERE id=?', (story_id,)).fetchone()
        return dict(row) if row else None

    def save(self, story_id, title, genre, premise, content):
        now = datetime.now(timezone.utc).isoformat()
        if story_id is None:
            cur = self.conn.execute('INSERT INTO stories (title,genre,premise,content,updated_at) VALUES (?,?,?,?,?)',
                                    (title, genre, premise, content, now))
            story_id = cur.lastrowid
        else:
            self.conn.execute('UPDATE stories SET title=?,genre=?,premise=?,content=?,updated_at=? WHERE id=?',
                              (title, genre, premise, content, now, story_id))
        self.conn.commit()
        return story_id

    def delete(self, story_id):
        self.conn.execute('DELETE FROM stories WHERE id=?', (story_id,))
        self.conn.commit()
