"""Stable data/domain API for the desktop frontend and optional extensions."""
from imgenius.shared.paths import DATA_DIR, CARD_DIR, DB_PATH, PERSONA_PATH, get_user_data_dir
from imgenius.shared.text import safe_text, apply_tokens
from imgenius.characters.prompts import (
    DEFAULT_SYSTEM_PROMPT, DEFAULT_FIRST_MESSAGE, GENDER_CHOICES,
    default_first_message, build_character_prompt,
)
from imgenius.characters.repository import CharacterStore
from imgenius.characters.portraits import (
    generate_character_card_png, save_default_characters, cleanup_example_characters,
    resolve_character_image, make_placeholder_portrait, ensure_default_character_images,
    export_character_card, select_font,
)
from imgenius.chats.repository import ChatStore
from imgenius.chats.personas import PersonaStore
from imgenius.stories.repository import StoryStore
from imgenius.models.legacy_bridge import (
    query_huggingface, get_ollama_models, install_ollama_model, generate_ollama_response,
)
