"""Safe, deliberately scoped destructive maintenance for IMGenius's own databases.

Catalog characters are identified by persistent seed IDs, not display names.
Nova and Atlas are tracked in their own registry.  Foreign card files and any
image still referenced by another character are never removed.
"""
from __future__ import annotations
import re
import sqlite3
from pathlib import Path

BASE_NAMES = frozenset({'nova', 'atlas'})
OWNED_PORTRAIT = re.compile(r'^(?:portrait_[0-9a-f]{16}|auto_avatar_\d+|character_\d+_[0-9a-f]{16,32})\.png$', re.IGNORECASE)


def ensure_base_registry(store):
    """Record the original bundled Nova/Atlas identities without changing profiles.

    Existing installs have no origin column for these two.  Their first
    recognized named rows are captured once; later renames remain protected.
    The 200 catalog models are separately tracked by character_seed_registry.
    """
    with store.conn:
        store.conn.execute('''CREATE TABLE IF NOT EXISTS base_character_registry (
            name TEXT PRIMARY KEY, character_id INTEGER NOT NULL)''')
        existing = {str(name).casefold() for name, _ in store.conn.execute(
            'SELECT name, character_id FROM base_character_registry')}
        for name in BASE_NAMES - existing:
            # Old installs might have a custom character named Nova/Atlas.  Favor
            # preservation rather than risk deleting it when provenance is absent.
            row = store.conn.execute(
                'SELECT id FROM characters WHERE lower(name)=? ORDER BY id ASC LIMIT 1',
                (name,),
            ).fetchone()
            if row:
                store.conn.execute(
                    'INSERT OR IGNORE INTO base_character_registry(name, character_id) VALUES (?, ?)',
                    (name, row[0]),
                )


def protected_character_ids(store):
    ensure_base_registry(store)
    ids = {int(row[0]) for row in store.conn.execute(
        'SELECT character_id FROM base_character_registry')}
    registry = store.conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='character_seed_registry'"
    ).fetchone()
    if registry:
        ids.update(int(row[0]) for row in store.conn.execute(
            'SELECT character_id FROM character_seed_registry WHERE character_id IS NOT NULL'))
    return ids


def custom_character_summary(store):
    rows = store.conn.execute('SELECT id FROM characters').fetchall()
    protected = protected_character_ids(store)
    custom = [int(row[0]) for row in rows if int(row[0]) not in protected]
    return {'custom_count': len(custom), 'base_count': len(rows) - len(custom)}


def delete_custom_characters(store, card_dir):
    """Delete only non-catalog character rows and unshared owned artwork.

    This does *not* delete conversations, stories or original imported PNG files
    outside IMGenius's managed character_cards directory.
    """
    protected = protected_character_ids(store)
    rows = store.conn.execute('SELECT id, card_image FROM characters').fetchall()
    to_remove = [(int(ident), image) for ident, image in rows if int(ident) not in protected]
    if not to_remove:
        return {'deleted': 0, 'retained': len(rows), 'portraits_deleted': 0}
    card_dir = Path(card_dir).resolve()
    candidates = set()
    for _ident, image in to_remove:
        if not image:
            continue
        path = Path(image)
        if not path.is_absolute():
            path = card_dir / path.name
        path = path.resolve()
        if path.parent == card_dir and OWNED_PORTRAIT.fullmatch(path.name):
            candidates.add(path)
    with store.conn:
        for ident, _image in to_remove:
            store.conn.execute('DELETE FROM characters WHERE id=?', (ident,))
    remaining_images = set()
    for (image,) in store.conn.execute('SELECT card_image FROM characters WHERE card_image IS NOT NULL'):
        if image:
            p = Path(image)
            if not p.is_absolute():
                p = card_dir / p.name
            remaining_images.add(p.resolve())
    deleted_portraits = 0
    for path in candidates - remaining_images:
        try:
            path.unlink(missing_ok=True)
            deleted_portraits += 1
        except OSError:
            # The database action must not fail if an image is still open/locked.
            pass
    return {'deleted': len(to_remove), 'retained': len(rows) - len(to_remove),
            'portraits_deleted': deleted_portraits}


def clear_all_chats(store):
    """Remove all IMGenius chat rows and messages (including orphan messages).

    Do not touch other apps, character definitions, model files or image output.
    SQLite secure_delete/VACUUM prevents chat content remaining in freed pages.
    """
    chats = store.conn.execute('SELECT COUNT(*) FROM chats').fetchone()[0]
    messages = store.conn.execute('SELECT COUNT(*) FROM messages').fetchone()[0]
    store.conn.execute('PRAGMA secure_delete=ON')
    with store.conn:
        store.conn.execute('DELETE FROM messages')
        if store.conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='chat_images'").fetchone():
            store.conn.execute('DELETE FROM chat_images')
        store.conn.execute('DELETE FROM chats')
        store.conn.execute("DELETE FROM sqlite_sequence WHERE name IN ('chats', 'messages')")
    store.conn.execute('VACUUM')
    return {'chats_deleted': chats, 'messages_deleted': messages}
