"""Permanent, scoped deletion of a user-added character and its conversations.

Characters and chats live in separate SQLite files. ATTACH allows their records
and associated messages/images to be removed in one transaction. This feature
never touches imported source files or shared gallery output.
"""
from __future__ import annotations

from pathlib import Path

from imgenius.data.cleanup import protected_character_ids
from imgenius.shared.paths import BUNDLED_PORTRAITS


def delete_character_with_chats(characters, chats, character_id, card_dir):
    """Remove one custom character with all matching chat records.

    The two SQLite stores must be file backed (as in normal IMGenius installs).
    Returns a count summary; protected and unknown identities are not deleted.
    Chat scene images remain available as files in the user's image gallery,
    just as when an individual chat is deleted.
    """
    character_id = int(character_id)
    if character_id in protected_character_ids(characters):
        raise ValueError('Bundled and catalog characters cannot be deleted here.')

    character = characters.get_character(character_id)
    if character is None:
        return {'deleted': 0, 'chats_deleted': 0, 'messages_deleted': 0,
                'chat_ids': (), 'portraits_deleted': 0}
    if characters.conn.in_transaction or chats.conn.in_transaction:
        raise RuntimeError('Finish the current database operation before deleting.')
    if str(characters.db_path) == ':memory:' or str(chats.db_path) == ':memory:':
        raise ValueError('Deletion requires the application\'s file-backed databases.')

    # Attach is a connection-local alias, not a permanent schema migration.
    # The default rollback-journal configuration allows atomic multi-file commits.
    conn = characters.conn
    conn.execute('ATTACH DATABASE ? AS delete_chat_db', (str(chats.db_path),))
    chat_ids = ()
    messages = 0
    try:
        conn.execute('PRAGMA secure_delete=ON')
        conn.execute('PRAGMA delete_chat_db.secure_delete=ON')
        with conn:
            chat_ids = tuple(row[0] for row in conn.execute(
                'SELECT id FROM delete_chat_db.chats WHERE character_id=?', (character_id,)))
            messages = conn.execute(
                'SELECT COUNT(*) FROM delete_chat_db.messages WHERE chat_id IN '
                '(SELECT id FROM delete_chat_db.chats WHERE character_id=?)',
                (character_id,)).fetchone()[0]
            conn.execute(
                'DELETE FROM delete_chat_db.messages WHERE chat_id IN '
                '(SELECT id FROM delete_chat_db.chats WHERE character_id=?)', (character_id,))
            conn.execute(
                'DELETE FROM delete_chat_db.chat_images WHERE chat_id IN '
                '(SELECT id FROM delete_chat_db.chats WHERE character_id=?)', (character_id,))
            conn.execute('DELETE FROM delete_chat_db.chats WHERE character_id=?', (character_id,))
            cursor = conn.execute('DELETE FROM characters WHERE id=?', (character_id,))
            if cursor.rowcount != 1:
                raise RuntimeError('The character could not be deleted; changes were rolled back.')
    finally:
        # DETACH only after the transaction has committed or rolled back.
        conn.execute('DETACH DATABASE delete_chat_db')

    # IMGenius-owned character artwork is removed only when it is inside the
    # managed card folder, not bundled, and not referenced by another character.
    card_dir = Path(card_dir).resolve()
    raw_image = character.get('card_image')
    deleted_portrait = 0
    if raw_image:
        source = Path(raw_image)
        portrait = (source if source.is_absolute() else card_dir / source.name).resolve()
        bundled = {path.name.casefold() for path in BUNDLED_PORTRAITS.glob('*') if path.is_file()}
        if portrait.parent == card_dir and portrait.name.casefold() not in bundled:
            referenced = False
            for (other,) in conn.execute('SELECT card_image FROM characters WHERE card_image IS NOT NULL'):
                if not other:
                    continue
                other_path = Path(other)
                resolved = (other_path if other_path.is_absolute() else card_dir / other_path.name).resolve()
                if resolved == portrait:
                    referenced = True
                    break
            if not referenced:
                try:
                    if portrait.is_file():
                        portrait.unlink()
                        deleted_portrait = 1
                except OSError:
                    # Records are already committed; never mask successful data deletion.
                    pass
    return {'deleted': 1, 'chats_deleted': len(chat_ids),
            'messages_deleted': messages, 'chat_ids': chat_ids,
            'portraits_deleted': deleted_portrait}
