"""Data components for IMGenius."""
