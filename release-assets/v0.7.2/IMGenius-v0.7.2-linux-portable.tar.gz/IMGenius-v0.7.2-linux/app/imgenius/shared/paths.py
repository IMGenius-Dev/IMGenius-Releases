"""App installation paths versus persistent, user-owned data paths.

Never store writable files in the installed package or overwrite existing user data.
"""
import os
import sys
import shutil
from pathlib import Path

PACKAGE_DIR = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[2]))
ASSET_DIR = PACKAGE_DIR / 'assets'
BUNDLED_PORTRAITS = ASSET_DIR / 'characters'  # Legacy reference: never packaged

def get_user_data_dir():
    """Persistent writable data outside installed program files."""
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local'))
    else:
        base = Path(os.environ.get('XDG_DATA_HOME') or (Path.home() / '.local' / 'share'))
    return base / 'IMGenius'

DATA_DIR = get_user_data_dir()


def normalize_comfy_root(value):
    """Accept ComfyUI root and Windows portable parent directory alike."""
    root = Path(value).expanduser()
    if (root / 'main.py').is_file():
        return root
    if (root / 'ComfyUI' / 'main.py').is_file():
        return root / 'ComfyUI'
    return root

def default_comfy_root():
    """Discover existing installations without overwriting their models or settings.

    Portable Windows ComfyUI is nested under ComfyUI_windows_portable/ComfyUI;
    returns the actual directory containing main.py and models/.
    """
    home = Path.home()
    managed = DATA_DIR / 'engines' / 'ComfyUI'
    candidates = [managed, home / 'ComfyUI']
    if os.name == 'nt':
        candidates += [
            home / 'ComfyUI_windows_portable' / 'ComfyUI',
            home / 'Downloads' / 'ComfyUI_windows_portable' / 'ComfyUI',
            home / 'Documents' / 'ComfyUI',
        ]
    for candidate in candidates:
        if (candidate / 'main.py').is_file():
            return candidate
    return managed

DATA_DIR.mkdir(parents=True, exist_ok=True)
CARD_DIR = DATA_DIR / 'character_cards'
CARD_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / 'app.db'
PERSONA_PATH = DATA_DIR / 'personas.json'

# The distributable never migrates packaged user databases or character art.
# Users' historical files in DATA_DIR are preserved across upgrades.
