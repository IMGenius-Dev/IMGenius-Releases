"""Safe user text and named prompt token substitution."""

def safe_text(value, default=''):
    if value is None:
        return default
    return str(value).strip() if isinstance(value, str) else str(value)

def apply_tokens(value, user_name='User', char_name='Assistant'):
    text = safe_text(value)
    if not text:
        return text
    replacements = {
        '{{user}}': safe_text(user_name, 'User') or 'User',
        '{{char}}': safe_text(char_name, 'Assistant') or 'Assistant',
    }
    for key, replacement in replacements.items():
        text = text.replace(key, replacement)
        text = text.replace(key.upper(), replacement)
        text = text.replace(key.title(), replacement)
    return text
