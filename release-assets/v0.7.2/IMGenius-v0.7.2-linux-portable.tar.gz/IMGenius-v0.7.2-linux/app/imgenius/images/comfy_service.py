"""Manage an IMGenius-started local ComfyUI process, never a user's existing server.

This module has no Qt dependencies, so process ownership and path safety can be tested
on Windows and Linux independently of the GUI.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import urlopen

from imgenius.shared.paths import DATA_DIR, default_comfy_root, normalize_comfy_root


def is_local_comfy_url(url: str) -> bool:
    try:
        parts = urlsplit(url)
        return parts.scheme == 'http' and parts.hostname in ('127.0.0.1', 'localhost', '::1') and bool(parts.port)
    except ValueError:
        return False


def existing_comfy(url: str, timeout: float = 0.6) -> bool:
    """Only a responsive ComfyUI system_stats endpoint counts as an existing server."""
    if not is_local_comfy_url(url):
        return False
    try:
        with urlopen(url.rstrip('/') + '/system_stats', timeout=timeout) as reply:
            return reply.status == 200 and b'devices' in reply.read(32768)
    except (OSError, ValueError):
        return False


def comfy_python(root: Path, *, platform=None, executable=None) -> Path | None:
    """Find this ComfyUI's Python, not the frozen IMGenius executable."""
    root = Path(root).expanduser()
    windows = (os.name == 'nt') if platform is None else platform == 'win32'
    if windows:
        candidates = [root / '.venv/Scripts/python.exe', root / 'venv/Scripts/python.exe',
                      root.parent / 'python_embeded/python.exe',
                      root.parent / 'python_embedded/python.exe']
    else:
        candidates = [root / '.venv/bin/python', root / 'venv/bin/python3',
                      root / 'venv/bin/python', root / '.venv/bin/python3']
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    # Source checkouts can reuse the app development interpreter but never frozen exe.
    if executable is None:
        executable = sys.executable
    if not getattr(sys, 'frozen', False) and (root / 'main.py').is_file():
        return Path(executable)
    return None


class ManagedComfyUI:
    def __init__(self):
        self.process = None
        self._log = None
        self.message = 'Not started'

    def start(self, root=None, url='http://127.0.0.1:8188') -> bool:
        """Start only when an installed local ComfyUI is not already running."""
        if self.process is not None and self.process.poll() is None:
            return True
        # A previous owned process may have exited during initialization.
        # Release its log before a user-requested retry starts a new process.
        if self.process is not None:
            self.process = None
            if self._log is not None:
                self._log.close()
                self._log = None
        if not is_local_comfy_url(url):
            self.message = 'External ComfyUI URL; process not managed by IMGenius.'
            return False
        if existing_comfy(url):
            self.message = 'Existing ComfyUI server detected; leaving it under user control.'
            return False
        root = normalize_comfy_root(root or default_comfy_root())
        main = root / 'main.py'
        if not main.is_file():
            self.message = 'ComfyUI not installed; run setup to enable automatic startup.'
            return False
        python = comfy_python(root)
        if python is None:
            self.message = 'ComfyUI Python environment missing; use setup to install dependencies.'
            return False
        port = urlsplit(url).port
        (DATA_DIR / 'logs').mkdir(parents=True, exist_ok=True)
        self._log = (DATA_DIR / 'logs/comfyui.log').open('ab')
        try:
            flags = 0
            kwargs = {}
            if os.name == 'nt':
                flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
            else:
                kwargs['start_new_session'] = True
            self.process = subprocess.Popen(
                [str(python), str(main), '--listen', '127.0.0.1', '--port', str(port)],
                cwd=str(root), stdin=subprocess.DEVNULL, stdout=self._log,
                stderr=subprocess.STDOUT, creationflags=flags, **kwargs,
            )
        except OSError as exc:
            self._log.close()
            self._log = None
            self.message = f'Could not start ComfyUI: {exc}'
            return False
        self.message = f'Started managed ComfyUI (PID {self.process.pid}); initializing in background.'
        return True

    def stop(self, timeout: float = 8.0) -> None:
        """Wait for graceful exit; terminate only IMGenius-owned process tree."""
        proc, self.process = self.process, None
        if proc is None:
            return
        try:
            if proc.poll() is None:
                if os.name == 'nt':
                    try:
                        proc.send_signal(signal.CTRL_BREAK_EVENT)
                    except (OSError, ValueError):
                        proc.terminate()
                else:
                    os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    if os.name == 'nt':
                        subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                       timeout=10, check=False)
                    else:
                        os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            self.message = 'ComfyUI shutdown could not be confirmed; inspect the process list.'
        finally:
            if self._log:
                self._log.close()
                self._log = None
