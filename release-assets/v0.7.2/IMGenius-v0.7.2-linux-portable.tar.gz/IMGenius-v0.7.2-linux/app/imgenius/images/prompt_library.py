"""Persistent Image Studio drafts and reusable, named negative prompts.

All writes go to the user's data directory, never the installed source tree.
The backend uses only Python's standard library and can be tested without Qt.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile

from imgenius.shared.paths import DATA_DIR

MAX_PRESETS = 120
MAX_PROMPT_CHARS = 100_000
MAX_NAME_CHARS = 80


class ImagePromptLibrary:
    def __init__(self, path: Path | str | None = None):
        self.path = Path(path) if path is not None else DATA_DIR / 'image_prompts.json'
        self.last_positive = ''
        self.last_negative = ''
        self._presets: dict[str, str] = {}
        self._load()

    def _load(self):
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding='utf-8'))
        except (ValueError, OSError, UnicodeError):
            # Don't destroy the user's original file if it is unreadable.
            return
        if not isinstance(raw, dict):
            return
        for attr, key in [('last_positive', 'positive'), ('last_negative', 'negative')]:
            content = raw.get(key, '')
            if isinstance(content, str):
                setattr(self, attr, content[:MAX_PROMPT_CHARS])
        presets = raw.get('negative_presets', {})
        if isinstance(presets, dict):
            for name, content in presets.items():
                if (isinstance(name, str) and isinstance(content, str)
                        and 0 < len(name.strip()) <= MAX_NAME_CHARS):
                    self._presets[name.strip()] = content[:MAX_PROMPT_CHARS]
                    if len(self._presets) >= MAX_PRESETS:
                        break

    @property
    def negative_presets(self) -> dict[str, str]:
        return dict(self._presets)

    def get_negative_preset(self, name: str) -> str | None:
        return self._presets.get(name)

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'version': 1,
            'positive': self.last_positive,
            'negative': self.last_negative,
            'negative_presets': self._presets,
        }
        payload = json.dumps(data, indent=2, ensure_ascii=False)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=self.path.parent,
                                             prefix='.image-prompts-', suffix='.tmp',
                                             delete=False) as tmp:
                temporary = Path(tmp.name)
                tmp.write(payload)
                tmp.flush()
                os.fsync(tmp.fileno())
            os.replace(temporary, self.path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def update_drafts(self, positive: str, negative: str):
        if not isinstance(positive, str) or not isinstance(negative, str):
            raise ValueError('Image prompts must be text.')
        if len(positive) > MAX_PROMPT_CHARS or len(negative) > MAX_PROMPT_CHARS:
            raise ValueError('Prompt exceeds the maximum supported length.')
        if positive == self.last_positive and negative == self.last_negative:
            return
        self.last_positive = positive
        self.last_negative = negative
        self._save()

    def save_negative_preset(self, name: str, text: str, *, replace: bool = False):
        name = str(name).strip()
        if not name or len(name) > MAX_NAME_CHARS:
            raise ValueError('Give the preset a name of 1–80 characters.')
        if not isinstance(text, str) or not text.strip():
            raise ValueError('Enter a negative prompt before saving the preset.')
        if len(text) > MAX_PROMPT_CHARS:
            raise ValueError('Negative prompt is too long.')
        if name in self._presets and not replace:
            raise ValueError('A preset with that name already exists.')
        if name not in self._presets and len(self._presets) >= MAX_PRESETS:
            raise ValueError('The negative-prompt library is full.')
        self._presets[name] = text
        self._save()

    def delete_negative_preset(self, name: str) -> bool:
        if name not in self._presets:
            return False
        del self._presets[name]
        self._save()
        return True
