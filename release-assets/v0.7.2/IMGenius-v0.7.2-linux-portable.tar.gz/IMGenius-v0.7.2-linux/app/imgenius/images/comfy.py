"""Direct local Ollama and ComfyUI integration. No Flask, no browser UI."""
from __future__ import annotations
import json
import random
import threading
import time
import uuid
from pathlib import Path

import requests
from imgenius.domain import DATA_DIR, safe_text

class Cancelled(Exception):
    pass


def ollama_models(base_url: str) -> list[dict]:
    r = requests.get(f'{base_url.rstrip("/")}/api/tags', timeout=10)
    r.raise_for_status()
    return r.json().get('models', [])


def ollama_chat(base_url, model, system, messages, options=None, on_token=None, cancel=None,
                preserve_partial_on_cancel=False):
    """Stream Ollama's /api/chat; output token callbacks from a worker thread.

    When preserving a stopped chat, return exactly the tokens already received.
    Other callers retain the existing Cancelled exception behavior.
    """
    cancel = cancel or threading.Event()
    opts = {k: v for k, v in (options or {}).items() if v is not None}
    conversation = [{'role': 'system', 'content': system}] + [
        {'role': m['role'], 'content': m['content']}
        for m in messages if m.get('role') in ('user', 'assistant')
    ]
    with requests.post(f'{base_url.rstrip("/")}/api/chat',
                       json={'model': model, 'messages': conversation, 'options': opts, 'stream': True},
                       stream=True, timeout=(10, 180)) as response:
        response.raise_for_status()
        chunks = []
        for line in response.iter_lines():
            if cancel.is_set():
                if preserve_partial_on_cancel:
                    return ''.join(chunks)
                raise Cancelled('Response stopped.')
            if not line:
                continue
            packet = json.loads(line)
            if packet.get('error'):
                raise RuntimeError(packet['error'])
            text = packet.get('message', {}).get('content', '')
            if text:
                chunks.append(text)
                if on_token:
                    on_token(text)
            if packet.get('done'):
                break
        return ''.join(chunks)


def comfy_object_info(base_url):
    response = requests.get(f'{base_url.rstrip("/")}/object_info', timeout=15)
    response.raise_for_status()
    return response.json()


def comfy_choices(object_info, node, input_name):
    try:
        value = object_info[node]['input']['required'][input_name][0]
        return [str(v) for v in value] if isinstance(value, list) else []
    except (KeyError, TypeError, IndexError):
        return []


def build_workflow(*, model, prompt, negative_prompt='', width=1024, height=1024,
                   steps=28, cfg=6.0, sampler='dpmpp_2m', scheduler='karras',
                   seed=None, mode='txt2img', input_filename=None, denoise=0.55,
                   loras=None, clip_skip=1, batch=1, upscale=1.0,
                   refine_steps=12, refine_denoise=0.30):
    """Standard ComfyUI API graph for SDXL/Illustrious; no custom nodes required.

    Img2img uses ComfyUI's LoadImage -> ImageScale -> VAEEncode path.
    Optional second pass uses LatentUpscale and a second KSampler.
    """
    if not model:
        raise ValueError('Choose an installed checkpoint.')
    if not prompt or not prompt.strip():
        raise ValueError('Enter a positive prompt.')
    if mode not in ('txt2img', 'img2img'):
        raise ValueError('Unknown image mode.')
    width, height = int(width), int(height)
    if not (256 <= width <= 2048 and 256 <= height <= 2048 and width % 8 == 0 and height % 8 == 0):
        raise ValueError('Image dimensions must be multiples of 8 between 256 and 2048.')
    if mode == 'img2img' and not input_filename:
        raise ValueError('Choose a source image for img2img.')
    if not 0.0 < float(denoise) <= 1.0:
        raise ValueError('Denoise must be greater than zero and at most 1.')
    if not (1 <= int(batch) <= 4):
        raise ValueError('Batch size must be 1–4.')
    if int(steps) < 1 or int(refine_steps) < 1:
        raise ValueError('Sampling steps must be positive.')
    if seed is not None and int(seed) >= 2**64:
        raise ValueError('Seed is outside the supported range.')
    if not (1.0 <= float(upscale) <= 2.0):
        raise ValueError('Refine scale must be between 1.0 and 2.0.')
    if float(upscale) > 1.0 and not (0.0 < float(refine_denoise) <= 1.0):
        raise ValueError('Refine denoise must be greater than zero and at most 1.')
    graph = {'1': {'class_type': 'CheckpointLoaderSimple', 'inputs': {'ckpt_name': model}}}
    model_link, clip_link, vae_link = ['1', 0], ['1', 1], ['1', 2]
    index = 2
    for entry in (loras or []):
        name = safe_text(entry.get('name'))
        if not name:
            continue
        strength = float(entry.get('strength', 0.7))
        graph[str(index)] = {'class_type': 'LoraLoader', 'inputs': {
            'lora_name': name, 'strength_model': strength, 'strength_clip': strength,
            'model': model_link, 'clip': clip_link}}
        model_link, clip_link = [str(index), 0], [str(index), 1]
        index += 1
    if int(clip_skip) > 1:
        graph[str(index)] = {'class_type': 'CLIPSetLastLayer', 'inputs': {
            'clip': clip_link, 'stop_at_clip_layer': -int(clip_skip)}}
        clip_link = [str(index), 0]
        index += 1
    pos_id, neg_id = str(index), str(index + 1)
    graph[pos_id] = {'class_type': 'CLIPTextEncode', 'inputs': {'clip': clip_link, 'text': prompt}}
    graph[neg_id] = {'class_type': 'CLIPTextEncode', 'inputs': {'clip': clip_link, 'text': negative_prompt}}
    index += 2
    if mode == 'img2img':
        load_id, resize_id, latent_id = str(index), str(index + 1), str(index + 2)
        graph[load_id] = {'class_type': 'LoadImage', 'inputs': {'image': input_filename}}
        graph[resize_id] = {'class_type': 'ImageScale', 'inputs': {
            'image': [load_id, 0], 'upscale_method': 'lanczos',
            'width': width, 'height': height, 'crop': 'center'}}
        graph[latent_id] = {'class_type': 'VAEEncode', 'inputs': {'pixels': [resize_id, 0], 'vae': vae_link}}
        index += 3
        if int(batch) > 1:
            repeat_id = str(index)
            graph[repeat_id] = {'class_type': 'RepeatLatentBatch', 'inputs': {
                'samples': [latent_id, 0], 'amount': int(batch)}}
            latent_id = repeat_id
            index += 1
        strength = float(denoise)
    else:
        latent_id = str(index)
        graph[latent_id] = {'class_type': 'EmptyLatentImage', 'inputs': {
            'width': width, 'height': height, 'batch_size': int(batch)}}
        index += 1
        strength = 1.0
    sampler_id = str(index)
    seed_value = random.randrange(0, 2**53) if seed is None or int(seed) < 0 else int(seed)
    graph[sampler_id] = {'class_type': 'KSampler', 'inputs': {
        'model': model_link, 'positive': [pos_id, 0], 'negative': [neg_id, 0],
        'latent_image': [latent_id, 0], 'seed': seed_value,
        'steps': int(steps), 'cfg': float(cfg), 'sampler_name': sampler,
        'scheduler': scheduler, 'denoise': strength}}
    index += 1
    result_latent = [sampler_id, 0]
    if float(upscale) > 1.0:
        scaled_id, second_id = str(index), str(index + 1)
        graph[scaled_id] = {'class_type': 'LatentUpscale', 'inputs': {
            'samples': result_latent, 'upscale_method': 'bislerp',
            'width': max(8, round(width * float(upscale) / 8) * 8),
            'height': max(8, round(height * float(upscale) / 8) * 8), 'crop': 'disabled'}}
        graph[second_id] = {'class_type': 'KSampler', 'inputs': {
            'model': model_link, 'positive': [pos_id, 0], 'negative': [neg_id, 0],
            'latent_image': [scaled_id, 0], 'seed': seed_value, 'steps': int(refine_steps),
            'cfg': float(cfg), 'sampler_name': sampler, 'scheduler': scheduler,
            'denoise': float(refine_denoise)}}
        result_latent = [second_id, 0]
        index += 2
    decode_id, save_id = str(index), str(index + 1)
    graph[decode_id] = {'class_type': 'VAEDecode', 'inputs': {'samples': result_latent, 'vae': vae_link}}
    graph[save_id] = {'class_type': 'SaveImage', 'inputs': {
        'filename_prefix': 'IMGenius', 'images': [decode_id, 0]}}
    return graph


def upload_image(base_url, filepath):
    file = Path(filepath)
    if not file.is_file():
        raise FileNotFoundError(file)
    with file.open('rb') as f:
        response = requests.post(f'{base_url.rstrip("/")}/upload/image',
                                 files={'image': (file.name, f, 'application/octet-stream')},
                                 data={'type': 'input', 'overwrite': 'false'}, timeout=60)
    response.raise_for_status()
    result = response.json()
    if not result.get('name'):
        raise RuntimeError('ComfyUI did not accept the uploaded image.')
    subfolder = result.get('subfolder') or ''
    return f'{subfolder}/{result["name"]}' if subfolder else result['name']


def generate_image(base_url, workflow, on_status=None, cancel=None, timeout_seconds=600):
    """Queue -> poll /history -> fetch /view bytes. Handles ComfyUI execution errors."""
    cancel = cancel or threading.Event()
    base = base_url.rstrip('/')
    response = requests.post(f'{base}/prompt', json={'prompt': workflow, 'client_id': str(uuid.uuid4())}, timeout=30)
    response.raise_for_status()
    packet = response.json()
    if packet.get('error'):
        raise RuntimeError(f'ComfyUI: {packet["error"]}')
    prompt_id = packet.get('prompt_id')
    if not prompt_id:
        raise RuntimeError('ComfyUI did not return a prompt ID. Check missing nodes/models.')
    if on_status:
        on_status(f'Queued as {prompt_id[:8]}…')
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if cancel.is_set():
            # Local wait cancellation only. Do not interrupt unrelated ComfyUI jobs.
            raise Cancelled('Stopped waiting. The ComfyUI job may still be running.')
        reply = requests.get(f'{base}/history/{prompt_id}', timeout=20)
        reply.raise_for_status()
        job = reply.json().get(prompt_id)
        if job:
            status = job.get('status', {})
            if status.get('status_str') == 'error' or status.get('completed') is False:
                messages = status.get('messages', [])
                details = str(messages[-1])[:800] if messages else 'Check the ComfyUI console.'
                raise RuntimeError(f'ComfyUI execution failed. {details}')
            imgs = [img for output in job.get('outputs', {}).values() if isinstance(output, dict)
                    for img in output.get('images', []) if isinstance(img, dict)]
            if imgs:
                results = []
                for img in imgs:
                    params = {'filename': img['filename'], 'subfolder': img.get('subfolder', ''),
                              'type': img.get('type', 'output')}
                    raw = requests.get(f'{base}/view', params=params, timeout=60)
                    raw.raise_for_status()
                    results.append((img['filename'], raw.content))
                return prompt_id, results
        if cancel.wait(1.0):
            raise Cancelled('Stopped waiting. The ComfyUI job may still be running.')
    raise TimeoutError('Timed out waiting for ComfyUI. Check the queue and console.')


def save_outputs(prompt_id, results):
    folder = DATA_DIR / 'images'
    folder.mkdir(parents=True, exist_ok=True)
    files = []
    for index, (filename, data) in enumerate(results):
        extension = Path(filename).suffix.lower()
        if extension not in ('.png', '.jpg', '.jpeg', '.webp'):
            extension = '.png'
        target = folder / f'{prompt_id}_{index}{extension}'
        target.write_bytes(data)
        files.append(target)
    return files
