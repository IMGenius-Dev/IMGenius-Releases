"""Character portrait workflow: Ollama prompt writing -> native ComfyUI API.

No new dependencies. The application calls this from a QThreadPool worker and
commits the returned portrait to the selected character on the GUI thread.
"""
from __future__ import annotations

from io import BytesIO
from pathlib import Path
import re
import threading
import uuid

from PIL import Image, ImageOps

from imgenius.domain import CARD_DIR, safe_text
from imgenius.images.comfy import (
    Cancelled, ollama_chat, comfy_object_info, comfy_choices,
    build_workflow, generate_image,
)

PORTRAIT_NEGATIVE = (
    'low quality, worst quality, blurry, out of focus, low resolution, '
    'watermark, text, signature, logo, duplicate face, extra arms, extra hands, '
    'distorted anatomy, deformed hands, badly drawn face, cropped head'
)

AVATAR_SYSTEM = (
    'You are a visual art director creating a high-quality Stable Diffusion XL / '
    'Illustrious XL character portrait prompt. Convert the supplied fictional '
    'character profile to ONE detailed positive image prompt. Preserve explicitly '
    'stated physical traits, species, gender presentation, clothing, and setting. '
    'For unspecified appearance, invent a coherent design matching the personality '
    'and scenario. Compose a polished single-character portrait, waist-up or '
    'three-quarter framing, clearly visible face, attractive lighting, detailed '
    'background, consistent anatomy. Describe visible things only; no story or '
    'conversation. Return ONLY the positive image prompt, as plain text: no '
    'markdown, explanation, quotation marks, negative prompt, or preface. '
    'Keep it under 140 words.'
)

PROFILE_FIELDS = (
    ('Name', 'name'), ('Gender', 'gender'), ('Age', 'age'),
    ('Description', 'short_description'), ('Personality', 'personality'),
    ('Scenario', 'scenario'), ('Example dialogue', 'example_dialogue'),
    ('Tags', 'tags'),
)


def describe_avatar_character(character):
    """Include only current profile fields, not archived instructions or memories."""
    lines = []
    for title, key in PROFILE_FIELDS:
        value = safe_text((character or {}).get(key))
        if value:
            lines.append(f'{title}: {value[:1800]}')
    if not safe_text((character or {}).get('name')):
        raise ValueError('Save a character with a name before generating a portrait.')
    return '\n'.join(lines)


def clean_avatar_prompt(text):
    """Strip common LLM wrappers without changing its visual content."""
    text = safe_text(text)
    text = re.sub(r'^```(?:text|markdown|prompt)?\s*|\s*```$', '', text, flags=re.I).strip()
    text = re.sub(r'^(?:positive\s+)?(?:image\s+)?prompt\s*:\s*', '', text, flags=re.I)
    text = text.strip(' \t\r\n"\'`')
    text = re.sub(r'\s+', ' ', text)
    if not text:
        raise ValueError('The Ollama model returned an empty portrait prompt.')
    return text[:1800]


def select_avatar_checkpoint(info, preferred=''):
    """Use selected checkpoint if available, else a plausible SDXL/IL checkpoint."""
    checkpoints = comfy_choices(info, 'CheckpointLoaderSimple', 'ckpt_name')
    if not checkpoints:
        raise ValueError('ComfyUI has no checkpoints available. Install an SDXL or Illustrious checkpoint first.')
    if preferred in checkpoints:
        return preferred
    for keyword in ('illustrious', 'sdxl', 'pony'):
        match = next((c for c in checkpoints if keyword in c.casefold()), None)
        if match:
            return match
    return checkpoints[0]


def generate_character_portrait(character, *, ollama_url, model, comfy_url,
                                preferred_checkpoint='', options=None, cancel=None,
                                on_status=None, output_dir=None):
    """Generate and persist a portrait; return (path, generated_prompt, checkpoint).

    The caller owns the character database transaction. This function performs
    no database mutation, preventing failed generations from wiping old art.
    """
    cancel = cancel or threading.Event()
    status = on_status or (lambda _: None)
    if not safe_text(model):
        raise ValueError('Select an installed Ollama chat model before generating a portrait.')
    if cancel.is_set():
        raise Cancelled('Portrait generation cancelled.')
    status('Writing portrait prompt with Ollama…')
    generation_options = dict(options or {})
    generation_options.update({'temperature': 0.65, 'num_predict': 240})
    prompt_response = ollama_chat(
        ollama_url, model, AVATAR_SYSTEM,
        [{'role': 'user', 'content': describe_avatar_character(character)}],
        options=generation_options, cancel=cancel,
    )
    prompt = clean_avatar_prompt(prompt_response)
    if cancel.is_set():
        raise Cancelled('Portrait generation cancelled.')
    status('Loading installed ComfyUI checkpoints…')
    info = comfy_object_info(comfy_url)
    checkpoint = select_avatar_checkpoint(info, preferred_checkpoint)
    if cancel.is_set():
        raise Cancelled('Portrait generation cancelled.')
    illustrative = any(word in checkpoint.casefold() for word in ('illustrious', 'pony'))
    workflow = build_workflow(
        model=checkpoint, prompt=prompt, negative_prompt=PORTRAIT_NEGATIVE,
        width=768, height=1024, batch=1, steps=26,
        cfg=5.0 if illustrative else 6.0,
        sampler='euler_ancestral' if illustrative else 'dpmpp_2m',
        scheduler='normal' if illustrative else 'karras',
        mode='txt2img', upscale=1.0,
    )
    status(f'Generating portrait with ComfyUI ({checkpoint})…')
    _, images = generate_image(comfy_url, workflow, cancel=cancel, on_status=status)
    if cancel.is_set():
        raise Cancelled('Portrait generation cancelled.')
    if not images:
        raise RuntimeError('ComfyUI finished without returning an image.')
    # Convert/verify before writing to user data. Preserve the output aspect ratio.
    image_bytes = images[0][1]
    with Image.open(BytesIO(image_bytes)) as source:
        portrait = ImageOps.exif_transpose(source).convert('RGB')
        portrait.thumbnail((1152, 1536), Image.Resampling.LANCZOS)
        portrait.load()
    folder = Path(output_dir) if output_dir is not None else CARD_DIR
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f'generated_portrait_{uuid.uuid4().hex}.png'
    partial = folder / f'.{target.stem}.partial.png'
    try:
        portrait.save(partial, format='PNG', optimize=True)
        partial.replace(target)
    finally:
        partial.unlink(missing_ok=True)
    status('Portrait ready. Applying it to character…')
    return target, prompt, checkpoint
