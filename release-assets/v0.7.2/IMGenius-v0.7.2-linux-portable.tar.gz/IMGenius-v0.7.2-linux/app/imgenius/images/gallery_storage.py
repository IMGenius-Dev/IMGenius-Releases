"""Safe permanent deletion of IMGenius-owned gallery images.

Never delete a user-imported source image or arbitrary path elsewhere on disk.
The gallery only manages direct children of DATA_DIR / "images".
"""
from __future__ import annotations
from pathlib import Path

from imgenius.ui.layout import IMAGE_EXTENSIONS


def delete_managed_gallery_image(image_path, gallery_dir, chat_store):
    """Delete an on-disk gallery image and remove its references in chat_images.

    Returns the number of chat attachments removed. Refuses symlinks, paths
    outside the gallery, directories, and unsupported file extensions.
    Database references roll back if unlink fails; nothing goes to Trash.
    """
    gallery_dir = Path(gallery_dir).absolute()
    image_path = Path(image_path).absolute()
    if gallery_dir.is_symlink() or image_path.is_symlink():
        raise ValueError('Cannot permanently delete images through symbolic links.')
    if (image_path.parent != gallery_dir
            or image_path.suffix.lower() not in IMAGE_EXTENSIONS):
        raise ValueError('Only images directly inside IMGenius gallery storage can be deleted.')
    if not image_path.is_file():
        raise FileNotFoundError(f'Gallery image no longer exists: {image_path.name}')
    # Re-check the resolved parent to protect against traversal and nested links.
    if image_path.resolve(strict=True).parent != gallery_dir.resolve(strict=True):
        raise ValueError('Image resolves outside IMGenius gallery storage.')
    with chat_store.conn:
        cursor = chat_store.conn.execute(
            'DELETE FROM chat_images WHERE filename = ?', (image_path.name,)
        )
        image_path.unlink()  # immediate filesystem deletion, not the Trash
    return cursor.rowcount
