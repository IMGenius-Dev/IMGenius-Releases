"""Responsive cross-platform startup for IMGenius v0.7.1."""
from __future__ import annotations

import sys
import time
import traceback

from PySide6.QtCore import QObject, QSettings, QThread, QTimer, Signal, QUrl
from PySide6.QtGui import QFont, QFontDatabase, QIcon, QDesktopServices
from PySide6.QtWidgets import QApplication, QMessageBox

from imgenius import __version__
from imgenius.images.comfy_service import ManagedComfyUI, existing_comfy, is_local_comfy_url
from imgenius.shared.paths import default_comfy_root, normalize_comfy_root
from imgenius.updates import check_github_updates
from imgenius.domain import (
    PersonaStore, cleanup_example_characters, ensure_default_character_images,
    save_default_characters,
)
from imgenius.characters.seeds import seed_character_catalog
from imgenius.ui.brand_assets import app_icon_path
from imgenius.ui.main_window import MainWindow
from imgenius.ui.splash import StartupSplash
from imgenius.ui.styles import STYLE
from imgenius.ui.themes import THEMES, build_theme_stylesheet


STARTUP_STEPS = (
    ('Preparing character library...', save_default_characters),
    ('Loading character catalog...', seed_character_catalog),
    ('Loading personas...', PersonaStore),
    ('Preparing character portraits...', ensure_default_character_images),
)


class StartupWorker(QThread):
    progress = Signal(str)
    ready = Signal()
    failed = Signal(str)

    def __init__(self, channel='beta', parent=None):
        super().__init__(parent)
        self.channel = channel
        self.update_result = None

    def run(self):
        try:
            self.progress.emit('Checking GitHub for updates...')
            self.update_result = check_github_updates(current=__version__, channel=self.channel)
            if self.update_result.state == 'unavailable':
                self.progress.emit('Update check unavailable; continuing offline...')
            for label, task in STARTUP_STEPS:
                self.progress.emit(label)
                task()
        except Exception:
            self.failed.emit(traceback.format_exc())
        else:
            self.ready.emit()


class ComfyReadinessWorker(QThread):
    """Poll backend health without freezing the animated splash or UI."""
    progress = Signal(str)
    ready = Signal()
    failed = Signal(str)

    def __init__(self, url, timeout_seconds=120, process=None, parent=None):
        super().__init__(parent)
        self.url = url
        self.timeout_seconds = timeout_seconds
        self.process = process

    def run(self):
        deadline = time.monotonic() + self.timeout_seconds
        last_second = -1
        while time.monotonic() < deadline:
            if self.isInterruptionRequested():
                return
            if existing_comfy(self.url, timeout=0.8):
                self.ready.emit()
                return
            if self.process is not None and self.process.poll() is not None:
                self.failed.emit('ComfyUI exited during startup. Check the ComfyUI log.')
                return
            remaining = max(0, int(deadline - time.monotonic()))
            if remaining != last_second and remaining % 5 == 0:
                self.progress.emit(f'Waiting for ComfyUI to finish starting... ({remaining}s)')
                last_second = remaining
            self.msleep(500)
        self.failed.emit('ComfyUI did not become ready before the startup timeout.')


class StartupController(QObject):
    """Keep the splash visible until the update check and ComfyUI gate finish."""

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.splash = StartupSplash()
        self.settings = QSettings('IMGenius', 'IMGenius')
        channel = str(self.settings.value('update_channel', 'beta'))
        self.worker = StartupWorker(channel if channel in ('beta', 'stable') else 'beta', self)
        self.wait_worker = None
        self.main_window = None
        self.comfy_service = ManagedComfyUI()
        self.comfy_url = ''
        self.comfy_problem = ''
        self.app.aboutToQuit.connect(self._shutdown)
        self.worker.progress.connect(self.splash.set_status)
        self.worker.ready.connect(self._prepare_comfy)
        self.worker.failed.connect(self._show_error)

    def start(self):
        self.splash.show_animated()
        QTimer.singleShot(0, self.worker.start)

    def _prepare_comfy(self):
        result = self.worker.update_result
        if result is not None and result.state == 'available':
            self.splash.set_status('An IMGenius update is available!')
            self._show_update_notice(result.tag, result.url)

        self.splash.set_status('Starting ComfyUI...')
        self.comfy_url = str(self.settings.value('comfy_url', 'http://127.0.0.1:8188'))
        if not is_local_comfy_url(self.comfy_url):
            self._comfy_failed('ComfyUI is set to a remote URL; it cannot be started locally.')
            return
        root = normalize_comfy_root(str(self.settings.value('comfy_root', str(default_comfy_root()))))
        if not (root / 'main.py').is_file():
            root = default_comfy_root()
        self.comfy_service.start(root, self.comfy_url)
        self._wait_for_comfy()

    def _wait_for_comfy(self):
        # Check for pre-existing (user-owned) instances as well as our own process.
        if self.wait_worker is not None and self.wait_worker.isRunning():
            return
        if existing_comfy(self.comfy_url):
            self._open_window()
            return
        if self.comfy_service.process is None:
            self._comfy_failed(self.comfy_service.message)
            return
        try:
            seconds = int(self.settings.value('comfy_startup_timeout_seconds', 120))
        except (TypeError, ValueError):
            seconds = 120
        seconds = min(max(seconds, 15), 300)
        self.splash.set_status('Waiting for ComfyUI to finish starting...')
        self.wait_worker = ComfyReadinessWorker(self.comfy_url, seconds,
                                                 self.comfy_service.process, self)
        self.wait_worker.progress.connect(self.splash.set_status)
        self.wait_worker.ready.connect(self._comfy_ready)
        self.wait_worker.failed.connect(self._comfy_failed)
        self.wait_worker.start()

    def _comfy_ready(self):
        self.splash.set_status('ComfyUI ready. Opening IMGenius...')
        self.comfy_service.message = 'ComfyUI ready'
        self._open_window()

    def _comfy_failed(self, reason):
        self.comfy_problem = str(reason)
        self.splash.set_status('ComfyUI unavailable; your choice is required...')
        msg = QMessageBox(self.splash)
        msg.setWindowTitle('ComfyUI not ready')
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setText('IMGenius could not confirm that ComfyUI is ready.')
        msg.setInformativeText(self.comfy_problem + '\n\nYou can retry, or enter IMGenius without image generation.')
        retry = msg.addButton('Retry', QMessageBox.ButtonRole.AcceptRole)
        skip = msg.addButton('Continue without images', QMessageBox.ButtonRole.ActionRole)
        exit_button = msg.addButton('Exit IMGenius', QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(retry)
        msg.exec()
        if msg.clickedButton() == retry:
            self.splash.set_status('Retrying ComfyUI startup...')
            self._prepare_comfy_retry()
        elif msg.clickedButton() == skip:
            self._open_window()
        else:
            self._shutdown()
            self.splash.close()
            self.app.quit()

    def _prepare_comfy_retry(self):
        # If the owned process crashed, start a fresh one; if it is still
        # alive, retry health checks without creating a duplicate.
        if self.comfy_service.process is None or self.comfy_service.process.poll() is not None:
            root = normalize_comfy_root(str(self.settings.value('comfy_root', str(default_comfy_root()))))
            if not (root / 'main.py').is_file():
                root = default_comfy_root()
            self.comfy_service.start(root, self.comfy_url)
        self._wait_for_comfy()

    def _show_update_notice(self, tag, url):
        # Inform only; updates must be obtained via approved, signed builds.
        msg = QMessageBox(self.splash)
        msg.setWindowTitle('IMGenius update available')
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setText(f'IMGenius {tag} is available on GitHub.')
        msg.setInformativeText('Open the release page to review the update, or continue startup.')
        open_release = msg.addButton('View release', QMessageBox.ButtonRole.ActionRole)
        msg.addButton('Continue startup', QMessageBox.ButtonRole.AcceptRole)
        msg.exec()
        if msg.clickedButton() == open_release:
            QDesktopServices.openUrl(QUrl(url))

    def _open_window(self):
        self.splash.set_status('Opening your studio...')
        try:
            self.main_window = MainWindow()
            self.main_window.show()
            self.main_window.status(self.comfy_problem or self.comfy_service.message)
        except Exception:
            self._show_error(traceback.format_exc())
            return
        self.app.setQuitOnLastWindowClosed(True)
        self.splash.finish()

    def _shutdown(self):
        if self.wait_worker is not None and self.wait_worker.isRunning():
            self.wait_worker.requestInterruption()
            self.wait_worker.wait(2500)
        self.comfy_service.stop()

    def _show_error(self, details):
        self.splash._timer.stop()
        print(details, file=sys.stderr)
        QMessageBox.critical(self.splash, 'IMGenius startup failed',
                             'IMGenius could not finish starting. Your saved data was not intentionally deleted.\n\n'
                             'Launch from a terminal to view the detailed error.')
        self.splash.close()
        self.worker.wait()
        QTimer.singleShot(0, self.app.quit)


def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName('IMGenius')
    app.setWindowIcon(QIcon(str(app_icon_path())))
    app.setOrganizationName('IMGenius')
    app.setStyle('Fusion')
    available = set(QFontDatabase.families())
    preferred = ('Inter', 'Noto Sans', 'Segoe UI', 'Cantarell',
                 'DejaVu Sans', 'Arial', 'Liberation Sans')
    family = next((name for name in preferred if name in available), app.font().family())
    app.setFont(QFont(family, 11))
    theme = str(QSettings('IMGenius', 'IMGenius').value('theme', 'Dark'))
    default_style = STYLE.replace('__IMG_FAMILY__', family)
    app.setStyleSheet(default_style if theme == 'Dark' else
                      build_theme_stylesheet(STYLE, theme if theme in THEMES else 'Dark', family))
    app._startup = StartupController(app)
    app._startup.start()
    return app.exec()
