"""Curated Hugging Face GGUF models for creative writing and character roleplay.

The curated repository IDs refer to public model listings. Their GGUF file variants,
sizes, and availability are fetched live from the Hugging Face model API; no file names,
download sizes, or released dates are invented. Nothing downloads without confirmation.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import PurePosixPath

from imgenius.models.manager import validate_repo_file, validate_repo_id


@dataclass(frozen=True)
class CreativeModel:
    title: str
    repo_id: str
    params: str
    category: str
    description: str
    recommended_quant: str = 'Q4_K_M'

    @property
    def url(self) -> str:
        return f'https://huggingface.co/{validate_repo_id(self.repo_id)}'


CREATIVE_MODELS: tuple[CreativeModel, ...] = (
    CreativeModel(
        'Mistral NeMo Mag Mell R1', 'QuantFactory/MN-12B-Mag-Mell-R1-GGUF', '12B', 'Creative / RP',
        'A Mistral NeMo-based merge built for imaginative fiction, character dialogue and immersive scenes.'),
    CreativeModel(
        'DarkIdol Llama 3.1', 'tensorblock/DarkIdol-Llama-3.1-8B-Instruct-1.2-Uncensored-GGUF', '8B', 'Roleplay',
        'An Llama 3.1 roleplay-oriented finetune; a smaller model option for character conversations.'),
    CreativeModel(
        'Mistral NeMo Celeste V1.9', 'nothingiisreal/MN-12B-Celeste-V1.9-GGUF', '12B', 'Story / RP',
        'Creative-writing and storytelling finetune of Mistral NeMo, aimed at descriptive fictional exchanges.'),
    CreativeModel(
        'MythoMax L2', 'TheBloke/MythoMax-L2-13B-GGUF', '13B', 'Story / RP',
        'A classic roleplay and collaborative fiction model, based on Llama 2.'),
    CreativeModel(
        'Stheno v3.2', 'bartowski/L3-8B-Stheno-v3.2-GGUF', '8B', 'Character RP',
        'An 8B Llama 3-based model designed for character roleplay and scene writing.'),
    CreativeModel(
        'Magnum 12B v2', 'bartowski/magnum-12b-v2-GGUF', '12B', 'Creative / RP',
        'Mistral NeMo family roleplay model for fiction, atmosphere and character conversation.'),
    CreativeModel(
        'Fimbulvetr 11B v2', 'Sao10K/Fimbulvetr-11B-v2-GGUF', '11B', 'Fantasy / RP',
        'Creative character and fantasy roleplay model with an 11B parameter base.'),
    CreativeModel(
        'Noromaid 13B DPO', 'NeverSleep/Noromaid-13B-0.4-DPO-GGUF', '13B', 'Roleplay',
        'A roleplay-focused 13B model in the Noromaid family, suitable for testing different narrative styles.'),
)


# File tag names supported by Ollama's hf.co/<repository>:<quant> pulling syntax.
_QUANT = re.compile(r'(?:^|[.\-_])(?P<tag>(?:IQ[1-4]_[A-Z0-9_]+|Q[2-8]_[A-Z0-9_]+))$', re.IGNORECASE)
_MULTI_PART = re.compile(r'(?:^|[-_.])\d{5}-of-\d{5}(?:$|[-_.])', re.IGNORECASE)


def gguf_quant(filename: str) -> str | None:
    """Return a single-file quant tag, or None if the HF-to-Ollama pull is ambiguous."""
    validate_repo_file(filename)
    name = PurePosixPath(filename).name
    if not name.lower().endswith('.gguf') or _MULTI_PART.search(name):
        return None
    stem = name[:-5]
    match = _QUANT.search(stem)
    return match.group('tag').upper() if match else None


def available_ggufs(files: list[dict]) -> list[dict]:
    """Only show single-file GGUF quants whose hf.co Ollama tag is unambiguous."""
    variants = []
    seen = set()
    for entry in files:
        filename = entry.get('name') or ''
        try:
            tag = gguf_quant(filename)
        except ValueError:
            continue
        if not tag or tag in seen:
            continue
        size = entry.get('size')
        if size is not None and (not isinstance(size, int) or size <= 0):
            size = None
        variants.append({'name': filename, 'quant': tag, 'size': size})
        seen.add(tag)
    # Smaller quants first, with unknown size at the end.
    return sorted(variants, key=lambda item: (item['size'] is None, item['size'] or 0, item['quant']))


def preferred_variant_index(files: list[dict], recommended: str = 'Q4_K_M') -> int:
    for index, entry in enumerate(files):
        if entry.get('quant') == recommended:
            return index
    for fallback in ('IQ4_XS', 'Q4_K_S', 'Q3_K_M', 'Q5_K_M'):
        for index, entry in enumerate(files):
            if entry.get('quant') == fallback:
                return index
    return 0 if files else -1


def ollama_hf_ref(repo_id: str, filename: str) -> str:
    repo_id = validate_repo_id(repo_id)
    tag = gguf_quant(filename)
    if not tag:
        raise ValueError('Select a supported, single-file GGUF quantization.')
    return f'hf.co/{repo_id}:{tag}'


def filter_creative_models(query: str) -> list[CreativeModel]:
    query = (query or '').casefold().strip()
    return [model for model in CREATIVE_MODELS
            if query in ' '.join((model.title, model.repo_id, model.params, model.category, model.description)).casefold()]
