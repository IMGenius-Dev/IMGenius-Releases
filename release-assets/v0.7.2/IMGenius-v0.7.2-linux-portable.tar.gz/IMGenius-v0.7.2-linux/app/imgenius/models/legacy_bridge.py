"""Legacy model convenience wrappers preserved for API compatibility."""
import json
import shutil
import subprocess
import requests
from imgenius.shared.text import safe_text

def query_huggingface(search_query=''):
    query = search_query.strip()
    url = 'https://huggingface.co/api/models'
    params = {'limit': 8, 'sort': 'downloads'}
    if query:
        params['search'] = query
    response = requests.get(url, params=params, timeout=20)
    response.raise_for_status()
    items = response.json()
    results = []
    for item in items:
        results.append({
            'id': item.get('id'),
            'author': item.get('author'),
            'downloads': item.get('downloads', 0),
            'likes': item.get('likes', 0),
            'tags': item.get('tags', [])[:8],
            'summary': item.get('summary', 'No summary available.'),
            'pipeline_tag': item.get('pipeline_tag'),
        })
    return results

def get_ollama_models(base_url='http://localhost:11434'):
    url = f'{base_url.rstrip("/")}/api/tags'
    try:
        response = requests.get(url, timeout=15)
        response.raise_for_status()
        data = response.json()
        return data.get('models', [])
    except requests.RequestException:
        return []

def install_ollama_model(model_name, base_url='http://localhost:11434'):
    model = safe_text(model_name)
    if not model:
        return {'success': False, 'error': 'A model name is required.'}

    binary = shutil.which('ollama') or shutil.which('ollama.exe')
    if not binary:
        return {'success': False, 'error': 'Ollama was not found in PATH. Install Ollama and re-run the command.'}

    try:
        result = subprocess.run([binary, 'pull', model], capture_output=True, text=True, check=False)
    except OSError as exc:
        return {'success': False, 'error': f'Unable to execute Ollama: {exc}', 'model': model}

    stdout = (result.stdout or '').strip()
    stderr = (result.stderr or '').strip()
    if result.returncode != 0:
        return {'success': False, 'error': stderr or stdout or 'Ollama pull failed.', 'model': model}

    return {'success': True, 'model': model, 'output': stdout or stderr or 'Model installed successfully.'}

def generate_ollama_response(model_name, prompt, base_url='http://localhost:11434', options=None):
    url = f'{base_url.rstrip("/")}/api/generate'
    payload = {'model': model_name, 'prompt': prompt, 'stream': False}
    pipeline_options = {}
    if options:
        for key, value in options.items():
            if value in (None, '', []):
                continue
            if key in {'temperature', 'top_p', 'repeat_penalty', 'num_ctx', 'num_predict'}:
                try:
                    pipeline_options[key] = float(value) if key not in {'num_ctx', 'num_predict'} else int(value)
                except (TypeError, ValueError):
                    pipeline_options[key] = value
            elif key == 'stop':
                pipeline_options['stop'] = value if isinstance(value, list) else [str(value)]
            else:
                pipeline_options[key] = value
    if pipeline_options:
        payload['options'] = pipeline_options
    response = requests.post(url, json=payload, timeout=120)
    response.raise_for_status()
    result = response.json()
    return result.get('response', '')
