"""Model discovery and installation for the native IMGenius application.

No frontend HTTP server, shell commands built from untrusted strings, or mandatory
huggingface_hub dependency. All downloads are deliberate, single-file operations.
"""
from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path, PurePosixPath
from urllib.parse import quote

import requests

from imgenius.domain import DATA_DIR
from imgenius.shared.paths import normalize_comfy_root
from imgenius.images.comfy import Cancelled

# An offline starter catalog. Ollama has no stable official API for returning
# the entire public library, so these are suggestions, not a live index.
OLLAMA_CATALOG = (
    ('Llama 3.2', ('llama3.2:1b', 'llama3.2:3b')),
    ('Llama 3.1', ('llama3.1:8b',)),
    ('Qwen 3', ('qwen3:0.6b', 'qwen3:1.7b', 'qwen3:4b', 'qwen3:8b')),
    ('Gemma 3', ('gemma3:1b', 'gemma3:4b', 'gemma3:12b')),
    ('DeepSeek R1', ('deepseek-r1:1.5b', 'deepseek-r1:7b')),
    ('Phi-4 Mini', ('phi4-mini:3.8b',)),
    ('Mistral', ('mistral:7b',)),
)

SUPPORTED_FILES = ('.safetensors', '.gguf')
COMFY_FOLDERS = {
    'checkpoint': 'checkpoints',
    'lora': 'loras',
    'vae': 'vae',
    'controlnet': 'controlnet',
    'embedding': 'embeddings',
    'upscale': 'upscale_models',
}


def validate_repo_id(repo_id: str) -> str:
    repo_id = (repo_id or '').strip()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*(?:/[A-Za-z0-9][A-Za-z0-9_.-]*)?', repo_id):
        raise ValueError('Invalid Hugging Face model repository identifier.')
    if any(part in ('.', '..') for part in repo_id.split('/')):
        raise ValueError('Invalid Hugging Face repository name.')
    return repo_id


def validate_repo_file(filename: str) -> str:
    if not filename or '\\' in filename or filename.startswith('/'):
        raise ValueError('Invalid Hugging Face filename.')
    path = PurePosixPath(filename)
    if any(part in ('.', '..') for part in filename.split('/')) or any(not part for part in filename.split('/')):
        raise ValueError('Unsafe Hugging Face path.')
    if path.suffix.lower() not in SUPPORTED_FILES:
        raise ValueError('Only .safetensors or .gguf weights are currently supported.')
    return filename


def list_hf_files(repo_id: str) -> list[dict]:
    """Return downloadable single-file model weights from the HF repository API."""
    repo_id = validate_repo_id(repo_id)
    url = f'https://huggingface.co/api/models/{quote(repo_id, safe="/")}'
    r = requests.get(url, params={'blobs': 'true'}, timeout=30)
    r.raise_for_status()
    info = r.json()
    files = []
    for item in info.get('siblings', []):
        path = item.get('rfilename', '')
        try:
            validate_repo_file(path)
        except ValueError:
            continue
        size = item.get('size') or (item.get('lfs') or {}).get('size')
        files.append({'name': path, 'size': int(size) if size is not None else None})
    return sorted(files, key=lambda x: x['name'].lower())


def target_path(repo_id: str, filename: str, destination: str, *, comfy_root=None, data_dir=None) -> Path:
    """Give a single downloaded model a stable, collision-resistant filename."""
    repo_id = validate_repo_id(repo_id)
    filename = validate_repo_file(filename)
    if destination == 'ollama':
        if not filename.lower().endswith('.gguf'):
            raise ValueError('Ollama imports here require a GGUF model file.')
        root = Path(data_dir or DATA_DIR) / 'models' / 'gguf'
    elif destination in COMFY_FOLDERS:
        if not comfy_root:
            raise ValueError('Select your local ComfyUI directory first.')
        root = normalize_comfy_root(comfy_root) / 'models' / COMFY_FOLDERS[destination]
        if filename.lower().endswith('.gguf'):
            raise ValueError('GGUF models are not compatible with this standard ComfyUI SDXL loader.')
    else:
        raise ValueError('Unknown model destination.')
    repo_label = '__'.join(repo_id.split('/'))
    safe_name = re.sub(r'[^A-Za-z0-9._-]', '_', PurePosixPath(filename).name)
    return root / f'{repo_label}__{safe_name}'


def download_hf_file(repo_id: str, filename: str, destination: Path, *, cancel=None, on_progress=None) -> Path:
    """Atomic streamed Hugging Face download with cancel and overwrite protection."""
    repo_id = validate_repo_id(repo_id)
    filename = validate_repo_file(filename)
    destination = Path(destination)
    cancel = cancel or threading.Event()
    if destination.exists():
        raise FileExistsError(f'Target already exists: {destination.name}. Existing models are not overwritten.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    url = f'https://huggingface.co/{quote(repo_id, safe="/")}/resolve/main/{quote(filename, safe="/")}'
    tmp = destination.with_name(destination.name + '.part')
    if tmp.exists():
        raise FileExistsError(f'Incomplete download found at {tmp}; remove it to retry.')
    done = 0
    try:
        if cancel.is_set():
            raise Cancelled('Download cancelled.')
        with requests.get(url, stream=True, timeout=(20, 90), allow_redirects=True) as response:
            response.raise_for_status()
            total_header = response.headers.get('Content-Length', '')
            total = int(total_header) if total_header.isdigit() else 0
            with tmp.open('xb') as output:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if cancel.is_set():
                        raise Cancelled('Download cancelled.')
                    if chunk:
                        output.write(chunk)
                        done += len(chunk)
                        if on_progress:
                            on_progress(done, total)
        if done == 0:
            raise RuntimeError('Download returned an empty file.')
        # Refuse overwrites even when another process created the destination mid-download.
        if destination.exists():
            raise FileExistsError(f'Target already exists: {destination}')
        tmp.replace(destination)
        return destination
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def pull_ollama(base_url: str, model_name: str, *, cancel=None, on_progress=None) -> str:
    """Pull directly through configured Ollama server, providing download progress."""
    name = model_name.strip()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,180}', name):
        raise ValueError('Enter a valid Ollama model name, such as qwen3:4b.')
    cancel = cancel or threading.Event()
    if cancel.is_set():
        raise Cancelled('Model pull cancelled.')
    with requests.post(f'{base_url.rstrip("/")}/api/pull', json={'model': name, 'stream': True},
                       stream=True, timeout=(20, 120)) as response:
        response.raise_for_status()
        completed = False
        for line in response.iter_lines():
            if cancel.is_set():
                raise Cancelled('Stopped listening to pull. Ollama may continue the download.')
            if not line:
                continue
            packet = json.loads(line)
            if packet.get('error'):
                raise RuntimeError(packet['error'])
            status = packet.get('status', 'Pulling')
            total = packet.get('total') or 0
            current = packet.get('completed') or 0
            if on_progress:
                on_progress(status, current, total)
            if status == 'success':
                completed = True
        if not completed:
            raise RuntimeError('Ollama ended the download without confirming success.')
    return name


def import_gguf_ollama(gguf_path: Path, name: str, *, cancel=None, on_status=None) -> str:
    """Import single GGUF into a *local* Ollama installation via its official CLI."""
    gguf_path = Path(gguf_path).resolve()
    if gguf_path.suffix.lower() != '.gguf' or not gguf_path.is_file():
        raise ValueError('Download a complete .gguf file first.')
    if not re.fullmatch(r'[a-z0-9][a-z0-9_.:-]{0,99}', name):
        raise ValueError('Use a short lowercase Ollama model name (letters, numbers, dots, dashes).')
    binary = shutil.which('ollama') or shutil.which('ollama.exe')
    if not binary:
        raise RuntimeError('Ollama command-line client is not installed. GGUF remains downloaded locally.')
    cancel = cancel or threading.Event()
    with tempfile.TemporaryDirectory(prefix='imgenius-ollama-') as directory:
        modelfile = Path(directory) / 'Modelfile'
        modelfile.write_text(f'FROM \"{gguf_path.as_posix()}\"\n', encoding='utf-8')
        process = subprocess.Popen([binary, 'create', name, '-f', str(modelfile)],
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, bufsize=1)
        lines = queue.Queue()
        def read_lines():
            assert process.stdout is not None
            for line in process.stdout:
                lines.put(line)
        reader = threading.Thread(target=read_lines, daemon=True)
        reader.start()
        history = []
        try:
            while process.poll() is None or reader.is_alive() or not lines.empty():
                if cancel.is_set():
                    process.terminate()
                    raise Cancelled('Ollama import stopped.')
                try:
                    line = lines.get(timeout=0.25)
                except queue.Empty:
                    continue
                if line.strip():
                    history.append(line.strip())
                    if on_status:
                        on_status(line.strip()[:140])
            code = process.wait()
            if code != 0:
                details = (history[-1][:180] if history else 'Check Ollama logs.')
                raise RuntimeError(f'Ollama create exited with code {code}. {details}')
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    return name
