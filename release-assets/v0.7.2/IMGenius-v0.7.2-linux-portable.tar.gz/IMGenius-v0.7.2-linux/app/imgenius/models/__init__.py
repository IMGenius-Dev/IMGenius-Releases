"""Models components for IMGenius."""
