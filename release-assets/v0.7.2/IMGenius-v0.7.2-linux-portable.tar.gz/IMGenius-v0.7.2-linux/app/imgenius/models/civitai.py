"""Strict SDXL 1.0 / Illustrious Civitai checkpoint and LoRA discovery.

Civitai.red uses the Civitai catalog. The documented public JSON API is hosted
at civitai.com; no credentials or undocumented civitai.red API are required.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlsplit, parse_qsl
import re
import threading

import requests

from imgenius.images.comfy import Cancelled
from imgenius.shared.paths import normalize_comfy_root

API_URL = 'https://civitai.com/api/v1/models'
MODEL_SITE = 'https://civitai.red/models'
ALLOWED_BASES = ('SDXL 1.0', 'Illustrious')
ALLOWED_TYPES = ('Checkpoint', 'LORA')
DOWNLOAD_HOSTS = frozenset({'civitai.com', 'civitai.red'})
SAFE_DOWNLOAD_OPTIONS = frozenset({'type', 'format', 'size', 'fp'})
HEX_SHA256 = re.compile(r'[A-Fa-f0-9]{64}\Z')


@dataclass(frozen=True)
class ImageWeight:
    model_id: int
    version_id: int
    model_name: str
    version_name: str
    category: str  # 'checkpoint' or 'lora'
    base_model: str
    filename: str
    size_bytes: int | None
    download_url: str
    sha256_hash: str | None

    @property
    def page_url(self) -> str:
        return f'{MODEL_SITE}/{self.model_id}?modelVersionId={self.version_id}'


def _positive_id(value):
    if type(value) is int and value > 0:
        return value
    return None


def _download_link(value: str, version_id: int) -> str | None:
    """Accept only official model download URLs; never follow arbitrary API links."""
    if not isinstance(value, str):
        return None
    parsed = urlsplit(value)
    try:
        if (parsed.scheme != 'https' or parsed.username or parsed.password or
                (parsed.hostname or '').lower() not in DOWNLOAD_HOSTS or parsed.port):
            return None
    except ValueError:
        return None
    if parsed.path != f'/api/download/models/{version_id}' or parsed.fragment:
        return None
    opts = parse_qsl(parsed.query, keep_blank_values=True)
    if any(k not in SAFE_DOWNLOAD_OPTIONS or len(v) > 50 for k, v in opts):
        return None
    return value


def filtered_weights(payload: dict, *, category: str = 'both', base: str = 'both') -> list[ImageWeight]:
    """Fail closed when version architecture is unknown or ambiguous."""
    if category not in ('both', 'checkpoint', 'lora') or base not in ('both', *ALLOWED_BASES):
        raise ValueError('Unsupported Civitai filter')
    allowed = set(ALLOWED_BASES if base == 'both' else (base,))
    output = []
    if not isinstance(payload, dict) or not isinstance(payload.get('items'), list):
        raise ValueError('Civitai returned an invalid model listing')
    for model in payload['items']:
        if not isinstance(model, dict) or model.get('mode') in ('Archived', 'TakenDown'):
            continue
        kind = {'Checkpoint': 'checkpoint', 'LORA': 'lora'}.get(model.get('type'))
        model_id = _positive_id(model.get('id'))
        if kind is None or model_id is None or (category != 'both' and category != kind):
            continue
        versions = model.get('modelVersions')
        if not isinstance(versions, list):
            continue
        for version in versions:
            if not isinstance(version, dict):
                continue
            architecture = version.get('baseModel')
            version_id = _positive_id(version.get('id'))
            if architecture not in allowed or version_id is None:
                continue
            choices = []
            files = version.get('files')
            if not isinstance(files, list):
                continue
            for file in files:
                if not isinstance(file, dict) or file.get('type') != 'Model':
                    continue
                filename = file.get('name')
                if (not isinstance(filename, str) or len(filename) > 180 or
                        re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_. -]*\.safetensors', filename, re.I) is None):
                    continue
                metadata = file.get('metadata') or {}
                if not isinstance(metadata, dict) or metadata.get('format', 'SafeTensor') != 'SafeTensor':
                    continue
                link = _download_link(file.get('downloadUrl'), version_id)
                if not link:
                    continue
                hashes = file.get('hashes') or {}
                if not isinstance(hashes, dict):
                    continue
                digest = hashes.get('SHA256')
                if digest is not None and (not isinstance(digest, str) or not HEX_SHA256.fullmatch(digest)):
                    continue
                size_kb = file.get('sizeKB')
                try:
                    size = int(float(size_kb) * 1024) if size_kb is not None else None
                    if size is not None and not 0 < size < 1024**5:
                        continue
                except (TypeError, ValueError, OverflowError):
                    continue
                choices.append((not bool(file.get('primary')), ImageWeight(
                    model_id=model_id, version_id=version_id,
                    model_name=str(model.get('name') or '')[:180],
                    version_name=str(version.get('name') or '')[:100],
                    category=kind, base_model=architecture, filename=filename,
                    size_bytes=size, download_url=link,
                    sha256_hash=digest.lower() if digest else None)))
            if choices:
                output.append(sorted(choices, key=lambda pair: pair[0])[0][1])
    return output


def search_weights(query='', *, category='both', base='both', cursor=None):
    """Ask the server to filter as well, then validate every returned version."""
    if category not in ('both', 'checkpoint', 'lora') or base not in ('both', *ALLOWED_BASES):
        raise ValueError('Unsupported model selection')
    query = query.strip()
    if len(query) > 180:
        raise ValueError('Search query too long')
    params = {
        'limit': 60,
        'types': 'Checkpoint,LORA' if category == 'both' else ('Checkpoint' if category == 'checkpoint' else 'LORA'),
        'baseModels': ','.join(ALLOWED_BASES) if base == 'both' else base,
        'sort': 'Most Downloaded',
        'nsfw': 'true',
    }
    if query:
        params['query'] = query
    if cursor:
        if not isinstance(cursor, str) or len(cursor) > 1200:
            raise ValueError('Invalid Civitai pagination cursor')
        params['cursor'] = cursor
    with requests.get(API_URL, params=params, timeout=(12, 25)) as response:
        response.raise_for_status()
        if len(response.content) > 8 * 1024 * 1024:
            raise ValueError('Civitai results exceeded the response limit')
        payload = response.json()
    matches = filtered_weights(payload, category=category, base=base)
    pagination = payload.get('metadata') or {}
    next_cursor = pagination.get('nextCursor') if isinstance(pagination, dict) else None
    if not isinstance(next_cursor, str) or len(next_cursor) > 1200:
        next_cursor = None
    return matches, next_cursor


def install_destination(weight: ImageWeight, comfy_root) -> Path:
    if (weight.category not in ('checkpoint', 'lora') or weight.base_model not in ALLOWED_BASES or
            _positive_id(weight.model_id) is None or _positive_id(weight.version_id) is None or
            not _download_link(weight.download_url, weight.version_id)):
        raise ValueError('Incompatible or unverified Civitai weight')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_. -]*\.safetensors', weight.filename, re.I):
        raise ValueError('Unsafe or unsupported filename')
    root = normalize_comfy_root(comfy_root)
    if not (root / 'models').is_dir():
        raise ValueError('Select a real ComfyUI directory with a models/ folder.')
    dest = 'checkpoints' if weight.category == 'checkpoint' else 'loras'
    safe_filename = re.sub(r'[^A-Za-z0-9._-]', '_', weight.filename)
    return root / 'models' / dest / f'civitai_{weight.model_id}_{weight.version_id}_{safe_filename}'


def download_weight(weight: ImageWeight, target: Path, *, cancel=None, on_progress=None):
    """One-file atomic streamed install with optional upstream SHA256 validation."""
    if (weight.base_model not in ALLOWED_BASES or weight.category not in ('checkpoint', 'lora') or
            not _download_link(weight.download_url, weight.version_id)):
        raise ValueError('Only SDXL 1.0 and Illustrious checkpoints and LoRAs can be installed.')
    target = Path(target)
    cancel = cancel or threading.Event()
    if target.exists():
        raise FileExistsError(f'{target.name} already exists; refusing to overwrite it.')
    if target.suffix.lower() != '.safetensors' or not target.name.startswith(
            f'civitai_{weight.model_id}_{weight.version_id}_'):
        raise ValueError('Destination is not the expected Civitai safetensors model file.')
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + '.part')
    hasher = sha256()
    count = 0
    try:
        if cancel.is_set():
            raise Cancelled('Download cancelled.')
        with requests.get(weight.download_url, stream=True, allow_redirects=True,
                          timeout=(20, 90)) as response:
            response.raise_for_status()
            total = int(response.headers.get('Content-Length', 0) or 0)
            with part.open('xb') as dest:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if cancel.is_set():
                        raise Cancelled('Download cancelled.')
                    if chunk:
                        dest.write(chunk)
                        hasher.update(chunk)
                        count += len(chunk)
                        if on_progress:
                            on_progress(count, total)
        if not count:
            raise ValueError('Empty Civitai model download')
        if weight.sha256_hash and hasher.hexdigest() != weight.sha256_hash:
            raise ValueError('Downloaded model SHA256 did not match Civitai metadata.')
        if target.exists():
            raise FileExistsError('A model appeared at the destination during download.')
        part.replace(target)
        return target
    except Exception:
        part.unlink(missing_ok=True)
        raise
