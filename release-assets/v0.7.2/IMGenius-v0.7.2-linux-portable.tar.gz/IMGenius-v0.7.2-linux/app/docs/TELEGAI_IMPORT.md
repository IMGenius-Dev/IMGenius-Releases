# TelegAI / CharacterHub inline character discovery

The v0.5.4 integration displays online character **cards** inside the existing
**Characters** page. It no longer opens a second embedded web-browser page.

## Usage

1. Open **Characters → TelegAI** (the source toggle at the top of Characters).
2. Search, choose a sort order, adjust **Include mature**, and use the page controls.
3. Click a card portrait or **Import card** to import its complete public PNG card.
4. Review the character profile, first message, system prompt, portrait and lorebook in
   Character Editor; only clicking **Save character** writes to your local collection.
5. Click **My characters** to return to your saved cards.

You can also paste a TelegAI/CharacterHub character detail URL to import directly.

## Technical notes

- Public listings are requested from a CharacterHub-compatible search API. Search and
  sorting may differ from what TelegAI's own website currently shows.
- Preview text is **never** treated as the full character definition. A real PNG
  with embedded card metadata is required for automatic import.
- Image requests and search responses are size-limited and restricted to public
  HTTPS CharacterHub/Chub hosts; no login cookies or private APIs are used.
- Online browsing is opt-in and starts only after the TelegAI toggle is selected.
- Qt WebEngine is **not required**. Native PySide6 and requests suffice.
- Third-party APIs, CDN routes and public availability can change without notice.
  Failed downloads should be handled with manual PNG/JSON import.

## Files

- `imgenius/ui/pages/characters.py` — My characters / TelegAI toggle
- `imgenius/ui/pages/telegai.py` — inline native Qt cards, search, pagination and import
- `imgenius/characters/telegai.py` — public search, URL validation and bounded downloads
- `imgenius/characters/card_io.py` — local character-card format validation

## Content-filter and card-action fix (0.5.5)

The **Include mature** switch controls whether public Mature / NSFW cards are eligible
in the TelegAI results. When Off, IMGenius requests the server's SFW listing and
also filters any cards explicitly marked Mature in their returned metadata (for
example `nsfw`, `naughty`, `rating`, or a Mature/18+ tag). When On, it requests
the inclusive listing and displays rated Mature results with a label.

The classification is based on the public listing's own supplied metadata;
missing or inaccurate upstream labels cannot be inferred reliably. Turning the
switch on does not guarantee that every page includes Mature characters.

Discovery-card actions are presented in two full-width rows so neither **Import
card** nor **View on site** is clipped on a narrow, responsive character tile.
