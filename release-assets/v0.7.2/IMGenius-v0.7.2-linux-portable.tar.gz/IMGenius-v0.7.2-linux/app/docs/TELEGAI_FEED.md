# Chub gallery — feed integration notes (IMGenius v0.5.12)

## v0.5.12: Catalog and For you split

**Full catalog** (default) uses Chub's indexed search API and accepts server-side text, tags and global page numbers. **For you feed** still uses the direct route described below, but represents only a curated recommendation set. The tag-search field is disabled in For you because it would not search the complete catalog. The mature-content toggle is available in either mode; Chub's index can apply different access restrictions and may return Unrated records.

## v0.5.11 UI branding

The IMGenius Characters UI identifies the original card catalog as **Chub**.
Discovery still requests the working TelegAI-hosted JSON adapter documented below.
The feed hostname is retained to preserve functionality and source transparency;
character links and the optional website button open `chub.ai` directly.

## Source and response mapping

The optional **For you feed** calls TelegAI's **direct JSON API endpoint**
(not its similarly named HTML page):

```
GET https://www.telegai.com/api/user/foryou?page=1&nsfw=false
GET https://www.telegai.com/api/user/foryou?page=1&nsfw=true
```

The direct `/api/user/foryou` route was verified by a user opening it in
Firefox; the earlier browser Network panel showed `x-matched-path: /api/user/foryou`
for its JSON response. Direct browsing does not require the website's `v` cache-busting parameter.
The accompanying captured JSON contained `bots` (42 items), `count` (42),
`tags_used`, `cold_start`, and `has_more` (`true`). `count` is **not** the
catalog total; paging follows `has_more`. The application does not send authentication tokens or cookies.

| Feed field | IMGenius card |
|---|---|
| `id` (`author/slug`) | Stable identifier / import URL |
| `bot_name` | Display name |
| `description` | Hover description |
| `image_url` | CharacterHub thumbnail (validated HTTPS host) |
| `topics` | Tags and `NSFW` character-level label |
| `nsfw_image` | Portrait-content flag only, never the character rating |
| `rating` | Community star rating, not Safe/Mature |
| `nChats` | Popularity sort (only within fetched page) |
| `created_at` | Newest sort (only within fetched page) |

## Content filter

The Safe view (`nsfw=false`) also rejects records whose topics explicitly
contain a mature marker. A flagged adult thumbnail is suppressed in the Safe
view even if the character itself is Unrated. Enabling mature viewing first
requires session-only local 18+ confirmation, and sends `nsfw=true`. This
confirmation **does not** log in to TelegAI or grant access to restrictions
imposed by TelegAI, Chub, or the user's region.

## What works and what is intentionally limited

- The character grid, paging, and filters use native Qt, not a web browser.
- The For you feed has no text or tag filters; use Full catalog for site-wide search.
- For you preserves the provider's original ordering; sort controls only apply to Full catalog.
- Import uses the existing Chub card download/export, **not** the preview
  summary. Export may require account access and can fail independently of
  successful discovery. Users can still import a card downloaded manually.
- Third-party API routes can change without warning. An HTTP 403 or an HTML
  response is reported instead of being interpreted as an empty gallery.
- Network, redirects, image hosts and response sizes use the same bounded
  validation and cancellation model as the existing Chub implementation.

## QA

Automated tests cover the observed response field names, content-vs-image
rating distinction, safe filtering, `has_more`, malformed responses, unsafe
avatar URLs, imports, and retained character data. A development-only check
against the user-supplied 42-item response parsed all 42 cards, including
41 Mature-topic records. Live requests to TelegAI from the user's machine
remain necessary to confirm the public endpoint accepts standalone clients.

## v0.5.9: JSON versus website HTML response

The initial 0.5.8 adapter reused the character-card file downloader. That
request did not advertise JSON as the desired representation, even though
`/foryou` is also a website route. A provider can serve a normal HTML page
with HTTP 200 for a generic HTTP client; `json.loads` then fails.

The v0.5.9 feed downloader sent `Accept: application/json` and
`X-Requested-With: XMLHttpRequest`, validated HTTPS redirects and payload
sizes, and reports the response's HTTP status and Content-Type when it cannot
parse JSON. These are standard content-negotiation headers, not authentication
or a way around the provider's own age/account restrictions.

A fake HTTP server in automated tests returns HTML without JSON headers and
JSON with them. This validates IMGenius's behavior but does not establish that
TelegAI's production service makes the same choice; live confirmation is still
needed. If TelegAI still returns HTML, inspect the working Firefox `foryou`
request's **non-sensitive** request headers and redacted response content type.
Do not share your browser cookies, authorization tokens, or account identifiers.

## v0.5.10: Direct API route instead of HTML page

The v0.5.9 fix did not solve the issue: even with `Accept: application/json`,
TelegAI returned an HTTP 200 `text/html` page from `/foryou` to IMGenius.
The user then verified the **direct** path `/api/user/foryou?page=1&nsfw=false`
returns JSON with the expected `bots` array when opened in Firefox.
The successful website request also included response header
`x-matched-path: /api/user/foryou`. Consequently, the adapter now requests the
direct JSON path rather than attempting more header negotiation on the website
page. This is a site-owned third-party endpoint with no stability guarantee.
No session cookies or authorization tokens are used by IMGenius.
