# IMGenius v0.6.5 — Keep stopped chat replies

The Chats **Stop** button now ends the current Ollama stream while retaining all assistant text already received. It saves the partial assistant reply into the local chat database, so it remains visible after restarting IMGenius. **Continue** starts a new generation from saved context; Ollama does not support resuming the original network stream.

- Works for Send, Regenerate, and Continue.
- Regenerate/Continue only replace later stored history when the stopped reply contains actual text.
- Stopping before the first token keeps the previous history and creates no empty assistant reply.
- Errors (not intentional Stop) retain previous behavior: do not save unfinished responses.
- Scene-image generation still uses cancellation rather than creating a text reply.
- Stops after the next streamed chunk (as before).

Run tests with `python -m pytest -q` from the project root.
