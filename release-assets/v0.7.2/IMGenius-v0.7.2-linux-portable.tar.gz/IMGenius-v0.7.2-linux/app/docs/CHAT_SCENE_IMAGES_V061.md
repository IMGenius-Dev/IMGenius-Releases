# IMGenius v0.6.1 — Chat usability and scene images

## Chat formatting

Both **user** and **assistant** messages now use the same safe renderer.
`*actions*`, `**emphasis**`, and an allowlisted subset of simple HTML render
as formatted text. Disallowed HTML tags and attributes are displayed as
escaped text, never executed. Any original message content remains unchanged
in SQLite and in the context sent to the LLM.

The Edit message dialog now uses a resizable, wrapped text editor with the
horizontal scrollbar disabled. The compose field also explicitly wraps.

## Regenerate and Continue

- **Regenerate:** the outgoing assistant bubble disappears immediately and is
  replaced by a streaming placeholder. The original database history is not
  deleted until the replacement succeeds; on error or cancellation it is
  restored in the UI. Regenerating an older reply still asks for confirmation
  before removing later messages.
- **Continue:** an internal instruction is sent to Ollama to extend the reply,
  but is not shown as a fabricated user message and is not stored in chat.
  A new assistant bubble streams the continuation. Continuing from an older
  reply retains its existing confirmation before truncating later messages.

## Generate scene image in Chats

In a conversation click **Generate scene image**. The app:

1. Takes up to 24 recent stored user/assistant messages and a bounded character
   profile snapshot.
2. Invokes the **currently selected Ollama chat model** to write a concise visual
   prompt for the latest scene. The image-prompt instruction and generated
   prompt do not become normal chat messages, do not modify the user's draft
   message, and do not overwrite saved Create image prompts.
3. Calls ComfyUI using the **selected checkpoint, dimensions, negative prompt,
   sampler, steps, CFG, LoRAs, and other current Create image settings**.
   The mode is always text-to-image, regardless of Create image's current mode.
4. Saves the resulting files to the existing `IMGenius/images/` user-data
   gallery and adds image references with the generated prompt to the current
   conversation. The image thumbnail is clickable to enlarge.

The `chat_images` table is created automatically in the existing SQLite
`chats.db` on first launch. It stores an image filename and the LLM-written
prompt alongside the chat ID. Existing messages are untouched. Image files
stay in the central gallery even after the chat is deleted, while chat
attachment references are cleaned up. Full chat cleanup also clears these
references without deleting the image gallery.

### Setup

- Ollama and ComfyUI must be running at the addresses specified in Settings.
- Select a working checkpoint in **Create image** (use **Refresh checkpoints
  + LoRAs** if necessary) before clicking the chat image button.
- You can use the normal **Stop** button during LLM prompt writing or while
  waiting for the image. Stopping the local wait may not cancel a job already
  submitted to ComfyUI.
- Generated scene images use the same gallery and negative-prompt settings as
  ordinary image generation. The generated positive prompt is retained with
  the image attachment; hover its thumbnail to view the prompt.

### Limitations

- Scene selection is determined by your current text-only LLM. The result
  depends on its context capacity and ability to produce concise visual
  descriptions.
- Live Ollama, ComfyUI, and native Qt interaction require a local desktop
  check. The automated suite uses backend tests and UI source assertions.
- The chat attachment only stores filenames in the gallery and will display
  an unavailable-image placeholder if the underlying image is later deleted.
