# IMGenius 0.7.1: GitHub update check + ComfyUI startup gate

The splash screen now runs this sequence before exposing the desktop UI:

1. Check the **public** `IMGenius-Dev/IMGenius-Releases` GitHub Releases feed (3-second request timeout).
2. When a newer release is available, ask whether to **view its GitHub release page** or continue startup. IMGenius does not automatically execute an update installer; signature verification and package-manager updates are still future work.
3. Prepare character and persona databases without bundling user data.
4. Start a local ComfyUI instance (or detect one already running).
5. Keep animating the splash while `/system_stats` reports whether ComfyUI is actually ready.
6. Open the main window only after ComfyUI is healthy, or after the user explicitly opts to continue without images.

ComfyUI readiness has a default maximum wait of **120 seconds**, configurable by the `comfy_startup_timeout_seconds` QSettings key (clamped to 15–300 seconds). If ComfyUI is not installed, exits during startup, or does not respond, the user may retry, continue without cloud/local image generation, or exit. Existing externally owned ComfyUI processes are never terminated by IMGenius.

## Required publication setup

The development repository `IMGenius-Dev/IMGenius` remains private. Anonymous clients cannot read its releases. Create a **public** repository named `IMGenius-Dev/IMGenius-Releases` and publish official version-tagged GitHub Releases there (for example `v0.7.2`), after validating and signing OS-specific builds. Until that public repo exists, the update check fails gracefully and cannot advertise available versions. The updater never uses personal access tokens.

The `update_channel` setting accepts `beta` (default, including prereleases) or `stable`. No external model providers or GitHub credentials are needed for the check. Offline startup proceeds normally.

**Important:** The release notifier only opens a browser link. It is not a secure automatic binary installer. Native Windows and GPU test runs remain necessary before wider distribution.
