# Full Chub catalog browsing — IMGenius 0.6.0

## Source and verification

The public catalog listing used here was observed on TelegAI's `/new` page
in an anonymized Firefox Network capture. Although the UI presents **Chub**
(the cards are Chub cards), the listing service is hosted in TelegAI's
Supabase project; this is neither an official Chub SDK nor a stable API.

Endpoint:

```
https://ywqesktuqvgsmrgraors.supabase.co/functions/v1/fetch-all-service
```

The captured public GET query was:

```
asc=false&exclude_tags=&first=80&include_forks=false&inclusive_or=true&nsfl=true&nsfw=true&page=1&require_custom_prompt=false&sort=created_at&tags=&venus=true
```

The captured JSON had 80 `bots` objects and a `count` value of `100000`.
In that capture 60 characters had the `NSFW` topic and 23 had a flagged
portrait (`nsfw_image`). The count can be a cap or estimate and is **not**
displayed as a verified catalog size. These are response observations,
not a statement that IMGenius has successfully contacted the service live.

The service returned JSON without visible account cookies in the captured
request. IMGenius does not copy Firefox credentials, sign in to third-party
services, or bypass age verification. It requests the public route only after
the user opens the Chub online tab and asks for mature content after local
adult confirmation. Changes in third-party access policies may cause failures.

## UI and fetching behavior

- A network batch is fixed to `first=80`, the known working size.
- Each IMGenius display page shows up to 12 cards, and each output page is
  calculated from the global card offset. Pages that cross batch boundaries
  fetch both required batches. Only visible portraits are downloaded.
- Previous batches are cached in memory for at most five minutes and evicted
  after twelve cached batches. **Refresh** clears the cache. Cache keys include source, sorting and all
  content/tag filters so a Safe page cannot reuse a Mature response.
- The service controls catalog ordering and available results; IMGenius does
  not randomly merge results or secretly fall back to another source.
- The provider's `count=100000` is not treated as an exact pagination total.
  Short batches terminate the Next-page indicator, even when `count` is large.
- `tags`, `exclude_tags` and `inclusive_or` are forwarded to the service.
  Whether a particular tag query uses union or intersection semantics exactly
  as named must be verified with live source responses.
- The observed and verified sort key is `created_at`; the other two choices
  use best-effort provider names and may need correction after live feedback.

### Searching text

No site-wide text-search request was included in the verified Supabase capture.
IMGenius therefore routes **nonempty** text to the separate public Chub search
index (which may not return mature results consistently). It does not
misrepresent local filtering of an 80-card response as a catalog-wide search.
Clear the text field for tag filtering and deep browsing through the public
catalog service; exclude tags and Any/All matching apply only in that mode.

### Security and privacy

- HTTPS only, with the hostname and path allowlisted across redirects.
- No cookies, access tokens or authorization headers sent.
- Streaming content-length limit of 8 MiB and rejection of non-JSON bodies.
- Character IDs validated, and images loaded only from trusted Chub CDN hosts.
- No site HTML or embedded scripts are executed inside IMGenius.
- Importing a complete card still uses the existing verified Chub V2 PNG
  extraction and requires an explicit user save.
- Data from public cards is untrusted and displayed as plain text.

## Tests / future work

Synthetic integration tests cover the supplied schema, page 7 crossing the
80-record boundary, far-page jumps, caching, last partial batches, separate
Safe/Mature cache keys, invalid tags, missing JSON, server errors, huge
responses and the migration to a patch manager supporting 0.6.x.

End-to-end network and live GUI behavior cannot be verified in this runtime.
If catalog text search support becomes publicly documented or observed, it
can replace the separate Chub index search rather than introducing guesswork.
