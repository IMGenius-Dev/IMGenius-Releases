# Where did each 0.4.x file go?

IMGenius 0.5.0 removes loose implementation modules from the project root. Use this map to find the same functionality in the new package.

| 0.4.x source file | 0.5.0 source location |
|---|---|
| `main.py` | `main.py` (launcher) + `imgenius/bootstrap.py` (initialization) |
| `qt_app.py` | `imgenius/ui/main_window.py` (shell) + eight modules in `imgenius/ui/pages/` + controls in `imgenius/ui/widgets/` |
| `core.py` | `imgenius/shared/paths.py`, `shared/text.py`, `characters/repository.py`, `characters/prompts.py`, `characters/portraits.py`, `chats/repository.py`, `chats/personas.py`, `stories/repository.py`, `models/legacy_bridge.py` |
| `character_library.py` | `imgenius/characters/library.py` |
| `character_pagination.py` | `imgenius/characters/pagination.py` |
| `character_grid_layout.py` | `imgenius/characters/grid_layout.py` |
| `character_card_io.py` | `imgenius/characters/card_io.py` |
| `character_catalog.json` | `assets/catalog/character_catalog.json` |
| `character_seeds.py` | `imgenius/characters/seeds.py` |
| `lorebook.py` | `imgenius/characters/lorebook.py` |
| `chat_formatting.py` | `imgenius/chats/formatting.py` |
| `avatar_generation.py` | `imgenius/images/avatar_generation.py` |
| `services.py` | `imgenius/images/comfy.py` |
| `model_manager.py` | `imgenius/models/manager.py` |
| `creative_catalog.py` | `imgenius/models/creative_catalog.py` |
| `data_cleanup.py` | `imgenius/data/cleanup.py` |
| `themes.py` | `imgenius/ui/themes.py` |
| `brand_assets.py` | `imgenius/ui/brand_assets.py` |
| `ui_layout.py` | `imgenius/ui/layout.py` |
| `data/character_cards/` (legacy) | User-owned data directory only; not shipped in v0.7.0 |
| `build-linux.sh`, `build-windows.bat`, `install-linux-desktop.sh` | `scripts/` |

A stable data facade remains available at `imgenius/domain.py` for code that previously imported common types and helpers from `core.py`, but new implementation code should go in its named feature module.

**Important:** These are code/asset locations. Files such as saved chats, downloaded models, generated images and uploaded character portraits are *not* moved. They still live under `~/.local/share/IMGenius/` on Linux and `%LOCALAPPDATA%\IMGenius\` on Windows.
