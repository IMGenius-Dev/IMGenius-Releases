# Upgrade from IMGenius 0.4.x to 0.5.0

This release changes the **source-code folder layout**, not the user's profile/database directory.

## 1. Close the old app

Stop any active model download, ComfyUI job, or chat generation, then fully quit IMGenius.

## 2. Back up your local data

On Linux, copy `~/.local/share/IMGenius/` (or `$XDG_DATA_HOME/IMGenius/`) to a safe backup folder. Example:

```bash
cp -a ~/.local/share/IMGenius ~/IMGenius-data-backup
```

On Windows, copy `%LOCALAPPDATA%\IMGenius\` in File Explorer to a backup location. Do not delete the original data directory.

## 3. Extract the entire 0.5.0 project into a new folder

Do **not** copy 0.5.0 files over the old `qt_app.py`, `core.py`, or other loose 0.4.x files. Those old files are intentionally gone; the new code is organized under `imgenius/`.

## 4. Launch the new project

Linux:

```bash
cd /path/to/IMGenius-v0.5.0
./launch-linux.sh
```

Windows: run `launch-windows.bat` inside the extracted project folder.

The program uses the existing user data directory automatically. Character cards, image history, model configuration and chats should remain present.

## 5. Update your Linux desktop shortcut if desired

```bash
bash scripts/install-linux-desktop.sh
```

This rewrites the installed launcher to point at the **new** extracted folder. If you delete or move that folder, reinstall the launcher.

## 6. Roll back if needed

Close the new app and launch the old project folder. Keep the backup of your data until you've verified the new release. Schema migration code remains in the repositories, and the reorganization itself does not require any destructive reset.

## Troubleshooting

- **No images in Characters:** v0.7.0 intentionally ships no sample character artwork. Import your own character cards; personal images remain in your data directory.
- **Models won't generate:** Confirm Ollama and/or ComfyUI are running and the URL settings still point to their endpoints.
- **Missing Python dependencies:** See `requirements.txt`; on Arch, install `pyside6 python-requests python-pillow` via `pacman`.
- **Old desktop launcher opens the wrong version:** Run `scripts/install-linux-desktop.sh` from the new folder.
