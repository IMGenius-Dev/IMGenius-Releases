# IMGenius developer guide

## Requirements

- Python 3.12+ (version used by the Windows/Linux GitHub build workflow: 3.12)
- PySide6 / Qt6
- Requests
- Pillow
- Pytest for development; PyInstaller for standalone builds

Install distro-native packages where possible. On Arch Linux:

```bash
sudo pacman -S pyside6 python-requests python-pillow python-pytest
```

Or install the Python requirements into an appropriate virtual environment.

## Run from source

```bash
./launch-linux.sh
# Windows: launch-windows.bat
```

## Test

```bash
python -m compileall -q imgenius
python -m pytest -q
```

Tests include backend modules, API interactions with mocked responses, UI source-structure checks that don't need a display server, and isolated data-migration smoke tests. **GUI visual testing still requires PySide6 and a graphical desktop.**

## Build an executable

Linux:

```bash
python -m pip install pyinstaller   # only if PyInstaller is not already installed
bash scripts/build-linux.sh
```

Windows:

```bat
scripts\build-windows.bat
```

`dist/IMGenius/` is the packaged application directory. `assets/` is bundled, but `~/.local/share/IMGenius` or `%LOCALAPPDATA%\IMGenius` is never bundled into a release.

CI builds are described in `.github/workflows/build.yml`.

## Change a page

Use `imgenius/ui/pages/<feature>.py`. UI elements shared with other pages belong in `imgenius/ui/widgets/`. Colors and common styling belong in `imgenius/ui/styles.py` and `themes.py`. Domain logic should not import PySide6.

## Release hygiene

- Run all tests.
- Confirm `assets/catalog/` is absent (no bundled character definitions).
- Confirm `assets/characters/` is absent (no bundled portraits).
- Confirm ZIP doesn't contain `app.db`, `chats.db`, `stories.db`, `personas.json`, or any user's generated images.
- Keep Windows and Linux launcher scripts working from the project root.
