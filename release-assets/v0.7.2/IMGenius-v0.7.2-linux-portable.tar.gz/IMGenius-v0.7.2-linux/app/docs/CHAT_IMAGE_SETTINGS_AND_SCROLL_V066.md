# IMGenius v0.6.6 — Scene image controls and scroll restoration

## Chat-side scene generation settings

The Chats page has a compact **Scene image settings** panel directly beneath
**LLM settings**. These controls apply to the **Generate scene image** button:
checkpoint, width, height, steps, CFG, sampler, scheduler, and negative prompt.
A Refresh checkpoints button fetches models from the configured ComfyUI server.
The first opening of Chats also loads available checkpoints automatically.

Chat controls do **not** overwrite Image Studio's independent prompt and sampling
settings. Advanced options not exposed in Chats (LoRAs, CLIP skip, refinement,
seed, batch) are inherited from Image Studio. Scene generation forces txt2img
and always uses the automatically constructed roleplay scene prompt, not the
manual Image Studio prompt. Image settings are saved locally in QSettings.

## Chat position

Editing a message, Regenerate, Continue, and finishing their generation now
retain the bottom of the current chat. The list's repaint is suspended before
its rows are rebuilt; after Qt has laid out the rows, the scrollbar is restored
or pinned immediately as appropriate. No multi-screen smooth animation plays
from position zero just because a chat was refreshed.

Normal streaming tokens still use the gradual follow-bottom animation. Explicit
user scrolling pauses that animation. Opening an existing multi-message chat
shows the latest messages; opening a new chat containing only a long greeting
starts at the top so it can be read. Refreshing sidebar conversation previews
no longer redundantly reloads the active chat.

## Test notes

The automated regression tests include scroll state, synthetic Continue prompts,
scene-image argument overrides, and settings integration. On systems with PySide6
and ComfyUI, also check that changing the chat checkpoint and sampling values
changes the actual generated image; manually test edits/regenerations in a long
conversation and confirm that scrolling upward still pauses automatic following.
