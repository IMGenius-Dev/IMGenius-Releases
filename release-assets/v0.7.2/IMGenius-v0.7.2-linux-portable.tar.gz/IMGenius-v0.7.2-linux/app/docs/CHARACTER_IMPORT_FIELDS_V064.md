# IMGenius 0.6.4 — Character profile import corrections

## Fixed

On PNG and JSON character-card import, IMGenius maps the short public description separately from the character's longer AI roleplay definition. The app previously always placed `data.description` into user-visible Description, even when it was a long character profile and no explicit `personality` existed. Long or clearly roleplay-structured descriptions now enter the Personality field; if a separate short description is present, it is used as the public Description. A short regular description retains its previous mapping when accompanied by an explicit personality field.

Legacy TavernAI `char_persona` is Personality, not Description. The original prompt text is preserved when a separate Personality field exists. System Prompt stays independent and retains the existing default if not present.

Age is read from explicit fields (`age`, `character_age`, extensions and metadata) first, and then from recognizable textual age labels or years-old expressions in character profile content. Gender supports canonical values and common aliases, tagged values, and explicitly labeled character gender in the card definition. For uncertain identity/age the app leaves Age blank or Gender Other instead of guessing from pronouns, user-POV labels, heights or ratings.

These rules apply to locally imported PNG and JSON cards and Chub cards downloaded as embedded PNGs through the normal importer. Import still opens an **unsaved Character Editor draft**. Always review fields before saving.

## Existing cards

No existing stored cards, chat histories, image outputs or other user data are modified. Re-import an originally downloaded PNG/JSON card to obtain the corrected field mapping and then review/replace an existing profile manually as appropriate. Avoid creating duplicate cards if you already have conversations associated with an old import; instead transfer values into the existing character via Edit.

## Verification

`python -m pytest -q` passes all 404 tests, including the new regression cases for long model prompts, classic short descriptions, gender aliases and profile labels, age precedence and age inference, V1 compatibility, and PNG/JSON/SQLite preservation. GUI validation requires launching the Qt desktop app on the target computer.

Patch source compatibility: IMGenius 0.6.3. Does not include or alter user databases.
