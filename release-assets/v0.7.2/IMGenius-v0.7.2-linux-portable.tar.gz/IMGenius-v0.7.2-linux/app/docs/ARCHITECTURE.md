# IMGenius code architecture

## Design goals

1. Each feature has a discoverable, named home.
2. User data is kept separate from the installation, including in packaged builds.
3. UI layout, business rules, and network integrations do not live in the same giant file.
4. Existing database schemas, prompt behavior, and external API calls are preserved.

## Application flow

`main.py` → `imgenius.bootstrap.main()` → initialize character catalog/user data → `imgenius.ui.main_window.MainWindow`.

The window composes eight page mixins from `imgenius/ui/pages/`:

| User-facing feature | Page source | Primary non-UI dependency |
|---|---|---|
| Character Library | `characters.py` | `characters/repository.py`, `library.py` |
| Character Editor | `editor.py` | `characters/card_io.py`, `lorebook.py` |
| Chats | `chats.py` | `chats/repository.py`, `personas.py` |
| Create image | `images.py` | `images/comfy.py`, `avatar_generation.py` |
| My images | `gallery.py` | `shared/paths.py`, `ui/layout.py` |
| Stories | `stories.py` | `stories/repository.py` |
| Models | `models.py` | `models/manager.py`, `creative_catalog.py` |
| Settings | `settings.py` | `data/cleanup.py`, `ui/themes.py` |

The Character Editor remains an *internal page* accessed from the Characters area; it has no redundant navigation button.

## UI module boundaries

`ui/main_window.py` owns shared navigation, worker lifecycle, status, and cross-page events. Page modules own layout construction and user interactions. Page mixins share only the controller's state (`self`) to avoid circular imports. Widgets live in `ui/widgets/`: `characters.py`, `chats.py`, `controls.py`, `visuals.py`, and `workers.py`.

`ui/styles.py` is the single base stylesheet; `ui/themes.py` applies color presets. Icons are loaded by `ui/brand_assets.py` from the installation's assets folder.

## Character storage and prompts

- `characters/repository.py`: SQLite schema and CRUD.
- `characters/prompts.py`: first-message templates, variable replacement and active system prompt construction.
- `characters/lorebook.py`: keyword activation and JSON conversion.
- `characters/card_io.py`: portable character-card formats including PNG metadata.
- `characters/portraits.py`: bundled sample portraits and local fallback images.
- `characters/seeds.py`: idempotent, registry-based starter-character installation.
- `characters/library.py`, `grid_layout.py`, `pagination.py`: metadata tags and browsing functions.

`imgenius/domain.py` provides stable, explicit exports for data stores and common character helpers; implement new behavior in the named feature module, not in this public export file.

## External integrations

- `images/comfy.py`: ComfyUI workflow construction, uploading, polling, saving outputs.
- `images/avatar_generation.py`: two-stage Ollama prompt authoring and ComfyUI generation.
- `models/manager.py`: Ollama/Hugging Face model downloads/imports.
- `models/creative_catalog.py`: curated GGUF variants and metadata.
- `models/legacy_bridge.py`: existing convenience functions maintained for compatibility.

## Persistent user data

`shared/paths.py` resolves the user-writable folder and creates it when needed:

- Linux: `${XDG_DATA_HOME:-~/.local/share}/IMGenius/`
- Windows: `${LOCALAPPDATA}/IMGenius/`

The package contains **only readonly bundled** art and catalog files in `assets/`. Database files (`app.db`, `chats.db`, `stories.db`), personas, downloaded/generated images and added portraits stay in the user data folder. Old app installations can coexist with this release; both point at the same user data folder.

First-run asset copying is *missing-file only*; existing portraits are not overwritten.

## Adding a new feature

1. Put non-UI logic in the appropriate domain folder with no Qt dependencies.
2. Put the Qt page layout and event handlers in a named module under `ui/pages/`.
3. Add reusable components in `ui/widgets/`, not directly to the page.
4. Register the page in `ui/main_window.py` if it needs navigation.
5. Add backend tests and a UI contract test under `tests/`.
6. Keep personal files out of `assets/` and out of the project ZIP.
