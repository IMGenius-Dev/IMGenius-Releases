# IMGenius v0.6.8 — Permanent Gallery Image Deletion

Use **My images** to select a single image or Ctrl/Shift-click several images. Click **Delete permanently**, press **Delete** with the gallery focused, or right-click an image and select **Delete permanently**. After a confirmation, IMGenius calls filesystem unlink on each image; files are not put in the OS Trash/Recycle Bin.

Only supported image extensions (.png, .jpg, .jpeg, .webp) located directly in the application's own data `images/` directory are eligible. Symbolic links and external files cannot be deleted by this operation. Failed deletes are reported; an unlink failure rolls back any chat-image reference removal for that file.

Successful deletion removes image attachment records for that filename across the app's chats. Text conversations and messages are not deleted. It also refreshes the gallery, Image Studio browser, any selected preview, and active chat when affected.

This removes IMGenius's managed copy; it does not erase any separately saved copies, other app references, backups, or cloud copies. Filesystem unlink is **not a secure wipe** on SSDs or snapshot-capable filesystems.

Regression coverage: tests/integration/test_gallery_permanent_deletion_v068.py and tests/ui/test_gallery_delete_v068.py.
