# IMGenius Patcher — updating your source installation

The patch manager is a **separate native PySide6 desktop window**. It applies **ZIP patches to the IMGenius Python source folder**, not to the packaged PyInstaller executable. It runs on Windows and Linux.

## Launch

- Linux: `./launch-patcher-linux.sh`
- Windows: `launch-patcher-windows.bat`
- Or run `python patcher.py` from the project root.

IMGenius 0.5.x and 0.6.x require PySide6. On Arch Linux, `sudo pacman -S pyside6` installs the same dependency used by the main app.

## Apply a patch

1. **Close IMGenius** before applying an update.
2. In IMGenius Patcher, select the **source directory containing `main.py`, `imgenius/`, and the launch scripts**. The folder is remembered.
3. Drag a `.zip` file onto the purple drop area, or use **Browse ZIP**.
4. Review each **Add** / **Replace** operation.
5. Click **Apply patch** and confirm.
6. Restart IMGenius.

Backups are saved inside the chosen project folder:

```
<IMGenius project>/.imgenius-patcher/backups/<date>_<id>/
```

Use **Restore last backup** to undo the most recent installed patch. The backup folder is ignored by Git.

**User data is separate and untouched**: `~/.local/share/IMGenius/` on Linux (respecting `XDG_DATA_HOME`), `%LOCALAPPDATA%\IMGenius\` on Windows. The patcher also explicitly blocks `data/`, private folders, unsafe ZIP paths, symbolic links, and unexpected file types.

## ZIP patch layout

Patch members must match their path inside the IMGenius source root:

```
imgenius-patch.json         (recommended, optional)
imgenius/ui/pages/chats.py
imgenius/characters/prompts.py
assets/nav/chats.png
```

Alternatively, all these files can be contained in **one outer ZIP folder**. `README.md` and `UPGRADE.md` found alongside a patch are ignored unless specifically declared in a manifest.

An old (0.4.x) patch containing top-level `qt_app.py` or `core.py` is **incompatible** with 0.5's reorganized source structure; the patcher explains this instead of installing it.

Recommended manifest `imgenius-patch.json`:

```json
{
  "format": "imgenius-patch-v1",
  "name": "IMGenius 0.5.2 chat update",
  "version": "0.5.2",
  "target_version": "0.5.*",
  "files": [
    {"path": "imgenius/ui/pages/chats.py", "sha256": "<64 lowercase hex characters>"}
  ]
}
```

The `target_version` checks the currently installed `imgenius.__version__`; compatible `0.5.*` versions are accepted. Individual file hashes verify integrity before any application file is replaced.

## Creating patches

Use the included creator from the source project root:

```bash
python scripts/create-patch.py --name "Chat fixes" --version 0.5.2 --output ./IMGenius_v0.5.2_Chat_Patch.zip imgenius/ui/pages/chats.py
```

The utility packages only the selected files and automatically adds an integrity-checked manifest. Avoid making patch archives from full release ZIPs; the patcher is intended for small targeted source changes.

## What it does not do

- Does not patch already-compiled PyInstaller app bundles; rebuild those from updated source.
- Does not execute scripts from the patch ZIP.
- Does not run a server, modify Ollama or ComfyUI, or delete installed models.
- Does not silently apply a patch. It requires confirmation.

**Only install patches you trust.** Python source changes can run arbitrary code the next time the app launches. The patcher's path and checksum checks do not prove that the publisher is trustworthy.

To add **IMGenius Patcher** to your KDE Plasma application launcher, run `bash scripts/install-patcher-linux-desktop.sh` from the full project folder. This is optional; it does not replace the existing main IMGenius launcher.

## Try it with a harmless demo

The package includes `examples/IMGenius_Demo_Patch.zip`. Drop it into the patcher after selecting your v0.5 source folder. It adds only `docs/PATCHER_TEST.txt` to the project. You can delete that file manually or press **Restore last backup** to remove it. No characters, conversations, models or generated images are changed.


## v0.6 compatibility

The included patcher accepts source installations from the 0.5.x and 0.6.x series.
A v0.6.0 upgrade patch targets **0.5.12**, while future maintenance patches
should declare a `target_version` matching the installed version. Back up your
project before major upgrades; the patcher also makes a restore point.
