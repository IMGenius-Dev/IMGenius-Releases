# Civitai SDXL / Illustrious browser (v0.7.2)

IMGenius Models now includes a Civitai tab using the **documented Civitai public JSON API** at `https://civitai.com/api/v1/models`; external browser links open at `https://civitai.red/models/{id}`. The `.red` site advertises the same model catalog but an independent `.red` JSON API has not been verified. No Civitai credentials are embedded.

## Hard restrictions

- **Allowed baseModel values**: `SDXL 1.0`, `Illustrious` **exactly**. No inferred compatibility, keywords, or family-name matching.
- **Allowed top-level model types**: `Checkpoint`, `LORA` only.
- **Allowed version download**: a single `.safetensors` Model file with a trusted Civitai download URL. A model with both Illustrious and Pony/Flux versions only exposes its Illustrious version.
- Server-side `types` and `baseModels` filters are sent, but results **also pass the local, strict per-version filter**. The same validation runs again before installing.
- Downloads require explicit confirmation and save to local ComfyUI `models/checkpoints` or `models/loras` using atomic `.part` files. Existing weight files are never overwritten. If the API supplies SHA-256, the file is verified before installation.
- Search and downloads use background workers; search shows errors nonmodally. Model downloads may require Civitai authentication or be unavailable.

The Hugging Face, Ollama and creative-writing tabs remain independent of this new Civitai-only restriction. A model's listing does not guarantee your ComfyUI workflow supports its LoRA architecture. Restart/refresh ComfyUI after installing new weights.

## Updates

The GitHub startup checker looks for a tagged release on the **public** `IMGenius-Dev/IMGenius-Releases` repository; pushing changes to the private source repository does **not** automatically make a downloadable update available. Publish and validate a public installer release separately before testing that notification flow.
