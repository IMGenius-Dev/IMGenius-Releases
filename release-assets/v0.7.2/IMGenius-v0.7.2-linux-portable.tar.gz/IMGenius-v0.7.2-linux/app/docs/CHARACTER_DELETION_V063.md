# IMGenius 0.6.3 — Individual character deletion

## How to use

1. Open **Characters → My characters**.
2. On your custom or imported character card, open the **⋮** action menu.
3. Choose **Delete character…**. Check the name and linked conversation/message totals.
4. Select **Yes** to delete or **Cancel** to retain everything.

Only user-added cards show the deletion menu. The original bundled Nova/Atlas profiles and seeded catalog cards are protected by stored identity, not display name. Character deletion is irreversible through the app.

## What gets deleted

- The selected local character's SQLite record, including its embedded memory fields.
- Every saved chat whose `character_id` matches the selected ID, with its messages, summary, and linked scene-image records.
- Unshared portrait artwork inside IMGenius's managed `character_cards/` folder, except bundled image assets.
- Stale in-memory and locally saved context notes for the deleted chat IDs, when present.

## What stays

- Other characters, including similarly named ones, and all their chats/messages.
- Stories (not keyed to specific characters), model files, original imported files outside the IMGenius-managed image folder, and generated gallery images in `images/`.
- Shared character portraits, even when the deleted character also pointed to them.

## Technical notes

The application keeps characters in `app.db` and chats in `chats.db`. The deletion service temporarily attaches the chat database to the character database's SQLite connection and deletes both sides within a single transaction. SQLite's default rollback journal is expected for atomic commits across both files. No schemas are migrated. Both database connections need to be idle before deletion; the UI refuses while AI/image jobs are active. `secure_delete` is enabled for the affected SQLite connections, but users' own filesystem snapshots/backups are outside the application's control.

The patch archive targets v0.6.2. It updates source code but **does not contain or replace** `app.db`, `chats.db`, gallery images, local models, or any other personal data.

## Verification

`python -m pytest -q`: 382 tests passed in the source-only test environment. The six v0.6.3 tests include deletion of multiple chats, the persistence check after reopening both databases, isolation from similarly named characters, protected seed IDs, shared/outside artwork retention, and rollback on a simulated database failure.

A manual visual test of the Qt menu and confirmation is still required on a computer with PySide6 and a GUI.
