# Chub browsing evolution

IMGenius 0.6.0 uses the TelegAI-hosted public catalog service for **Full catalog**
without changing its visible Chub branding. See [CHUB_CATALOG_V060.md](CHUB_CATALOG_V060.md)
for the new 80-record batch adapter, paging, filters and known limitations.

The notes below describe the historical 0.5.x behavior and remain for migration.

# Chub character discovery in IMGenius 0.5.7 (historical)

In version **0.5.7**, online cards shown under **Characters → Chub** came from `https://api.chub.ai/search`, not from the rendered HTML at telegai.com. Online browsing is opt-in and does not depend on Qt WebEngine.

For **0.5.8–0.5.11**, the Characters gallery used only the limited TelegAI-hosted recommendations feed. Since **0.5.12**, the source selector allows **Full catalog** (Chub's indexed `https://api.chub.ai/search`) or **For you feed** (TelegAI-hosted `/api/user/foryou`). Both display Chub character cards and import through the regular Chub export methods. See [TELEGAI_FEED.md](TELEGAI_FEED.md) for the recommendations implementation.

## Full catalog filtering (0.5.12)

- Text searches go to the server as `search=` rather than filtering the downloaded page.
- Tag searches go to the server as `topics=...`, using comma-separated tag names. The tag parameter is sent only when a filter is provided. Multi-tag matching semantics depend on the third-party API and have not been verified live.
- Page numbers go to the indexed search endpoint as `page=`; the provider's `count` / `totalCount` signals (or page fullness) control Next. Unlike the For you feed, pages aren't limited by a recommendation list.
- Popular, Newest, and Recently updated use the index's sort options.
- The recommended For you feed keeps the independently tested mature-topic/portrait labeling but does not provide site-wide text or tag search.


## Mature content and content ratings

- The **Include mature** switch asks for local adult confirmation for the current session and submits `nsfw=true` to Chub; disabling it submits `nsfw=false` and excludes any explicitly Mature-rated results.
- This does not transfer a Chub login or any site-side age confirmation. Chub controls which records its API returns.
- Some public search results omit a content-rating field. Such cards are shown as **Unrated**, not asserted to be Safe. A screenful of Unrated cards is not proof mature access is unavailable or available.
- IMGenius displays response counts but does not invent mature status for cards without metadata.

## Importing Chub characters

Click a card portrait or **Import card**, or paste a `https://chub.ai/characters/author/slug` URL. Older TelegAI links are also accepted. IMGenius fetches a public PNG with embedded card metadata, trying a Chub Tavern export as a fallback if the CDN route fails. It validates the complete card and opens an **unsaved draft** in Character Editor; saving is always your choice.

## Limitations

These public endpoints are maintained by a third party and can change. IMGenius makes no claims about how many mature results the provider actually supplies. The development environment couldn't reach Chub live, so verify results on your computer. If Chub declines an export, use the provider's normal download UI and IMGenius's local card import rather than attempting to bypass account, age, or regional restrictions.
