# IMGenius v0.6.2 — Long opening messages and chat scrolling

This update addresses clipping and scroll jumps in the existing native Chats page.

## Changes

- **Opening messages:** The chat timeline scrolls by pixel instead of by message item. An imported first greeting longer than the viewport can now be read from its first line through its last line with the mouse wheel, trackpad or scrollbar.
- **Long rich-text messages:** Message height measurement reserves a proportional margin for long paragraphs, formatted HTML and roleplay text, reducing differences between QTextDocument and QLabel line spacing that could hide the final lines.
- **Long character scenarios:** Chat headers now show character name and model only. Hover over the header to read the full scenario; the scenario is still used in the character prompt and remains available in the Character Editor. It no longer takes over the conversation's vertical space.
- **Smooth new replies:** New and streamed replies gradually scroll into view instead of instantly jumping to the last item. The timer follows the current content height as it grows.
- **Reader control:** Scrolling upward with the wheel, keyboard or scrollbar disables auto-follow so existing content can be read while generation continues. Scrolling back to the bottom re-enables following.
- **Chat navigation:** A conversation with one opening message opens at its beginning, not its end. Existing conversations with multiple messages open at the latest reply. Refreshes keep the reader's position if auto-follow is not active.

## Upgrade

Apply the v0.6.2 patch using IMGenius Patcher to a **v0.6.1** source installation, or extract the complete v0.6.2 source project separately. Restart IMGenius after patching. No database schema or existing user data changes are made.

## Verification

The automated suite covers long-content sizing, per-pixel scrolling, incremental follow steps, manual scroll cancellation, initial opener position, normal chat reopening, preserving reading position, and avoiding stale deferred scroll callbacks.

The Qt interface still needs visual testing on Linux or Windows where PySide6 is installed; the automated tests run without a display server.
