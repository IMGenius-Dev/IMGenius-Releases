# IMGenius v0.6.7 — Animated startup splash

The launch flow now displays an animated branded Qt splash immediately after QApplication
and theme initialization. The panel uses the existing IMGenius icon, a dark
purple/cyan theme, rotating dots, a moving indicator bar, and status messages:
character library, saved cards, catalog, personas, and portraits. The splash
fades out after the main window is visible. Fast launches are **not artificially
delayed** just to show the animation.

**Responsiveness:** startup database and portrait preparation happens sequentially
inside a QThread, so the GUI event loop remains free to animate. These tasks
finish before the MainWindow creates its own character/chat database stores.
The main window is created on the GUI thread, as required by Qt. A startup
error shows a dialog and prints diagnostics to stderr rather than opening
an incompletely initialized window.

**Dependency:** PySide6, already required for IMGenius. No network services,
Qt Quick, videos, GIFs, or other libraries are needed. Color and icon are
built from current local assets. User data paths and schemas are unchanged.

**Manual QA:** test a fast relaunch, a fresh install with catalog seeding, and
a second run with hundreds of characters. On Windows, KDE Wayland, and X11,
verify that the panel is centered, progress animates smoothly, and the main
window opens once. No GUI screenshot test runs in headless CI.
