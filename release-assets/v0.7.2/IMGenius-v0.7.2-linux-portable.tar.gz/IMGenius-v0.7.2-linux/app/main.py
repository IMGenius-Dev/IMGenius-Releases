"""IMGenius application launcher. Implementation lives in imgenius/."""
from imgenius.bootstrap import main

if __name__ == '__main__':
    raise SystemExit(main())
