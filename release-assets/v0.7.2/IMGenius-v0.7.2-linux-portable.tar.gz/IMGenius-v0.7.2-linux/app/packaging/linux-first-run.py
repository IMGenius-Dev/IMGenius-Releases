"""No third-party dependencies; Linux first-run setup for IMGenius 0.7.
Never writes to /opt or into distributed sources; uses per-user XDG data.
"""
from __future__ import annotations
import os
from pathlib import Path
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext

APP_ROOT=Path(__file__).resolve().parents[1]
HOME=Path(os.environ.get('XDG_DATA_HOME') or Path.home()/'.local/share')/'IMGenius'
VENV=HOME/'runtime'
COMFY=HOME/'engines'/'ComfyUI'

def has_comfy():
    return (COMFY/'main.py').is_file() or (Path.home()/'ComfyUI'/'main.py').is_file()

def run_command(cmd,log):
    log('$ '+' '.join(map(str,cmd)))
    proc=subprocess.Popen([str(x) for x in cmd],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
    for line in proc.stdout: log(line.rstrip())
    if proc.wait(): raise RuntimeError(f'Command exited with status {proc.returncode}: {cmd[0]}')


def setup_gui():
    win=tk.Tk();win.title('IMGenius 0.7 — First-run Setup');win.geometry('710x540')
    win.configure(bg='#171522')
    tk.Label(win,text='IMGenius 0.7',font=('Arial',22,'bold'),bg='#171522',fg='#e4ddff').pack(pady=(15,3))
    tk.Label(win,text='Install your personal Python environment without changing system packages.',bg='#171522',fg='#bbb2d8').pack()
    comfy=tk.BooleanVar(value=not has_comfy())
    nvidia=tk.BooleanVar(value=False)
    desktop=tk.BooleanVar(value=False)
    for text,var in [('Install ComfyUI from official source (large download)',comfy),('Use NVIDIA GPU PyTorch for ComfyUI (requires compatible driver)',nvidia),('Create a Desktop shortcut (app menu entry already installed)',desktop)]:
        tk.Checkbutton(win,text=text,variable=var,bg='#171522',fg='#ddd4ee',selectcolor='#322744',activebackground='#171522',activeforeground='white').pack(anchor='w',padx=35)
    output=scrolledtext.ScrolledText(win,height=14,bg='#11101a',fg='#c7e1e5',font=('Monospace',9)); output.pack(fill='both',expand=True,padx=20,pady=12)
    bottom=tk.Label(win,text='Python and Qt download requires an internet connection.',bg='#171522',fg='#bbb2d8');bottom.pack(pady=4)
    def log(line): win.after(0,lambda line=line:(output.insert('end',line+'\n'),output.see('end')))
    def work():
        try:
            HOME.mkdir(parents=True,exist_ok=True)
            if not (VENV/'bin/python').exists(): run_command([sys.executable,'-m','venv',str(VENV)],log)
            python=str(VENV/'bin/python')
            run_command([python,'-m','pip','install','--disable-pip-version-check','-r',str(APP_ROOT/'requirements.txt')],log)
            if comfy.get() and not has_comfy():
                COMFY.parent.mkdir(parents=True,exist_ok=True)
                run_command(['git','clone','--depth','1','https://github.com/Comfy-Org/ComfyUI.git',str(COMFY)],log)
                run_command([sys.executable,'-m','venv',str(COMFY/'.venv')],log)
                enginepy=str(COMFY/'.venv/bin/python')
                index='https://download.pytorch.org/whl/cu130' if nvidia.get() else 'https://download.pytorch.org/whl/cpu'
                run_command([enginepy,'-m','pip','install','torch','torchvision','--index-url',index],log)
                run_command([enginepy,'-m','pip','install','-r',str(COMFY/'requirements.txt')],log)
            if desktop.get():
                user_desktop=Path(os.environ.get('XDG_DESKTOP_DIR') or Path.home()/'Desktop')
                user_desktop.mkdir(parents=True,exist_ok=True)
                source=Path('/usr/share/applications/imgenius.desktop')
                if not source.exists(): source=Path.home()/'.local/share/applications/imgenius.desktop'
                if source.exists():
                    dest=user_desktop/'IMGenius.desktop'; dest.write_bytes(source.read_bytes());dest.chmod(0o755)
            win.after(0,lambda: finish())
        except Exception as exc:
            log(f'SETUP ERROR: {exc}')
            win.after(0,lambda e=str(exc): fail(e))
    def finish():
        bottom.config(text='Setup complete. You can now launch IMGenius.'); btn.config(text='Launch IMGenius',state='normal',command=win.destroy)
    def fail(err):
        bottom.config(text='Setup encountered an error. Review the log above.');btn.config(state='normal',text='Retry setup',command=start)
        messagebox.showerror('IMGenius Setup',err)
    def start():
        btn.config(state='disabled');threading.Thread(target=work,daemon=True).start()
    btn=tk.Button(win,text='Install and configure IMGenius',command=start,bg='#493c77',fg='white',font=('Arial',12,'bold'));btn.pack(pady=8)
    win.mainloop()

if __name__=='__main__':
    try:
        setup_gui()
    except Exception as exc:
        print(f'IMGenius first-run setup needs Tkinter and a graphical session: {exc}',file=sys.stderr)
        sys.exit(1)
