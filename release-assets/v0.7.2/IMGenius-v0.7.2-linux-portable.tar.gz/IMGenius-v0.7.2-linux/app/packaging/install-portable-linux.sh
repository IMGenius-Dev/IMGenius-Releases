#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
root="$HOME/.local/opt/IMGenius"
mkdir -p "$root" "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/256x256/apps"
cp -a app/. "$root/"
cat > "$HOME/.local/bin/imgenius" <<EOF
#!/usr/bin/env bash
IMGENIUS_APP_ROOT="\$HOME/.local/opt/IMGenius" exec "\$HOME/.local/opt/IMGenius/packaging/imgenius-linux" "\$@"
EOF
chmod +x "$HOME/.local/bin/imgenius"
cp app/packaging/imgenius.desktop "$HOME/.local/share/applications/imgenius.desktop"
sed -i "s|^Exec=imgenius$|Exec=$HOME/.local/bin/imgenius|" "$HOME/.local/share/applications/imgenius.desktop"
cp app/assets/IMGenius-256.png "$HOME/.local/share/icons/hicolor/256x256/apps/imgenius.png"
read -r -p 'Create Desktop shortcut? [y/N] ' choice || true
if [[ "${choice:-}" =~ ^[Yy] ]];then
 mkdir -p "$HOME/Desktop"
 cp "$HOME/.local/share/applications/imgenius.desktop" "$HOME/Desktop/IMGenius.desktop";chmod +x "$HOME/Desktop/IMGenius.desktop"
fi
printf 'Installed IMGenius 0.7. Launch using app menu or %s/.local/bin/imgenius\n' "$HOME"
