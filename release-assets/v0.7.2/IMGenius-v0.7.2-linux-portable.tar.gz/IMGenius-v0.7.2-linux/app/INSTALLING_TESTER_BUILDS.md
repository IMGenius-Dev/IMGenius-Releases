## v0.7.2 image-weight browser

Models now includes a Civitai tab limited to SDXL 1.0 / Illustrious checkpoints and LoRAs. There are no new Python dependencies. This is **not** an installer self-update: replace the installed application through the OS installer/package manager, or run from updated development source. Read `docs/CIVITAI_SDXL_ILLUSTRIOUS_V072.md` for details.

# IMGenius 0.7 — Tester installation guide

## Windows 10/11 (64-bit)

1. Download **IMGenius-Setup-v0.7.exe** and double-click it. It installs program files for your Windows account to `%LOCALAPPDATA%\Programs\IMGenius`. Administrator access is not needed for the app itself, although winget may request elevation for some prerequisites.
2. Follow the installation dialog for **Python 3.12**, and choose whether to install **ComfyUI**, optional NVIDIA PyTorch or CPU inference, **Ollama**, and a starter text model. An internet connection is required for any missing runtime or model downloads. A compatible GPU driver is still required for GPU inference.
3. Choose **Desktop** and/or **Start Menu** shortcuts separately. After setup, launch **IMGenius** from your shortcut or `%LOCALAPPDATA%\Programs\IMGenius\IMGenius.exe`.
4. To uninstall *program files only*, run `uninstall-windows.bat` inside the installed folder. Your characters, chats, gallery, ComfyUI installations, and models remain under `%LOCALAPPDATA%\IMGenius` or their chosen locations.

**Technical note:** The Windows `.exe` is a native launcher that starts the Python/Qt application from an isolated runtime installed during setup. It is **not** a self-contained PyInstaller frozen Qt bundle. First run downloads the missing prerequisites, which can be several gigabytes if ComfyUI is selected. Windows Package Manager (winget) must be available for automated Python/Git/Ollama installations.

## Debian/Ubuntu Linux (64-bit)

1. Download `imgenius_0.7.0_amd64.deb` and install it using your graphical package installer or `sudo apt install ./imgenius_0.7.0_amd64.deb` from its download directory.
2. Open **IMGenius** in the application menu, or run `imgenius` in a terminal.
3. The first-run setup wizard downloads the desktop Python/Qt dependencies into `~/.local/share/IMGenius/runtime` (or `$XDG_DATA_HOME/IMGenius/runtime`). Optionally install ComfyUI and choose a CPU or compatible NVIDIA PyTorch build. The icon will then launch the installed app.
4. Ollama for local chat is installed separately from its official provider on Linux. Select/download a model before generating text. ComfyUI model checkpoints are likewise not included.
5. Remove the app using your package manager, e.g. `sudo apt remove imgenius`. This preserves personal data and model files.

## Other Linux distributions (including Arch)

1. Download `IMGenius-v0.7-linux-portable.tar.gz`; extract it.
2. From the extracted `IMGenius-v0.7-linux` folder run `bash install.sh`. No root permissions required.
3. Launch from the new app menu entry or `~/.local/bin/imgenius` (may require logging out and back in to update your PATH).
4. Ensure Python 3, pip/venv support, Tkinter, Git, and a GUI/X11 or Wayland session are installed. On Arch: `sudo pacman -S python python-pip tk git` (the isolated venv uses pip; no system Python packages are overwritten).

## Privacy and runtime behavior

- Both packages deliberately contain **no character cards, portraits, conversations, user databases, or generated images**. Brand and generic navigation icons are present.
- User data lives outside the install directory. Installing/updating a package does not delete it.
- IMGenius starts a configured local ComfyUI backend if needed. On close, it stops only the ComfyUI process it started, not an existing user-managed one.
- The application and installers are **not digitally signed**. Windows SmartScreen may warn; only download these tester builds from the developer's trusted distribution channel. Do not bypass security warnings for unexpected files.
- Native Windows/Qt/GPU installation still requires real-device testing. Please report Windows version, GPU/driver, steps to reproduce, and redacted log excerpts for any issue.
