# IMGenius v0.7.2 — Civitai SDXL / Illustrious browser

The **Models → Civitai · SDXL / Illustrious** tab searches the public Civitai catalog for **Checkpoint** and **LoRA** versions whose `baseModel` is **exactly** `SDXL 1.0` or `Illustrious`. Downloads require confirmation and install individual `.safetensors` weights into the configured ComfyUI model directories. See [docs/CIVITAI_SDXL_ILLUSTRIOUS_V072.md](docs/CIVITAI_SDXL_ILLUSTRIOUS_V072.md) for supported formats and limitations.

**Update testing:** Source commits alone do not trigger the desktop update prompt. To test it on an existing v0.7.1 client, publish a `v0.7.2` release with installer assets in the separate public `IMGenius-Dev/IMGenius-Releases` repository.

---

# IMGenius v0.7.0 — Windows & Linux setup

IMGenius is a desktop application for character chat (Ollama), character-card editing, and local image generation (ComfyUI). **This source release ships with no saved character cards, portraits, chats, personal data, model weights, or image gallery content.** You add your own characters and choose which local models to install. Your saved data stays outside the application folder.

## Windows — first-time setup (recommended)

1. Download and extract the **full v0.7.0 source ZIP** into a user-writable folder, for example `%USERPROFILE%\Documents\IMGenius`. Don't run it from inside the ZIP or extract it into protected `C:\Program Files`.
2. On Windows 10/11 with the Microsoft **App Installer / winget** available, double-click **`setup-windows.bat`**. Keep the console open; the wizard uses standard Windows Yes/No dialogs.
3. Setup checks for **Python 3.12** and installs it through winget if missing. It creates a separate `.venv` for IMGenius and installs its Python dependencies automatically.
4. Choose whether to **install ComfyUI**. If accepted, setup checks for an existing copy first; otherwise it installs Git (if needed), clones the [official ComfyUI source](https://github.com/Comfy-Org/ComfyUI), creates its isolated Python environment and installs PyTorch + ComfyUI requirements. Choose the **NVIDIA CUDA 13.0** option only with a compatible GPU and up-to-date NVIDIA drivers; choose **CPU** for CPU-only mode. AMD/Intel-specific builds need separate vendor-compatible setup. The download is large and requires internet access.
5. Choose whether to install **Ollama** through winget for local LLM chat. Optionally download the suggested `qwen3:4b` starter LLM. This model is not bundled and can also be installed later through **Models**.
6. Answer the two **separate prompts** for an IMGenius **Desktop shortcut** and **Start Menu shortcut**. Both are optional.
7. Launch from a shortcut or **`launch-windows.bat`**. On a new extracted copy, the launcher opens setup first if dependencies are missing.

> If Windows reports a Python/Git/Ollama PATH update is pending, sign out and in, then run setup again. Installer downloads can take a long time; do not close the console mid-install. Windows installations and GPU drivers vary, so no installer can guarantee every CUDA configuration will succeed.

## Linux — first-time setup

1. Extract the full ZIP into a directory you own, such as `~/Applications/IMGenius`.
2. Ensure `python3`, Python `venv` support, and `git` are installed through your distribution package manager. On Arch you can use `sudo pacman -S python git` and install `python-pip` if your venv lacks pip. CUDA users must have compatible NVIDIA drivers; AMD users should install a matching ROCm PyTorch build manually.
3. Open a terminal in the extracted directory and run:

   ```bash
   bash setup-linux.sh
   ./launch-linux.sh
   ```

4. Setup creates an isolated Python environment, installs IMGenius requirements, offers to clone/install ComfyUI from its official source, then offers **application-menu** and **desktop** shortcuts independently. You may skip ComfyUI if you already have a configured installation.
5. Install [Ollama](https://ollama.com/download) with the official distro package or install script if you want chat. Install a compatible model using the **Models** tab, or `ollama pull qwen3:4b`.

On Arch, the project-specific `.venv` avoids changing Python packages managed by `pacman` or `yay`.

## Where files are stored

| Type | Windows | Linux |
|---|---|---|
| User data (characters, chats, generated images, settings-adjacent content) | `%LOCALAPPDATA%\IMGenius` | `${XDG_DATA_HOME:-~/.local/share}/IMGenius` |
| New managed ComfyUI source | `%LOCALAPPDATA%\IMGenius\engines\ComfyUI` | `${XDG_DATA_HOME:-~/.local/share}/IMGenius/engines/ComfyUI` |
| ComfyUI checkpoints | `<ComfyUI>\models\checkpoints` | `<ComfyUI>/models/checkpoints` |
| ComfyUI LoRAs | `<ComfyUI>\models\loras` | `<ComfyUI>/models/loras` |
| Other image models | `<ComfyUI>\models\vae`, `controlnet`, `embeddings`, etc. | Same folder names with `/` separators |
| Downloaded GGUF before Ollama import | `%LOCALAPPDATA%\IMGenius\models\gguf` | `~/.local/share/IMGenius/models/gguf` |
| Installed Ollama weights | Managed by Ollama, not the IMGenius ZIP | Managed by Ollama, not the IMGenius ZIP |

IMGenius also recognizes a source installation at `~/ComfyUI` on either OS, and on Windows the common `ComfyUI_windows_portable/ComfyUI` layout. Existing models aren't moved or overwritten. In **Models → Hugging Face**, confirm the ComfyUI folder is correct before downloading checkpoints. Image generation needs a compatible checkpoint; the setup script does **not** choose, license, or download model weights for you. Some ComfyUI custom nodes require additional dependencies and may not run in the managed base environment.

## Starting and stopping ComfyUI automatically

When IMGenius starts, it checks the **configured ComfyUI URL** and folder. For a local ComfyUI installation, it starts the correct ComfyUI Python in the background, bound to **127.0.0.1**, and logs output to the local user-data `logs/comfyui.log`. Startup may take tens of seconds while models initialize. If an existing local ComfyUI service responds, IMGenius **does not take ownership** of that service or kill it later. A remote/custom URL is never launched locally.

Closing IMGenius with **X** (or normal app exit) asks only its **own** ComfyUI process to stop and waits up to several seconds before force-stopping the managed process tree. The app does **not** stop user-launched ComfyUI or Ollama. If a managed backend can't start, IMGenius still opens and you can inspect the log. GPU driver failures, unsupported models or missing dependencies must be fixed separately.

## Existing IMGenius users — upgrade without losing data

1. **Close v0.6.8**, including any open image/chat generation. Back up your own `%LOCALAPPDATA%\IMGenius` or `~/.local/share/IMGenius` folder.
2. **Extract v0.7.0 to a fresh application directory** rather than merging ZIP contents into an old source folder. This ensures old bundled portraits/catalog files are not left behind in the application directory. The new release purposely doesn't package them.
3. Run setup, then launch. Your existing saved characters, chats, and images stay in their **separate user data directory** and should be read by v0.7.0 without copying them into the application.
4. Verify old chats and imported character images load, then optionally retire the old source folder. Never publish or share a zipped copy of the user data directory.

The patch manager cannot delete obsolete bundled assets from an existing source folder. For this privacy-sensitive release, **use the full clean source archive instead of applying an overwrite-only patch to v0.6.8**.

## Problems and troubleshooting

- **App won't open:** run `launch-windows.bat` from Command Prompt or `./launch-linux.sh` in a terminal and read the displayed error. Rerun setup if `.venv` isn't installed.
- **ComfyUI unavailable:** confirm the ComfyUI directory contains `main.py`, has a working `.venv`, and its URL is `http://127.0.0.1:8188`. Check `<user data>/logs/comfyui.log`. Use **Models → ComfyUI folder** if you installed it elsewhere.
- **No image checkpoints:** download a model you have permission to use from **Models → Hugging Face** into the proper `models/checkpoints` folder; refresh the model list.
- **CUDA errors:** update the NVIDIA driver or use an appropriate PyTorch CUDA build. For an AMD GPU, manual ROCm/DirectML support may be needed; CPU mode is slow.
- **No local chat models:** ensure Ollama runs, then download a supported GGUF or pull a chat model. The default local URL is `http://127.0.0.1:11434`.
- **Port 8188 occupied:** close the unrelated service, or point IMGenius at your existing ComfyUI service. IMGenius does not start a second copy if ComfyUI is already responding.
- **Windows shortcuts missing:** rerun `setup-windows.bat` and select Yes on the corresponding prompt.

## Developer notes and release safety

Install `pytest` into your development environment and run `python -m pytest -q`. For a distributable source ZIP, run `python scripts/audit-release.py <zip-path>` and confirm it passes. Never package `data/`, `.venv/`, `.db`, `character_cards/`, `models/`, `logs/`, generated images, or profiles. Only brand assets and generic navigation icons belong in the release.

Native installers and executables must be built and tested on their target OS; `scripts/build-windows.bat` uses PyInstaller for a Windows executable, and `scripts/build-linux.sh` for Linux. **An automated Linux test pass does not certify a Windows installer, the Qt display, GPU drivers, or ComfyUI model compatibility.**

### Packaged executable distributions

On Windows, a PyInstaller build can place `IMGenius.exe`, `setup-windows.bat`, `setup-windows.ps1`, `launch-windows.bat` and the icon beside one another in `dist/IMGenius`. Run **setup-windows.bat** first; the script detects `IMGenius.exe` and installs the local AI prerequisites without creating an extra application Python virtual environment. Shortcuts point at the executable. On Linux, a PyInstaller build likewise includes the shell setup and launcher in `dist/IMGenius`; the launcher detects its native binary. **The distributed ZIP in this conversation is source, not a precompiled Windows `.exe`.**

## Official development repository and automated builds

This is the **private source repository** for IMGenius. The `main` branch represents reviewed development code; locally saved characters, chats, private portraits, model weights, credentials, and downloaded ComfyUI/Ollama installations must never be committed.

GitHub Actions tests Python code and source privacy on Windows and Linux for every push to `main` and every pull request. **Tester binaries are built only when the workflow is run manually or a version tag is pushed**. A successful build creates downloadable GitHub Actions artifacts; **it does not automatically publish an unreviewed public GitHub Release or sign any installer**. Test the Windows and Linux artifacts on real machines before uploading anything to a public distribution repository.

To validate a local checkout:

```bash
python scripts/audit-repository.py
python -m pytest -q
```

See `INSTALLING_TESTER_BUILDS.md` for platform-specific notes. The installer/executable build helper sources are in `packaging/`.

### v0.7.1 startup checks

The animated startup splash checks the public IMGenius GitHub Releases feed before opening, then waits for the configured local ComfyUI instance to answer `/system_stats`. If ComfyUI cannot start, users can retry, continue without image generation, or quit. The GitHub update check is non-blocking on network failure; see [startup checks and release setup](docs/STARTUP_UPDATES_COMFY_V071.md). The public `IMGenius-Dev/IMGenius-Releases` repository must be created and have published releases before update notifications can work.
