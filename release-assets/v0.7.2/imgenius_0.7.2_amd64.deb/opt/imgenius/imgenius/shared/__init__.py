"""Shared components for IMGenius."""
